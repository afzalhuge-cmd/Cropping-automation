"""Sub-parts of the Description: Field / Background / Summary / Sequence Listing.   py test_subsections.py"""
import sys, os, tempfile
import test_sequence as TS
import detector

def main():
    ok = 0; total = 0
    def check(name, cond, info=""):
        nonlocal ok, total
        total += 1; ok += bool(cond)
        print(("PASS  " if cond else "FAIL  ") + name, info if not cond else "")
    path = TS.build("before_claims")
    r = detector.analyze_pdf(path)
    sub = {x["TITLE"]: (x["FIRST pg.no"], x["Last Pg.no"]) for x in r["sub_rows"]}
    check("sub_rows lists the four sub-parts", list(sub) == detector.SUB_SECTIONS, str(sub))
    check("Sequence Listing sits under Description (pages 5-8)", sub["Sequence Listing"] == (5, 8), str(sub))
    desc = next(x for x in r["rows"] if x["TITLE"] == "Description")
    check("Description range still contains the listing", desc["FIRST pg.no"] <= 5 and desc["Last Pg.no"] >= 8)
    r = detector.analyze_pdf(TS.build("no_listing"))
    sub = {x["TITLE"]: (x["FIRST pg.no"], x["Last Pg.no"]) for x in r["sub_rows"]}
    check("no listing: Sequence Listing sub-row blank", sub["Sequence Listing"] == ("", ""), str(sub))
    print(f"\n{ok}/{total} checks passed")
    return 0 if ok == total else 1

if __name__ == "__main__":
    sys.exit(main())
