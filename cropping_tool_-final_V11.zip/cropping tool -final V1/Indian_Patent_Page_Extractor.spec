# -*- mode: python ; coding: utf-8 -*-

from PyInstaller.utils.hooks import collect_submodules, collect_all

hiddenimports = ["detector", "figures", "ocr_engine", "cv2", "numpy"]
datas = []
binaries = []
# Tesseract: if a folder named "tesseract" (tesseract.exe + dlls + tessdata\eng.traineddata) sits next to
# this file, it is packed into the exe so the program runs on PCs without Tesseract installed.
# (Run prepare_tesseract.bat once to create that folder from an installed Tesseract.)
import os
_tess = os.path.join(SPECPATH, "tesseract")
if os.path.isfile(os.path.join(_tess, "tesseract.exe")):
    datas += [(_tess, "tesseract")]
    print("Bundling Tesseract from .\\tesseract")
else:
    print("NOTE: no .\\tesseract folder - the exe will look for an installed Tesseract at run time.")
for pkg in ("pymupdf", "fitz", "cv2"):
    try:
        hiddenimports += collect_submodules(pkg)
    except Exception:
        pass

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Indian_Patent_Page_Extractor',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
)
