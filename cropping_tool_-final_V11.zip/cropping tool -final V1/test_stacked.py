"""Regression test: two figures must never end up in ONE image.

Layouts that used to fail (v37):
  * figures stacked on one sheet with reference numerals ("100", "2") printed in the narrow gap between the
    caption of the upper figure and the drawing below it -> the upper crop crept into the lower figure;
  * two figures side by side whose leader lines / numerals interleave in the same column band.
Run:  py test_stacked.py            (also:  py test_stacked.py some.pdf  to audit a real patent)
"""
import os, sys, tempfile
import numpy as np
import cv2
import pymupdf as fitz
import figures

TMP = tempfile.mkdtemp()


def _drawing(w, h, seed):
    rng = np.random.RandomState(seed)
    img = np.full((h, w, 3), 255, np.uint8)
    for _ in range(40):
        p = rng.randint(0, [w, h], 2); q = rng.randint(0, [w, h], 2)
        cv2.line(img, tuple(int(v) for v in p), tuple(int(v) for v in q), (70, 70, 70), 2)
    cv2.rectangle(img, (5, 5), (w - 6, h - 6), (40, 40, 40), 3)
    path = os.path.join(TMP, f"d{seed}.png")
    cv2.imwrite(path, img)
    return path


def _sheet_stacked(path):
    doc = fitz.open()
    pg = doc.new_page(width=612, height=792)
    pg.insert_text((40, 40), "Applicant Name Pvt Ltd     No of Sheets : 2", fontsize=9)
    pg.insert_image(fitz.Rect(133, 107, 511, 334), filename=_drawing(380, 230, 1))
    pg.insert_text((296, 340), "Figure. 3", fontsize=10)
    for t, (x, y) in (("100", (150, 352)), ("2", (470, 366)), ("101", (140, 380))):   # numerals of the lower figure
        pg.insert_text((x, y), t, fontsize=9)
    pg.insert_image(fitz.Rect(140, 372, 498, 672), filename=_drawing(360, 300, 2))
    pg.insert_text((296, 695), "Figure. 4", fontsize=10)
    pg.insert_text((400, 740), "DIGITALLY SIGNED  Agent for the applicants", fontsize=8)
    doc.save(path)
    return {(3, ""): fitz.Rect(133, 107, 511, 334), (4, ""): fitz.Rect(140, 372, 498, 672)}


def _sheet_side_by_side(path):
    doc = fitz.open()
    pg = doc.new_page(width=612, height=792)
    pg.insert_image(fitz.Rect(133, 402, 340, 611), filename=_drawing(210, 210, 3))
    pg.insert_image(fitz.Rect(352, 402, 506, 611), filename=_drawing(150, 210, 4))
    # numerals (with their leader lines) sitting in the same column band as the neighbouring figure
    pg.insert_text((341, 440), "7A", fontsize=9)                     # belongs to the LEFT figure, leader goes left
    pg.draw_line((339, 437), (300, 437), width=0.6)
    pg.insert_text((331, 415), "101", fontsize=9)                    # belongs to the RIGHT figure, leader goes right
    pg.draw_line((349, 412), (380, 412), width=0.6)
    pg.insert_text((200, 630), "Figure. 8A", fontsize=10)
    pg.insert_text((400, 630), "Figure. 8B", fontsize=10)
    doc.save(path)
    return {(8, "A"): fitz.Rect(133, 402, 340, 611), (8, "B"): fitz.Rect(352, 402, 506, 611)}


def _check(name, path, truth):
    figs = figures.find_figures(path, use_ocr=False, skip_pages=set(), drawing_pages={1})
    by = {(f["num"], f["suffix"]): f for f in figs}
    ok = set(by) == set(truth)
    detail = []
    for key, own in truth.items():
        f = by.get(key)
        if not f:
            ok = False
            continue
        c = fitz.Rect(*f["crop"])
        for k2, other in truth.items():
            if k2 == key:
                continue
            inter = fitz.Rect(c)
            inter.intersect(other)
            frac = inter.get_area() / max(other.get_area(), 1)       # how much of the OTHER drawing is inside this crop
            if frac > 0.05:
                ok = False
                detail.append(f"{f['label']} contains {frac:.0%} of FIG. {k2[0]}{k2[1]}")
        inter = fitz.Rect(c)
        inter.intersect(own)
        if inter.get_area() < 0.95 * own.get_area():                  # must keep its OWN drawing complete
            ok = False
            detail.append(f"{f['label']} lost part of its own drawing")
    print(("PASS  " if ok else "FAIL  ") + name, "; ".join(detail))
    return ok


def main():
    if len(sys.argv) > 1:                                             # audit mode for a real PDF
        figs = figures.find_figures(sys.argv[1])
        bad = [f for f in figs if "WARNING" in f.get("note", "")]
        for f in bad:
            print("CHECK", f["label"], f["note"])
        print(f"{len(figs)} figures, {len(bad)} flagged")
        return 0 if not bad else 1
    results = [
        _check("stacked figures with numerals in the gap", os.path.join(TMP, "a.pdf"), _sheet_stacked(os.path.join(TMP, "a.pdf"))),
        _check("side-by-side figures with interleaved numerals", os.path.join(TMP, "b.pdf"), _sheet_side_by_side(os.path.join(TMP, "b.pdf"))),
    ]
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
