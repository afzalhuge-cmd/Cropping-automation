"""Self-test: a table that runs over several pages is saved as TABLE 1, TABLE 1.1, TABLE 1.2 ...
and a ruled table is cut at its own ruling, not at the paragraph text around it.  Run:  py test_tablecont.py"""
import os, tempfile, fitz, figures

def grid(page, x0, y0, x1, y1, rows):
    ys = [y0 + (y1 - y0) * i / rows for i in range(rows + 1)]
    for y in ys:
        page.draw_line((x0, y), (x1, y), width=0.7)
    for x in (x0, (x0 + x1) / 2, x1):
        page.draw_line((x, y0), (x, y1), width=0.7)
    for i in range(rows):
        page.insert_text((x0 + 6, ys[i] + 14), f"row {i}", fontsize=9)

doc = fitz.open()
p1 = doc.new_page()
for k in range(8):
    p1.insert_text((72, 80 + 14 * k), "Body text of the description goes here and here and here.", fontsize=10)
p1.insert_text((150, 215), "Table 1: Exemplary samples", fontsize=11)
grid(p1, 100, 225, 500, 700, 6)                                   # runs to the bottom of the page
p1.insert_text((290, 790), "- 8 -", fontsize=9)
p2 = doc.new_page()
grid(p2, 100, 80, 500, 300, 3)                                    # no caption: continues Table 1
p2.insert_text((72, 340), "Another paragraph after the table, long enough to count as text.", fontsize=10)
p2.insert_text((150, 380), "Table 2: A separate table", fontsize=11)
grid(p2, 100, 390, 500, 500, 2)
p3 = doc.new_page()
p3.insert_text((72, 100), "Text only page.", fontsize=10)
path = os.path.join(tempfile.mkdtemp(), "t.pdf")
doc.save(path)
got = [(t["label"], t["page"], t["filename"]) for t in figures.find_tables(path, skip_pages=())]
want = [("TABLE 1", 1, "table_001.jpg"), ("TABLE 1.1", 2, "table_001_1.jpg"), ("TABLE 2", 2, "table_002.jpg")]
ok = got == want
print(("PASS " if ok else "FAIL ") + str(got))
raise SystemExit(0 if ok else 1)
