"""
Tests for the Tesseract + OpenCV OCR (ocr_engine.py) and the figure finder on picture-only drawings.

    py test_ocr.py

Skipped (not failed) when Tesseract is not installed.
"""
import os
import sys
import tempfile

import numpy as np

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz
import cv2

import detector
import figures
import ocr_engine
import test_detector as T

W, H = 595, 842
FONT = cv2.FONT_HERSHEY_SIMPLEX
results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (("   " + detail) if detail else ""))


def label(img, text, org, scale=1.1):
    cv2.putText(img, text, org, FONT, scale, (0, 0, 0), 2, cv2.LINE_AA)


def figure_art(img, x, y, w, h, seed):
    """Something that looks like a technical drawing: boxes, circles, hatching."""
    rng = np.random.RandomState(seed)
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 0), 3)
    for _ in range(6):
        cx, cy = x + rng.randint(40, w - 40), y + rng.randint(40, h - 40)
        cv2.circle(img, (cx, cy), rng.randint(15, 35), (0, 0, 0), 2)
    for k in range(0, w, 22):
        cv2.line(img, (x + k, y), (x + k + h // 2, y + h), (90, 90, 90), 1)


def png(img):
    return cv2.imencode(".png", img)[1].tobytes()


def page_with_picture(img, pic_rect, header=True, captions=False):
    d = fitz.open()
    p = d.new_page(width=W, height=H)
    if header:
        p.insert_text((60, 60), "APPLICANT NAME   SHEET 1 / 1", fontsize=10, fontname="helv")
    p.insert_image(pic_rect, stream=png(img))
    if captions:   # long caption text under the picture, like the real filing
        y = pic_rect.y1 + 30
        for i in range(1, 6):
            p.insert_text((70, y), f"Figure {i}: Illustrates the view number {i} of the device showing the "
                                   f"outer shell, the layers and the core arrangement in detail.",
                          fontsize=8.5, fontname="helv")
            y += 16
    return d


def centre_in(rect, c):
    return rect.x0 <= c[0] <= rect.x1 and rect.y0 <= c[1] <= rect.y1


def verify_crops(figs, centres, tag):
    """every crop holds its own label and no other label"""
    ok = len(figs) == len(centres)
    detail = f"found {len(figs)} of {len(centres)}"
    if ok:
        for f in figs:
            r = fitz.Rect(*f["crop"])
            own = centre_in(r, centres[f["label"]])
            foreign = [k for k, c in centres.items() if k != f["label"] and centre_in(r, c)]
            if not own or foreign:
                ok = False
                detail += f"  {f['label']}: own={own} foreign={foreign}"
    check(tag, ok, detail)


# --------------------------------------------------------------------------
def test_label_matcher_tolerates_ocr_noise():
    """Tesseract often reads the dash after 'FIG. 3' as ~ or a doubled dash (seen on a real filing)."""
    ok = True
    for text, num in [("FIG. 3 ~ CROSS-SECTIONAL VIEW (SECTION A-A)", 3), ("FIG. 3 \u2014- CROSS-SECTIONAL VIEW", 3),
                      ("FIG. 5 \u2014", 5), ("FIG. 2 - TOP AND BOTTOM VIEWS", 2), ("FIG. 4 _ CORE", 4)]:
        got = figures._labels_in_lines([{"text": text, "x0": 0, "y0": 0, "x1": 100, "y1": 10}])
        if not got or got[0]["num"] != num:
            ok = False
            print("      not recognised:", text)
    prose = figures._labels_in_lines([{"text": "FIG. 3 is a sectional view of the device taken along line A-A of the", "x0": 0, "y0": 0, "x1": 100, "y1": 10}])
    check("label matcher: noisy dashes accepted, prose sentences still ignored", ok and not prose)


def test_missing_tesseract():
    saved = (dict(ocr_engine._STATE), ocr_engine._candidate_paths)
    try:
        ocr_engine._STATE.update({"exe": None, "error": None, "version": ""})
        ocr_engine._candidate_paths = lambda: []
        ok, msg = ocr_engine.available()
        check("missing Tesseract -> friendly message", (not ok) and "install" in msg.lower(), msg[:70])
        # a scanned PDF must not crash; it must warn
        tmp = tempfile.mkdtemp()
        src = os.path.join(tmp, "s.pdf")
        d = T.Doc()
        d.text_page([("h", "ABSTRACT"), ("p", T.para(60))])
        d.save(src)
        s = fitz.open(src)
        out = fitz.open()
        for pg in s:
            np_ = out.new_page(width=pg.rect.width, height=pg.rect.height)
            np_.insert_image(np_.rect, pixmap=pg.get_pixmap(dpi=100))
        path = os.path.join(tmp, "scan.pdf")
        out.save(path)
        r = detector.analyze_pdf(path, use_ocr=True)
        check("scanned PDF + no Tesseract -> warning, no crash", any("OCR" in w for w in r["warnings"]),
              "; ".join(r["warnings"])[:80])
    finally:
        ocr_engine._STATE.clear()
        ocr_engine._STATE.update(saved[0])
        ocr_engine._candidate_paths = saved[1]


def degrade(g, seed=0):
    h, w = g.shape
    out = cv2.warpAffine(g, cv2.getRotationMatrix2D((w / 2, h / 2), 1.5, 1), (w, h), borderValue=255)
    yy, xx = np.mgrid[0:h, 0:w]
    out = out.astype(np.float32) * (0.55 + 0.45 * xx / w)             # shadow on the left
    out += np.random.RandomState(seed).normal(0, 14, out.shape)
    out = np.clip(out, 0, 255).astype(np.uint8)
    return cv2.imdecode(cv2.imencode(".jpg", out, [cv2.IMWRITE_JPEG_QUALITY, 50])[1], 0)


def test_bad_scan_ranges():
    tmp = tempfile.mkdtemp()
    src = os.path.join(tmp, "g.pdf")
    d = T.Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", T.para(80)), ("h", "BACKGROUND OF THE INVENTION"), ("p", T.para(80))])
    d.text_page([("h", "DETAILED DESCRIPTION OF THE INVENTION"), ("p", T.para(200))])
    d.text_page(T.claims_page(1))
    d.text_page([("h", "ABSTRACT"), ("p", T.para(80))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(src)
    s = fitz.open(src)
    out = fitz.open()
    for pg in s:
        pix = pg.get_pixmap(dpi=200, colorspace=fitz.csGRAY)
        g = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width)
        np_ = out.new_page(width=pg.rect.width, height=pg.rect.height)
        np_.insert_image(np_.rect, stream=cv2.imencode(".jpg", degrade(g))[1].tobytes())
    path = os.path.join(tmp, "bad_scan.pdf")
    out.save(path)
    r = detector.analyze_pdf(path, use_ocr=True)
    got = {x["TITLE"]: (x["FIRST pg.no"], x["Last Pg.no"]) for x in r["rows"]}
    exp = {"Description": (1, 2), "Claim": (3, 3), "Abstract": (4, 4), "Drawing": (5, 5)}
    check("tilted + shadowed + noisy JPEG scan: page ranges", got == exp, f"got {got}")


def test_ruled_sheet_with_text_layer():
    """Like the real filing: a header + long captions in the text layer, and ONE raster picture whose
    'FIG. n - TITLE' captions are pixels, split by ruled panel borders (3 on top, 2 below)."""
    img = np.full((1000, 1600), 255, np.uint8)
    cv2.rectangle(img, (4, 4), (1595, 995), 0, 3)
    cv2.line(img, (530, 4), (530, 600), 0, 1)
    cv2.line(img, (1070, 4), (1070, 600), 0, 1)
    cv2.line(img, (4, 600), (1595, 600), 0, 1)
    cv2.line(img, (800, 600), (800, 995), 0, 1)
    cells = {"FIG. 1": (4, 4, 530, 600), "FIG. 2": (530, 4, 1070, 600), "FIG. 3": (1070, 4, 1595, 600),
             "FIG. 4": (4, 600, 800, 995), "FIG. 5": (800, 600, 1595, 995)}
    titles = {"FIG. 1": "PERSPECTIVE VIEW", "FIG. 2": "TOP AND BOTTOM", "FIG. 3": "CROSS SECTION",
              "FIG. 4": "CORE LAYOUT", "FIG. 5": "WALL ASSEMBLY"}
    pic = fitz.Rect(40, 110, 555, 110 + 515 * 1000 / 1600)
    centres = {}
    for k, (x0, y0, x1, y1) in cells.items():
        label(img, f"{k} - {titles[k]}", (x0 + 20, y0 + 50), 0.9)
        figure_art(img, x0 + 40, y0 + 90, (x1 - x0) - 80, (y1 - y0) - 140, seed=len(k) + x0)
        # label centre in page points
        centres[k] = (pic.x0 + (x0 + 160) / 1600 * pic.width, pic.y0 + (y0 + 40) / 1000 * pic.height)
    d = page_with_picture(img, pic, captions=True)
    path = os.path.join(tempfile.mkdtemp(), "ruled.pdf")
    d.save(path)
    words = sum(len(l["text"].split()) for l in detector._page_lines(fitz.open(path)[0], False)[0])
    figs = figures.find_figures(path, use_ocr=True, skip_pages=set())
    check(f"text layer has {words} words (the old '<60 words' rule would skip OCR)", words > 60)
    verify_crops(figs, centres, "ruled picture: 5 figures found, cut along the borders")
    check("notes say 'panel borders'", all("panel borders" in f["note"] for f in figs) and bool(figs))
    off = figures.find_figures(path, use_ocr=False, skip_pages=set())
    check("without OCR: one flagged whole-picture crop, no invented panels",
          len(off) == 1 and off[0]["note"] == figures.UNLABELED_NOTE, str([(f["label"], f["note"][:25]) for f in off]))


def test_unruled_sheet_labels_below():
    """No borders at all; four drawings in a 2 x 2 arrangement, bare 'FIG. n' printed under each."""
    img = np.full((1000, 1400), 255, np.uint8)
    spots = {"FIG. 1": (80, 60), "FIG. 2": (760, 60), "FIG. 3": (80, 520), "FIG. 4": (760, 520)}
    pic = fitz.Rect(40, 120, 555, 120 + 515 * 1000 / 1400)
    centres, art = {}, {}
    for k, (x, y) in spots.items():
        figure_art(img, x, y, 520, 330, seed=x + y)
        label(img, k, (x + 200, y + 400), 1.3)
        centres[k] = (pic.x0 + (x + 245) / 1400 * pic.width, pic.y0 + (y + 380) / 1000 * pic.height)
        art[k] = (pic.x0 + (x + 260) / 1400 * pic.width, pic.y0 + (y + 165) / 1000 * pic.height)
    d = page_with_picture(img, pic, header=False)
    path = os.path.join(tempfile.mkdtemp(), "unruled.pdf")
    d.save(path)
    figs = figures.find_figures(path, use_ocr=True, skip_pages=set())
    verify_crops(figs, centres, "unruled picture, labels below: 4 figures found")
    ok = len(figs) == 4 and all(centre_in(fitz.Rect(*f["crop"]), art[f["label"]]) for f in figs)
    check("each crop contains its own drawing", ok)


def test_scanned_drawing_sheet():
    """Whole page is a scan (no text layer at all)."""
    img = np.full((2339, 1654), 255, np.uint8)
    figure_art(img, 300, 500, 1000, 600, 3)
    label(img, "FIG. 1", (700, 1200), 2.2)
    figure_art(img, 300, 1400, 1000, 500, 4)
    label(img, "FIG. 2", (700, 1980), 2.2)
    cv2.putText(img, "Sheet 1 of 1", (650, 140), FONT, 1.4, 0, 3, cv2.LINE_AA)
    d = fitz.open()
    p = d.new_page(width=W, height=H)
    p.insert_image(p.rect, stream=png(degrade(img)))
    path = os.path.join(tempfile.mkdtemp(), "scan_draw.pdf")
    d.save(path)
    figs = figures.find_figures(path, use_ocr=True, skip_pages=set())
    check("scanned drawing sheet: FIG. 1 and FIG. 2 read by OCR",
          sorted(f["label"] for f in figs) == ["FIG. 1", "FIG. 2"], str([f["label"] for f in figs]))


def main():
    ok, msg = ocr_engine.available()
    if not ok:
        print("SKIPPED - Tesseract not available:", msg[:120])
        return 0
    print("OCR engine:", msg)
    test_label_matcher_tolerates_ocr_noise()
    test_missing_tesseract()
    test_bad_scan_ranges()
    test_ruled_sheet_with_text_layer()
    test_unruled_sheet_labels_below()
    test_scanned_drawing_sheet()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
