"""
Tests for the 'Sequence Listing' part (WIPO ST.26 tables / ST.25 <210> tags).

A sequence listing is the LAST PART OF THE DESCRIPTION.  The detector must
  * list it as its own row ('Sequence Listing', first/last page),
  * make the Description range include it when it closes the description (before the claims),
  * never mistake its pages for Drawing / Abstract / Claim (e.g. when it is attached after the drawings),
  * not invent a listing from a few 'SEQ ID NO' mentions or a CDR table in the description.

No OCR needed.     py test_sequence.py
"""
import os
import sys
import tempfile

import detector
import figures
import test_detector as T

results = []
RES = ["QVQLVESGGG VVQPGRSLRL SCKASGYTFT RSTMHWVRQA PGQGLEWIGY INPSSAYTNY",
       "NQKFKDRFTI SADKSKSTAF LQMDSLRPED TGVYFCARPQ VHYDYNGFPY WGQGTPVTVS"]


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (("   " + detail) if detail else ""))


def cover(d):
    d.text_page([("p", "COMPLETE SPECIFICATION  FORM-2  THE PATENTS ACT, 1970  The following specification "
                       "particularly describes the invention and the manner in which it is to be performed.")])


def st26_pages(d, n_pages=4, per_page=5, first_heading=True, stamp=None):
    """WIPO ST.26 style tables: 'Sequence Listing' heading, then 3-k-... field blocks."""
    k = 0
    for pg in range(n_pages):
        items = []
        if pg == 0 and first_heading:
            items += [("line", "Sequence Listing"), ("line", "1"), ("line", "Sequence Listing Information"),
                      ("line", "1-1"), ("line", "File Name"), ("line", "X_ST26_SequenceListing.xml")]
        for _ in range(per_page):
            k += 1
            items += [("line", f"3-{k}"), ("line", "Sequences"), ("line", f"3-{k}-1"),
                      ("line", "Sequence Number [ID]"), ("line", str(k)), ("line", f"3-{k}-2"),
                      ("line", "Molecule Type"), ("line", "AA"), ("line", f"3-{k}-3"), ("line", "Length"),
                      ("line", "120"), ("line", f"3-{k}-5"), ("line", "Residues"),
                      ("line", RES[0]), ("line", RES[1])]
        d.text_page(items[:44], footer=stamp.format(pg) if stamp else None)


def desc_pages(d, n=3):
    d.text_page([("h", "FIELD OF INVENTION:"), ("p", T.para(120)), ("h", "SUMMARY OF THE INVENTION:"), ("p", T.para(80))])
    for _ in range(n - 1):
        d.text_page([("p", T.para(220))])


def build(kind):
    d = T.Doc()
    cover(d)
    if kind == "before_claims":
        desc_pages(d, 3)
        st26_pages(d, 4)
        d.text_page(T.claims_page(1))
        d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
        d.draw_page("FIG. 1", "Sheet 1 of 2")
        d.draw_page("FIG. 2", "Sheet 2 of 2")
    elif kind == "after_drawings":
        desc_pages(d, 3)
        d.text_page(T.claims_page(1))
        d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
        d.draw_page("FIG. 1", "Sheet 1 of 2")
        d.draw_page("FIG. 2", "Sheet 2 of 2")
        st26_pages(d, 4)
    elif kind == "st25":
        desc_pages(d, 3)
        items = [("line", "SEQUENCE LISTING")]
        for i in range(1, 4):
            items += [("line", f"<210> {i}"), ("line", "<211> 60"), ("line", "<212> PRT"),
                      ("line", "<213> Artificial Sequence"), ("line", "<400> " + str(i)),
                      ("line", "gcatgcatgc atgcatgcat gcatgcatgc atgcatgcat gcatgcatgc atgcatgcat 60")]
        d.text_page(items)
        d.text_page([("line", f"<210> {i}") for i in range(4, 9)] + [("line", "<212> PRT"), ("line", "<400> 9")] +
                    [("line", "gcatgcatgc atgcatgcat gcatgcatgc atgcatgcat gcatgcatgc atgcatgcat 60")] * 4)
        d.text_page(T.claims_page(1))
        d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
        d.draw_page("FIG. 1", "Sheet 1 of 1")
    elif kind == "no_listing":
        # sequences are only MENTIONED, plus a CDR table of the kind found in antibody patents
        d.text_page([("h", "FIELD OF INVENTION:"),
                     ("p", "The antibody comprises SEQ ID NO: 5, SEQ ID NO: 6 and SEQ ID NO: 7 as described. " + T.para(100))])
        d.text_page([("line", "HCDR1 | CD3 | 143 | TYGMN"), ("line", "HCDR2 | CD3 | 135 | RIRSKYNNYATYYADSVKD"),
                     ("line", "HCDR3 | CD3 | 141 | HGNFGNSYVSWFAY"), ("p", T.para(200))])
        d.text_page([("p", T.para(220))])
        d.text_page(T.claims_page(1))
        d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
        d.draw_page("FIG. 1", "Sheet 1 of 1")
    path = os.path.join(tempfile.mkdtemp(), kind + ".pdf")
    d.save(path)
    return path


def rows_of(path):
    r = detector.analyze_pdf(path)
    return r, {x["TITLE"]: (x["FIRST pg.no"], x["Last Pg.no"]) for x in r["rows"]}


def main():
    # 1. listing closes the description (between description and claims) - like a real ST.26 filing
    r, got = rows_of(build("before_claims"))
    check("before the claims: own 'Sequence Listing' row (pages 5-8)", got.get("Sequence Listing") == (5, 8), str(got))
    check("before the claims: Description includes it (2-8), claims/abstract/drawings intact",
          got.get("Description") == (2, 8) and got.get("Claim") == (9, 9) and got.get("Abstract") == (10, 10)
          and got.get("Drawing") == (11, 12), str(got))
    desc = next(x for x in r["rows"] if x["TITLE"] == "Description")
    check("Description detection text says the listing is its last part", "Sequence Listing" in desc["Detection"],
          desc["Detection"][-70:])
    pr = {x["PDF page"]: x["Section"] for x in r["page_rows"]}
    check("page table marks the listing pages", pr[5] == "Description (Sequence Listing)" and pr[8] == "Description (Sequence Listing)"
          and pr[4] == "Description", str({k: pr[k] for k in (4, 5, 8, 9)}))

    # 2. listing attached after the drawings: cannot join the description, must not become Drawing
    r, got = rows_of(build("after_drawings"))
    check("after the drawings: separate row (pages 9-12), not swallowed by Drawing",
          got.get("Sequence Listing") == (9, 12) and got.get("Drawing") == (7, 8), str(got))
    check("after the drawings: Description unchanged (2-4)", got.get("Description") == (2, 4), str(got))
    seq = next(x for x in r["rows"] if x["TITLE"] == "Sequence Listing")
    check("row explains where it was found", "kept apart" in seq["Detection"], seq["Detection"][-70:])

    # 3. ST.25 style (<210>/<400> tags and 'SEQUENCE LISTING' heading)
    r, got = rows_of(build("st25"))
    check("ST.25 listing found (pages 5-6) and ends the description", got.get("Sequence Listing") == (5, 6)
          and got.get("Description") == (2, 6) and got.get("Claim") == (7, 7), str(got))

    # 4. false-positive guard
    r, got = rows_of(build("no_listing"))
    check("SEQ ID NO mentions + CDR table: no Sequence Listing row", "Sequence Listing" not in got, str(got))
    check("...and the other sections are still right", got.get("Description") == (2, 4) and got.get("Claim") == (5, 5),
          str(got))

    # 5. printed page numbers: table data near the edge is not a page number inside the listing
    r, got = rows_of(build("before_claims"))
    printed = {x["PDF page"]: x["Printed page"] for x in r["page_rows"]}
    check("no bogus printed numbers inside the listing", all(printed[p] == "" for p in range(5, 9)), str(printed))

    # 6. outputs: report line + figure skipping
    path = build("before_claims")
    r = detector.analyze_pdf(path)
    rep = figures.build_report("x.pdf", r["rows"], [])
    check("report has a 'Sequence Listing' line", "Sequence Listing" in rep and "pages 5" in rep.replace("\u2013", "-"))
    check("listing pages are skipped by the figure search", {5, 6, 7, 8} <= figures.pages_to_skip(r["rows"]))

    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
