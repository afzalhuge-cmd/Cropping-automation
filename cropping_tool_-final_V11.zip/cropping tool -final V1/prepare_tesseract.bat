@echo off
setlocal
title Prepare portable Tesseract folder
rem Copies an installed Tesseract into .\tesseract so build_exe.bat can pack it into the exe
rem (or so you can copy the program folder to another PC without installing anything there).
set SRC=
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" set SRC=%ProgramFiles%\Tesseract-OCR
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" set SRC=%ProgramFiles(x86)%\Tesseract-OCR
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set SRC=%LOCALAPPDATA%\Programs\Tesseract-OCR
if "%SRC%"=="" (
    echo Tesseract is not installed. Run install_tesseract.bat first.
    pause
    exit /b 1
)
echo Copying from "%SRC%" ...
if exist tesseract rmdir /s /q tesseract
mkdir tesseract
mkdir tesseract\tessdata
copy /y "%SRC%\tesseract.exe" tesseract\ >nul
copy /y "%SRC%\*.dll" tesseract\ >nul
copy /y "%SRC%\tessdata\eng.traineddata" tesseract\tessdata\ >nul
if exist "%SRC%\tessdata\configs" xcopy /e /i /y "%SRC%\tessdata\configs" tesseract\tessdata\configs >nul
if exist "%SRC%\tessdata\tessconfigs" xcopy /e /i /y "%SRC%\tessdata\tessconfigs" tesseract\tessdata\tessconfigs >nul
echo.
echo Done. The folder .\tesseract is used automatically when the program runs, and
echo build_exe.bat packs it into the exe.
pause
