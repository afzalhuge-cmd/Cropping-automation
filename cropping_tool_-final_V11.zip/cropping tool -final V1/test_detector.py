"""
Self-test for detector.py.  Builds synthetic Indian-style patent PDFs (with
deliberate traps) and checks the detected page ranges against ground truth.

Run:   py test_detector.py
"""
import os
import random
import sys
import tempfile

try:
    import pymupdf as fitz
except ImportError:
    import fitz

import detector

random.seed(7)
WORDS = ("the invention relates to a system comprising a housing a processor configured to receive "
         "signal from sensor wherein said member is coupled with an assembly for improved efficiency "
         "and reduced cost embodiment example wherein temperature controller operates valve pressure "
         "chamber inlet outlet shaft bearing motor").split()


def para(n=110):
    return " ".join(random.choice(WORDS) for _ in range(n)).capitalize() + "."


W, H = 595, 842


class Doc:
    def __init__(self):
        self.doc = fitz.open()

    def text_page(self, items, header=None, footer=None, first_y=70):
        page = self.doc.new_page(width=W, height=H)
        y = first_y
        if header:
            page.insert_text((60, 38), header, fontsize=9, fontname="helv")
        for kind, txt in items:
            if kind == "h":
                page.insert_text((60, y + 14), txt, fontsize=13, fontname="hebo")
                y += 30
            elif kind == "hplain":                       # non-bold, title case, same size
                page.insert_text((60, y + 11), txt, fontsize=11, fontname="helv")
                y += 26
            elif kind == "p":
                r = fitz.Rect(60, y, W - 60, y + 300)
                rc = page.insert_textbox(r, txt, fontsize=11, fontname="helv")
                used = 300 - rc
                y += used + 12
            elif kind == "line":
                page.insert_text((60, y + 11), txt, fontsize=11, fontname="helv")
                y += 16
        if footer:
            page.insert_text((W / 2 - 15, H - 30), footer, fontsize=9, fontname="helv")
        return page

    def draw_page(self, fig, sheet=None, header=None, shapes=True, image_only=False):
        page = self.doc.new_page(width=W, height=H)
        if header:
            page.insert_text((60, 38), header, fontsize=9, fontname="helv")
        if image_only:
            pm = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 300, 300), False)
            pm.set_rect(pm.irect, (200, 200, 200))
            page.insert_image(fitz.Rect(100, 150, 500, 550), pixmap=pm)
            return page
        if shapes:
            page.draw_rect(fitz.Rect(120, 150, 480, 400), width=1.5)
            page.draw_circle(fitz.Point(300, 275), 60, width=1)
            for k in range(6):
                page.draw_line(fitz.Point(120, 150 + 40 * k), fitz.Point(480, 150 + 40 * k))
            page.insert_text((150, 180), "102", fontsize=9)
            page.insert_text((250, 230), "104", fontsize=9)
        if fig:
            page.insert_text((270, 470), fig, fontsize=12, fontname="hebo")
        if sheet:
            page.insert_text((250, 60), sheet, fontsize=10)
        return page

    def save(self, path):
        self.doc.save(path)
        self.doc.close()


DESC_HEADINGS = [
    ("h", "TITLE OF THE INVENTION"), ("p", "A smart valve control system"),
    ("h", "FIELD OF THE INVENTION"), ("p", para(60)),
    ("h", "BACKGROUND OF THE INVENTION"),
]


def brief_drawings():
    return [("h", "BRIEF DESCRIPTION OF THE DRAWINGS"),
            ("line", "FIG. 1 illustrates a block diagram of the system."),
            ("line", "FIG. 2 shows a flow chart of the method."),
            ("line", "FIG. 3 depicts a sectional view of the valve.")]


def claims_page(start_no=1, heading="We claim:", n=6):
    items = [("h", heading)] if heading else []
    for k in range(start_no, start_no + n):
        if k == 1:
            items.append(("p", f"{k}. A system comprising a housing, a processor and a valve; " + para(35)))
        else:
            items.append(("p", f"{k}. The system as claimed in claim 1, wherein " + para(25)))
    return items


CASES = []


def case(fn):
    CASES.append(fn)
    return fn


# ---------------------------------------------------------------------------
@case
def typical_order(path):
    """Form2 cover + Description, Claims, Abstract, Drawings; traps in body text."""
    d = Doc()
    d.text_page([("line", "FORM 2"), ("line", "THE PATENTS ACT, 1970"), ("line", "THE PATENTS RULES, 2003"),
                 ("h", "COMPLETE SPECIFICATION"), ("line", "(See section 10; rule 13)")], footer="1")
    d.text_page(DESC_HEADINGS[:2] + DESC_HEADINGS[2:] + [("p", para(90))], footer="2")
    # trap: 'prior art' wrapped in a paragraph, 'claims' inside sentence
    d.text_page([("p", "As known in the art this is described in the\nprior art\nof the earlier patents "
                        "and the claims are not limited. " + para(100)),
                 ("h", "SUMMARY OF THE INVENTION"), ("p", para(120))], footer="3")
    d.text_page(brief_drawings() + [("h", "DETAILED DESCRIPTION OF THE INVENTION"), ("p", para(130))], footer="4")
    d.text_page([("p", para(200))], footer="5")
    d.text_page([("p", para(100))], footer="6")
    d.text_page(claims_page(1), footer="7")
    d.text_page(claims_page(7, heading=None, n=5) + [("line", "Dated this 12th day of May 2024")], footer="8")
    d.text_page([("h", "ABSTRACT"), ("p", para(120))], footer="9")
    for i in range(3):
        d.draw_page(f"FIG. {i+1}", f"Sheet {i+1} of 3", header="Applicant: ACME Ltd.")
    d.save(path)
    return {"Description": (2, 6), "Claim": (7, 8), "Abstract": (9, 9), "Drawing": (10, 12)}


@case
def forms_before_spec(path):
    """Form 1 / Form 3 / Form 5 in the same PDF, each with 'title of the invention'."""
    d = Doc()
    d.text_page([("line", "FORM 1"), ("line", "THE PATENTS ACT, 1970"), ("line", "APPLICATION FOR GRANT OF PATENT"),
                 ("line", "(See section 7, 54 & 135 and rule 20(1))"), ("line", "4. TITLE OF THE INVENTION: Valve"),
                 ("line", "Name of the applicant: ACME")])
    d.text_page([("line", "Signature of applicant"), ("line", "To The Controller of Patents, Patent Office, Chennai")])
    d.text_page([("line", "FORM 3"), ("line", "THE PATENTS ACT, 1970"), ("line", "STATEMENT AND UNDERTAKING"),
                 ("line", "TITLE OF THE INVENTION"), ("line", "Declaration")])
    d.text_page([("line", "FORM 5"), ("line", "DECLARATION AS TO INVENTORSHIP"), ("line", "TITLE OF THE INVENTION")])
    d.text_page([("line", "FORM 2"), ("line", "THE PATENTS ACT, 1970"), ("h", "COMPLETE SPECIFICATION"),
                 ("h", "TITLE OF THE INVENTION"), ("p", "Valve"), ("h", "FIELD OF THE INVENTION"), ("p", para(50))])
    d.text_page([("h", "BACKGROUND OF THE INVENTION"), ("p", para(200))])
    d.text_page(claims_page(1))
    d.text_page([("h", "ABSTRACT"), ("p", para(100))])
    for i in range(2):
        d.draw_page(f"FIG. {i+1}", f"Sheet {i+1} of 2")
    d.save(path)
    return {"Description": (6, 6), "Claim": (7, 7), "Abstract": (8, 8), "Drawing": (9, 10)}


@case
def abstract_first_and_shared_page(path):
    """Abstract first; claims and (no heading style) abstract... plus drawings last."""
    d = Doc()
    d.text_page([("h", "ABSTRACT"), ("p", para(110)), ("h", "TITLE OF THE INVENTION"), ("p", "Valve"),
                 ("h", "FIELD OF THE INVENTION"), ("p", para(80))])
    d.text_page([("h", "BACKGROUND OF THE INVENTION"), ("p", para(200))])
    d.text_page([("h", "SUMMARY"), ("p", para(120))])
    d.text_page([("p", para(150)), ("h", "WHAT IS CLAIMED IS:"), ("p", "1. A system comprising a housing. " + para(20)),
                 ("p", "2. The system as claimed in claim 1, wherein " + para(20))])
    d.text_page(claims_page(3, heading=None, n=4))
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Abstract": (1, 1), "Description": (1, 4), "Claim": (4, 5), "Drawing": (6, 6)}


@case
def no_drawings_shared_claim_abstract(path):
    d = Doc()
    d.text_page(DESC_HEADINGS + [("p", para(150))])
    d.text_page([("h", "DETAILED DESCRIPTION"), ("p", para(200))])
    d.text_page([("p", para(60)), ("h", "We claim:"),
                 ("p", "1. A method comprising " + para(30)),
                 ("p", "2. The method according to claim 1, wherein " + para(20)),
                 ("p", "3. The method according to claim 2, wherein " + para(20)),
                 ("h", "ABSTRACT"), ("p", para(100))])
    d.save(path)
    return {"Description": (1, 3), "Claim": (3, 3), "Abstract": (3, 3), "Drawing": None}


@case
def embedded_figure_in_description(path):
    """A description page dominated by a vector figure with a FIG caption must not be a Drawing."""
    d = Doc()
    d.text_page(DESC_HEADINGS + [("p", para(150))])
    pg = d.text_page([("h", "DETAILED DESCRIPTION OF THE INVENTION"), ("p", para(40))], first_y=70)
    pg.draw_rect(fitz.Rect(120, 300, 480, 520), width=1.5)
    for k in range(6):
        pg.draw_line(fitz.Point(120, 300 + 35 * k), fitz.Point(480, 300 + 35 * k))
    pg.insert_text((250, 560), "FIG. 2", fontsize=11)
    d.text_page([("p", para(250))])
    d.text_page(claims_page(1))
    d.text_page([("h", "ABSTRACT"), ("p", para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 2")
    d.draw_page("FIG. 2", "Sheet 2 of 2")
    d.save(path)
    return {"Description": (1, 3), "Claim": (4, 4), "Abstract": (5, 5), "Drawing": (6, 7)}


@case
def image_only_drawings(path):
    d = Doc()
    d.text_page(DESC_HEADINGS + [("p", para(200))])
    d.text_page([("p", para(250))])
    d.text_page(claims_page(1))
    d.text_page([("h", "Abstract"), ("p", para(90))])
    d.draw_page(None, image_only=True)
    d.draw_page(None, image_only=True)
    d.save(path)
    return {"Description": (1, 2), "Claim": (3, 3), "Abstract": (4, 4), "Drawing": (5, 6)}


@case
def numbered_titlecase_headings(path):
    """Headings are numbered, title case, not bold (weaker styling)."""
    d = Doc()
    d.text_page([("hplain", "1. Field of the Invention"), ("p", para(60)),
                 ("hplain", "2. Background of the Invention"), ("p", para(120))])
    d.text_page([("hplain", "3. Summary of the Invention"), ("p", para(200))])
    d.text_page([("hplain", "Claims:"), ("p", "1. A device comprising " + para(30)),
                 ("p", "2. A device as defined in claim 1 wherein " + para(30))])
    d.text_page([("hplain", "Abstract"), ("p", para(80))])
    d.draw_page("Fig. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Description": (1, 2), "Claim": (3, 3), "Abstract": (4, 4), "Drawing": (5, 5)}


@case
def scanned_ocr(path):
    """Everything rasterised (no text layer) -> needs OCR."""
    src = tempfile.mktemp(suffix=".pdf")
    d = Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(80)), ("h", "BACKGROUND OF THE INVENTION"), ("p", para(80))])
    d.text_page([("h", "DETAILED DESCRIPTION OF THE INVENTION"), ("p", para(200))])
    d.text_page(claims_page(1))
    d.text_page([("h", "ABSTRACT"), ("p", para(80))])
    d.draw_page("FIG. 1", "Sheet 1 of 2")
    d.draw_page("FIG. 2", "Sheet 2 of 2")
    d.save(src)
    s = fitz.open(src)
    out = fitz.open()
    for pg in s:
        pix = pg.get_pixmap(dpi=200)
        np_ = out.new_page(width=pg.rect.width, height=pg.rect.height)
        np_.insert_image(np_.rect, pixmap=pix)
    out.save(path)
    os.remove(src)
    return {"Description": (1, 2), "Claim": (3, 3), "Abstract": (4, 4), "Drawing": (5, 6)}


# ---------------------------------------------------------------------------
def _new_engine(path, ocr):
    r = detector.analyze_pdf(path, use_ocr=ocr)
    out = {}
    for row in r["rows"]:
        s, e = row["FIRST pg.no"], row["Last Pg.no"]
        out[row["TITLE"]] = ((s, e) if s != "" else None, row["Confidence"], row["Detection"])
    return r["n_pages"], out, r["warnings"]


def run(engine="new", verbose=True):
    fn_engine = _new_engine
    tmp = tempfile.mkdtemp()
    failures, total_sections, ok_sections = 0, 0, 0
    skipped = 0
    for fn in CASES:
        path = os.path.join(tmp, fn.__name__ + ".pdf")
        expected = fn(path)
        ocr = fn.__name__ == "scanned_ocr"
        if ocr:
            try:
                detector.get_ocr_engine()
            except Exception as exc:
                print(f"\n== {fn.__name__}   SKIPPED (Tesseract unavailable: {str(exc)[:120]})")
                skipped += 1
                continue
        n_pages, got_all, warns = fn_engine(path, ocr)
        if verbose:
            print(f"\n== {fn.__name__}   ({n_pages} pages)")
        ok_case = True
        for name in ("Abstract", "Description", "Claim", "Drawing"):
            got, conf, why = got_all[name]
            exp = expected[name]
            ok = got == exp
            ok_case &= ok
            total_sections += 1
            ok_sections += ok
            if verbose:
                print(f"  {'OK  ' if ok else 'FAIL'} {name:12s} got={got}  expected={exp}  conf={conf}  {why[:95]}")
        if verbose and warns:
            print("  warnings:", warns)
        failures += 0 if ok_case else 1
    print(f"\n[{engine}] {len(CASES) - skipped - failures}/{len(CASES) - skipped} documents fully correct, {ok_sections}/{total_sections} section ranges correct")
    return failures


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "new"
    sys.exit(1 if run(which) else 0)
