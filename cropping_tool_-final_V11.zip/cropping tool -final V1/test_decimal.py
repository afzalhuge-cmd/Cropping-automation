"""Self-test: decimal figure numbers (FIG. 1.1 ... FIG. 10.7), several captions merged in one OCR line,
OCR slips, and running text that must NOT be read as captions.   Run:  py test_decimal.py"""
import figures

def labs(*texts):
    lines = [{"text": t, "x0": 100.0 + 120 * i, "y0": 100.0, "x1": 100.0 + 120 * i + 10 * len(t), "y1": 110.0}
             for i, t in enumerate(texts)]
    return [figures.fig_label(l["num"], l["suffix"]) for l in figures._labels_in_lines(lines)]

CASES = [
    (("FIG. 1.1",), ["FIG. 1.1"]),
    (("FIG.6.1",), ["FIG. 6.1"]),
    (("FIG. 10.7",), ["FIG. 10.7"]),
    (("FIG. 8.3(100 )",), ["FIG. 8.3"]),
    (("FIG. 2A",), ["FIG. 2A"]),
    (("FIG. 1.1 FIG. 1.2",), ["FIG. 1.1", "FIG. 1.2"]),
    (("FIG. 9.0 FIG. 9.2 FIG. 9.3 FIG. 9.4",), ["FIG. 9.0", "FIG. 9.2", "FIG. 9.3", "FIG. 9.4"]),
    (("FIG. 10.6 . FIG. 10.7",), ["FIG. 10.6", "FIG. 10.7"]),
    (("FIG. 9.0 FIG. 9.2", "FIG. 91"), ["FIG. 9.0", "FIG. 9.2", "FIG. 9.1"]),     # OCR dropped the dot
    (("Contrary to figure 3.1, figures 3.2 and 3.3 illustrate that sets may",), []),
    (("Figure 3.1 shows a scissor mechanism set which has side pins",), []),
]
bad = 0
for texts, want in CASES:
    got = labs(*texts)
    ok = got == want
    bad += not ok
    print(("PASS " if ok else "FAIL ") + repr(texts) + ("" if ok else f"  got {got} want {want}"))
print(f"{len(CASES) - bad}/{len(CASES)} checks passed")
raise SystemExit(1 if bad else 0)
