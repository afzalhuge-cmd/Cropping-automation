"""
Figure finder / exporter for patent PDFs.

    python figures.py Patent.pdf [--ocr] [--out DIR] [--dpi 200]

What it does
------------
1. Finds figure labels ("FIG. 1", "FIG. 2A", "Figure 3") that stand on a line of
   their own - on drawing sheets AND on description pages that carry an embedded
   figure.
2. Finds the picture that belongs to each label ,
   and several figures that share one picture are cut apart at the labels.
3. Saves every figure as figure_001.jpg, figure_002.jpg ... (FIG. 2A -> figure_002A.jpg)
   and writes a text report in the layout

        Patent.pdf

        Abstract       -> PDF pages 2-2
        ...
        Drawing:
        FIG. 1 -> PDF page 7 -> figure_001.jpg

Scanned pages (no text layer) and drawings whose labels are part of a picture need OCR
(Tesseract + OpenCV, see ocr_engine.py) to read the labels.
"""

import os
from concurrent.futures import ThreadPoolExecutor
import re
import sys

try:
    import pymupdf as fitz  # PyMuPDF >= 1.24.3
except ImportError:  # pragma: no cover
    try:
        import fitz
    except ImportError:
        fitz = None

import detector

try:
    import cv2
    import numpy as np
except Exception:  # pragma: no cover - OCR / panel detection are optional
    cv2 = None
    np = None

ARROW = "\u2192"
DASH = "\u2013"

# "FIG. 1", "Fig 2A", "FIGURE 3(b)", "(FIG. 4)", "FIG. 1.1", "FIG.10.7", "FIG. 8.3(100)" - nothing else on the line
_NUM = r"(?P<num>\d{1,3})(?:\s*\.\s*(?P<dec>\d{1,2}))?(?:(?P<sx>[A-Za-z])|\s*\(\s*(?P<sp>[A-Za-z])\s*\))?(?:\s*\(\s*(?P<ss>[ivxIVX]{1,4})\s*\))?"
_REFNUM = r"(?:\s*\(\s*\d{1,4}\s*\))?"
_FIG_ONLY = re.compile(
    r"^\s*[.,;|'`]*\s*[\(\[]?\s*fig(?:ure)?s?\.?\s*[\-\u2013\u2014:]?\s*" + _NUM + _REFNUM +
    r"\s*[\)\]]?\s*[:.\-\u2013\u2014]?\s*$", re.I)
# "FIG. 1 - Perspective view"  (short caption after a dash / colon)
_FIG_SHORT = re.compile(
    r"^\s*fig(?:ure)?\.?\s*[\-\u2013\u2014:]?\s*" + _NUM +
    r"\s*[:\-\u2013\u2014\u2212~_=]+\s*\S.{0,60}$", re.I)
# "Figure 1 Eco Friendly Composite Sheet dimension"  (title-case caption straight after the number,
# no dash).  Must start with a capital letter, stay short and not read like a sentence
# ("Figure 2 shows ...", "Figure 1 is ...").
_FIG_TITLED = re.compile(
    r"^\s*(?i:fig(?:ure)?)\.?\s*" + _NUM + r"[ \t]+"
    r"(?!(?i:is|are|was|were|shows?|showing|illustrates?|depicts?|represents?|has|have|can|will|"
    r"also|and|or|of|in|to|at|as|on|for|with|the|a|an|that|which)\b)"
    r"[A-Z][^\n]{2,70}$")
# one caption anywhere inside an OCR line (used to cut "FIG. 1.1 FIG. 1.2" into two captions)
_FIG_ANYWHERE = re.compile(
    r"fig(?:ure)?s?\.?\s*[\-\u2013\u2014:]?\s*\d{1,3}(?:\s*\.\s*\d{1,2})?(?:[A-Za-z]\b|\s*\(\s*[A-Za-z]\s*\))?" + _REFNUM, re.I)

MAX_WORDS_DRAWING_PAGE = 150   # pages with fewer words count as "drawing-like"
NEAR_GRAPHIC_PT = 100          # a bare label must sit this close to a picture
MARGIN_PT = 8
WEAK_NOTE = "no separate picture found"


# --------------------------------------------------------------------------
# geometry helpers
# --------------------------------------------------------------------------

def _union(a, b):
    return fitz.Rect(min(a.x0, b.x0), min(a.y0, b.y0), max(a.x1, b.x1), max(a.y1, b.y1))


def _pad(r, m):
    return fitz.Rect(r.x0 - m, r.y0 - m, r.x1 + m, r.y1 + m)


def _dist(label, cand):
    """Distance from a label box to a picture box (prefers pictures directly above/below)."""
    dx = max(0.0, cand.x0 - label.x1, label.x0 - cand.x1)
    dy = max(0.0, cand.y0 - label.y1, label.y0 - cand.y1)
    return dy + (150.0 + dx if dx > 0 else 0.0)


def _merge_rects(rects, pad=8):
    rects = [fitz.Rect(r) for r in rects]
    merged = True
    while merged:
        merged = False
        out = []
        while rects:
            a = rects.pop()
            i = 0
            while i < len(rects):
                if _pad(a, pad).intersects(rects[i]):
                    a = _union(a, rects.pop(i))
                    merged = True
                    i = 0
                else:
                    i += 1
            out.append(a)
        rects = out
    return rects


def _graphic_rects(page):
    """Boxes of pictures on the page: embedded images + clustered vector drawings.

    Scanned/stitched figures often come as many thin image strips; those are kept (width >= 30,
    height >= 8) and merged first, then the merged box must be at least 30 x 30."""
    pr = page.rect
    raw = []                                  # (rect, is_image)
    try:
        for img in page.get_images(full=True):
            try:
                raw.extend((fitz.Rect(r), True) for r in page.get_image_rects(img[0]))
            except Exception:
                pass
    except Exception:
        pass
    try:
        # a white page-sized background fill would swallow every other drawing into one cluster
        draws = [d for d in page.get_drawings()
                 if not (d["rect"].width >= 0.95 * pr.width and d["rect"].height >= 0.95 * pr.height)]
        raw.extend((fitz.Rect(r), False) for r in page.cluster_drawings(drawings=draws))
    except Exception:
        pass
    clipped = []
    for r, is_img in raw:
        r = fitz.Rect(r.x0, r.y0, r.x1, r.y1)
        r.intersect(pr)
        if r.is_empty:
            continue
        if is_img:
            if r.width < 30 or r.height < 8:
                continue
        elif r.width < 30 or r.height < 30:
            continue
        elif r.width >= 0.95 * pr.width and r.height >= 0.95 * pr.height:
            continue                          # page-sized background / frame, not a picture
        clipped.append(r)
    return [r for r in _merge_rects(clipped, pad=3) if r.width >= 30 and r.height >= 30]


_SIGN_LINE = re.compile(r"agent\s+for\s+the\s+applicant|dated\s+this|\bIN/PA\b|signature", re.I)


def _raster_pictures(page, min_frac=0.08, limit=3):
    """Large embedded raster pictures (scans / images of drawings), biggest first. Their captions
    are pixels, not text, so they can only be read with OCR."""
    pr = page.rect
    rects = []
    try:
        for img in page.get_images(full=True):
            try:
                for r in page.get_image_rects(img[0]):
                    r = fitz.Rect(r)
                    r.intersect(pr)
                    if not r.is_empty:
                        rects.append(r)
            except Exception:
                pass
    except Exception:
        return []
    rects = [r for r in _merge_rects(rects, pad=3) if r.get_area() >= min_frac * pr.get_area()]
    rects.sort(key=lambda r: -r.get_area())
    return rects[:limit]


_LONE_FIG = re.compile(r"^\s*[.,;|'`]*\s*fig(?:ure)?s?\.?\s*$", re.I)


def _rescue_lone_fig(page, lines, dpi=300):
    """Sparse-mode OCR sometimes reads only "FIG" of a caption and loses the number ("FIG. 1").  Re-read a
    small strip to the right of such a word as a single line at a higher resolution."""
    out = []
    for ln in lines:
        if _LONE_FIG.match(ln["text"]):
            try:
                r = fitz.Rect(ln["x0"] - 6, ln["y0"] - 5, ln["x1"] + 80, ln["y1"] + 5)
                r.intersect(page.rect)
                gray = detector._render_gray(page, dpi, clip=r)
                items = detector.ocr_engine.ocr_image(gray, dpi, psm=7, deskew=False)
                txt = " ".join(i["text"] for i in items).strip()
                if re.match(r"^\s*fig(?:ure)?\.?\s*\d", txt, re.I):
                    ln = dict(ln)
                    ln["text"] = txt
                    ln["x1"] = max(ln["x1"], r.x0 + 6 + (items[-1]["x1"] * 72.0 / dpi if items else 0))
                    ln.pop("words", None)
            except Exception:
                pass
        out.append(ln)
    return out


def _trim_to_core(crop, core, obstacles):
    """Pull the edges of `crop` in so it does not run into printed header / footer / signature objects that lie
    outside `core` (the drawing and its caption)."""
    c = fitz.Rect(crop)
    for o in obstacles:
        o = fitz.Rect(o)
        i = fitz.Rect(o)
        i.intersect(core)
        if not i.is_empty or not c.intersects(o):
            continue
        if o.y0 >= core.y1 - 1:
            c.y1 = min(c.y1, o.y0 - 0.5)
        elif o.y1 <= core.y0 + 1:
            c.y0 = max(c.y0, o.y1 + 0.5)
        elif o.x0 >= core.x1 - 1:
            c.x1 = min(c.x1, o.x0 - 0.5)
        elif o.x1 <= core.x0 + 1:
            c.x0 = max(c.x0, o.x1 + 0.5)
    return c if not c.is_empty else fitz.Rect(crop)


def _ocr_ready():
    try:
        detector.ocr_engine.find_tesseract()
        return True
    except Exception:
        return False


def _vector_picture(page, min_paths=150):
    """A drawing sheet whose figure is VECTOR artwork (lettering such as "FIG. 1" and the numerals are drawn
    as outlines, so there is no text layer to read).  Returns one rect around all the vector artwork,
    or None when the page has too little of it."""
    pr = page.rect
    try:
        ds = [d for d in page.get_drawings()
              if not (d["rect"].width >= 0.95 * pr.width and d["rect"].height >= 0.95 * pr.height)]
    except Exception:
        return None
    if len(ds) < min_paths:
        return None
    u = fitz.Rect(ds[0]["rect"])
    for d in ds[1:]:
        u |= fitz.Rect(d["rect"])
    u.intersect(pr)
    if u.is_empty or u.get_area() < 0.08 * pr.get_area():
        return None
    return u


def _ocr_pictures(page):
    """Areas whose captions are pixels or outlines and must be OCR'd: big raster pictures + the vector artwork."""
    pics = list(_raster_pictures(page))
    vec = _vector_picture(page)
    if vec is not None and not any(_overlap_frac(vec, p) > 0.6 for p in pics):
        pics.append(vec)
    return pics


def _overlap_frac(a, b):
    i = fitz.Rect(a)
    i.intersect(b)
    if i.is_empty:
        return 0.0
    return i.get_area() / max(min(a.get_area(), b.get_area()), 1e-6)


_FURNITURE = re.compile(r"digitally\s+signed|agent\s+for\s+the\s+applicant|\bIN/PA\b|reg\.?\s*no|"
                        r"no\.?\s+of\s+sheets?|sheet\s+no|dated\s+this|applicant", re.I)


def _trim_page_furniture(page, lab, graphics, lines, extra_obst=()):
    """Pull the crop edges in so that sheet header (\"No of Sheets : 6\"), applicant name and the signature
    block ( \"DIGITALLY SIGNED ... Agent for the applicants\") are not in the figure image.  Only text that lies
    OUTSIDE the figure's own drawing(s) and caption is trimmed away."""
    crop = fitz.Rect(lab["crop"])
    ph = page.rect.height
    core = fitz.Rect(lab["rect"])
    for g in graphics:
        i = fitz.Rect(g)
        i.intersect(crop)
        if not i.is_empty and i.get_area() >= 0.2 * min(fitz.Rect(g).get_area(), crop.get_area()):
            core |= i
    obst = []
    for ln in lines:
        r = fitz.Rect(ln["x0"], ln["y0"], ln["x1"], ln["y1"])
        if _FURNITURE.search(ln["text"]) or ln["y1"] < 0.085 * ph or ln["y0"] > 0.915 * ph:
            obst.append(r)
    obst += [fitz.Rect(r) for r in extra_obst if not fitz.Rect(r).intersects(fitz.Rect(lab["rect"]))]    # handwritten signature pictures
    if not obst:
        return crop
    out = _trim_to_core(crop, core, obst)
    # a figure that lost most of its crop must not be touched - keep the original
    return out if out.get_area() >= 0.6 * crop.get_area() else crop


def _drop_signature_graphics(graphics, lines):
    """Handwritten signatures (small image next to 'Dr. X / IN/PA-... / Agent for the Applicant')
    are not drawings."""
    sign = [fitz.Rect(l["x0"], l["y0"], l["x1"], l["y1"]) for l in lines
            if _SIGN_LINE.search(l["text"])]
    if not sign:
        return graphics
    keep = []
    for g in graphics:
        small = g.width < 200 and g.height < 100
        if small and any(_pad(g, 70).intersects(r) for r in sign):
            continue
        keep.append(g)
    return keep


def _grow_with_callouts(g, lines, page_rect, reach=60, others=()):
    """Reference numerals (112, 120a ...) are text, not vector art: pull short text lines that
    sit around the picture into its box so the crop does not cut them off.

    `others` = the other pictures of the sheet.  A numeral is only taken when THIS picture is the nearest
    one to it and it does not sit on another picture - otherwise the crop of one figure would creep
    (numeral after numeral) into the figure printed next to it and two figures end up in one image."""
    g = fitz.Rect(g)
    others = [fitz.Rect(o) for o in others]
    changed = True
    while changed:
        changed = False
        for ln in lines:
            t = ln["text"].strip()
            if not t or len(t) > 8 or len(t.split()) > 2:
                continue
            if not any(ch.isdigit() for ch in t):
                continue
            if _FIG_ONLY.match(t) or _FIG_SHORT.match(t):   # a caption is not a callout
                continue
            r = fitz.Rect(ln["x0"], ln["y0"], ln["x1"], ln["y1"])
            if r.intersects(g):
                continue
            if not _pad(g, reach).intersects(r):
                continue
            if others:
                if any(r.intersects(o) for o in others):    # it belongs to the neighbouring picture
                    continue
                mine = _gap((g.x0, g.y0, g.x1, g.y1), (r.x0, r.y0, r.x1, r.y1))
                if any(_gap((o.x0, o.y0, o.x1, o.y1), (r.x0, r.y0, r.x1, r.y1)) < mine for o in others):
                    continue                                 # a neighbouring picture is closer
            g = _union(g, r)
            changed = True
    g.intersect(page_rect)
    return g


def _grow_all_with_callouts(graphics, lines, page_rect, reach=60):
    return [_grow_with_callouts(g, lines, page_rect, reach, others=[o for k, o in enumerate(graphics) if o is not g])
            for g in graphics]

# --------------------------------------------------------------------------
# label detection
# --------------------------------------------------------------------------

_SPLIT_LABEL = re.compile(r"^FIGS?\.?\s*([A-Za-z])$", re.I)


def _repair_split_labels(lines):
    """Some PDFs store 'FIG. 3D' as 'FIG. D' + a separate '3' (digit sitting inside the label box).
    Re-join them so the caption is recognised."""
    out = list(lines)
    for ln in lines:
        m = _SPLIT_LABEL.match(ln["text"].strip())
        if not m:
            continue
        for other in out:
            if other is ln:
                continue
            t = other["text"].strip()
            if not t.isdigit() or len(t) > 2:
                continue
            inside_x = ln["x0"] - 4 <= other["x0"] <= ln["x1"] + 4
            same_y = abs((other["y0"] + other["y1"]) / 2 - (ln["y0"] + ln["y1"]) / 2) < 12
            if inside_x and same_y:
                ln["text"] = f"FIG. {t}{m.group(1).upper()}"
                out.remove(other)
                break
    return out


def _split_multi_labels(lines):
    """OCR often returns the captions of a whole row as ONE line ("FIG. 1.1 FIG. 1.2",
    "FIG. 9.0 FIG. 9.1 FIG. 9.2 FIG. 9.3").  Cut such a line into one pseudo-line per caption,
    sharing the line's width in proportion to the characters."""
    out = []
    for ln in lines:
        text = ln["text"]
        ms = list(_FIG_ANYWHERE.finditer(text))
        # only a line that is nothing but captions is cut; a sentence such as
        # "figures 3.2 and 3.3 illustrate ..." is running text and must stay whole
        residue = _FIG_ANYWHERE.sub(" ", text)
        if len(ms) < 2 or re.search(r"[A-Za-z0-9]", residue):
            out.append(ln)
            continue
        n = max(len(text), 1)
        w = ln["x1"] - ln["x0"]
        spans = None
        words = ln.get("words")
        if words and " ".join(t for _a, _b, t in words) == text:     # exact word boxes from OCR
            spans, pos = [], 0
            for a, b, t in words:
                spans.append((pos, pos + len(t), a, b))
                pos += len(t) + 1
        for k, m in enumerate(ms):
            end = ms[k + 1].start() if k + 1 < len(ms) else len(text)
            part = dict(ln)
            part["text"] = text[m.start():end].strip(" .,;|")
            part.pop("words", None)
            hit = [sp for sp in spans if sp[0] < end and sp[1] > m.start()] if spans else []
            if hit:
                part["x0"], part["x1"] = min(sp[2] for sp in hit), max(sp[3] for sp in hit)
            else:
                part["x0"] = ln["x0"] + w * m.start() / n
                part["x1"] = ln["x0"] + w * max(end - 1, m.start() + 1) / n
            out.append(part)
    return out


def _normalise_decimal_labels(raw):
    """raw: [(line, m)].  OCR drops the dot now and then ("FIG. 91" for "FIG. 9.1").  On a sheet
    whose other captions are decimal (9.0, 9.2, 9.3 ...) a two-digit number whose first digit equals
    their main number is read as main.sub."""
    majors = {}
    for _ln, m in raw:
        if m.group("dec") is not None:
            majors[int(m.group("num"))] = majors.get(int(m.group("num")), 0) + 1
    fixed = []
    for ln, m in raw:
        num, dec = int(m.group("num")), m.group("dec")
        if dec is None and 10 <= num <= 99 and not (m.group("sx") or m.group("sp")):
            major, sub = divmod(num, 10)
            if major in majors:
                num, dec = major, str(sub)
        fixed.append((ln, m, num, dec))
    return fixed


_CAP_CONFUSED = re.compile(r"^(?P<pre>\W*fig(?:ure)?s?\.?\s*[\-\u2013:]?\s*)(?P<d>[SsOoIl|])(?P<s>[A-Ha-h])(?P<post>\W*)$", re.I)
_CONFUSED_DIGIT = {"S": "5", "O": "0", "I": "1", "L": "1", "|": "1"}


def _fix_confused_caption(text):
    """OCR reads the digit of a caption as a letter: 'FIG. SB' is FIG. 5B, 'FIG. IA' is FIG. 1A."""
    m = _CAP_CONFUSED.match(text)
    if not m:
        return text
    return m.group("pre") + _CONFUSED_DIGIT[m.group("d").upper()] + m.group("s").upper() + m.group("post")


def _labels_in_lines(lines):
    lines = _split_multi_labels(lines)
    raw = []
    for ln in lines:
        text = _fix_confused_caption(ln["text"])
        kind = "bare"
        m = _FIG_ONLY.match(text)
        if not m:
            m = _FIG_SHORT.match(text)
            kind = "short"
        if not m and len(text.split()) <= 10 and not text.rstrip().endswith((",", ";")):
            m = _FIG_TITLED.match(text)
            kind = "short"
        if not m:
            continue
        ln = dict(ln)
        ln["_kind"] = kind
        raw.append((ln, m))
    out = []
    for ln, m, num, dec in _normalise_decimal_labels(raw):
        letter = (m.group("sx") or m.group("sp") or "").upper()
        if m.group("ss"):                       # "2b(i)" / "2b(ii)" sub-figures
            letter += "(" + m.group("ss").lower() + ")"
        suffix = (("." + str(int(dec))) if dec is not None else "") + letter
        out.append({
            "num": num, "suffix": suffix, "kind": ln["_kind"],
            "rect": fitz.Rect(ln["x0"], ln["y0"], ln["x1"], ln["y1"]),
        })
    return out


def _suffix_key(suffix):
    m = re.match(r"^(?:\.(\d+))?(.*)$", suffix or "")
    return (int(m.group(1)) if m and m.group(1) is not None else -1, m.group(2) if m else suffix)


def fig_label(num, suffix=""):
    return f"FIG. {num}{suffix}"


def fig_filename(num, suffix=""):
    return f"figure_{num:03d}{suffix.replace('.', '_').replace('(', '_').replace(')', '')}.jpg"



# --------------------------------------------------------------------------
# several figures on one picture: cut along drawn panel borders (OpenCV)
# --------------------------------------------------------------------------

PANEL_DPI = 150


def _bands(profile, thresh, min_gap=1):
    """Runs of consecutive indices where profile >= thresh -> [(start, end)]."""
    idx = np.flatnonzero(profile >= thresh)
    if idx.size == 0:
        return []
    runs, start, prev = [], int(idx[0]), int(idx[0])
    for i in idx[1:]:
        i = int(i)
        if i - prev > min_gap:
            runs.append((start, prev))
            start = i
        prev = i
    runs.append((start, prev))
    return runs


def _border_lines(ink, box):
    """Long straight lines inside `box` -> ('h'|'v', position, thickness, coverage) list.
    Only lines spanning >= 85 % of the box count, so strokes of the drawing itself are ignored."""
    x0, y0, x1, y1 = box
    sub = ink[y0:y1, x0:x1]
    h, w = sub.shape
    out = []
    if h < 30 or w < 30:
        return out
    kh = cv2.getStructuringElement(cv2.MORPH_RECT, (max(25, int(w * 0.5)), 1))
    cov = cv2.morphologyEx(sub, cv2.MORPH_OPEN, kh).sum(axis=1) / 255.0 / w
    for a, b in _bands(cov, 0.85):
        if b - a + 1 <= 12:
            out.append(("h", (a + b) / 2.0, b - a + 1, float(cov[a:b + 1].max())))
    kv = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(25, int(h * 0.5))))
    cov = cv2.morphologyEx(sub, cv2.MORPH_OPEN, kv).sum(axis=0) / 255.0 / h
    for a, b in _bands(cov, 0.85):
        if b - a + 1 <= 12:
            out.append(("v", (a + b) / 2.0, b - a + 1, float(cov[a:b + 1].max())))
    return out


def _split_by_borders(ink, box, idxs, centers, depth=0):
    """Recursively cut `box` along full-length border lines until every piece holds one label.
    Returns [(box, [label indexes])]."""
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    lines = _border_lines(ink, box)
    # frame lines hugging the edge of the box are trimmed away, not used for cutting
    for kind, pos, th, _cov in lines:
        half = int(th / 2.0) + 1
        if kind == "h":
            if pos < 0.04 * h:
                y0 = max(y0, int(box[1] + pos + half))
            elif pos > 0.96 * h:
                y1 = min(y1, int(box[1] + pos - half))
        else:
            if pos < 0.04 * w:
                x0 = max(x0, int(box[0] + pos + half))
            elif pos > 0.96 * w:
                x1 = min(x1, int(box[0] + pos - half))
    box = (x0, y0, x1, y1)
    if len(idxs) <= 1 or depth > 6:
        return [(box, list(idxs))]
    best = None
    lines = _border_lines(ink, box)           # positions below are relative to the trimmed box
    for kind, pos, th, cov in lines:
        extent = (box[3] - box[1]) if kind == "h" else (box[2] - box[0])
        if pos < 0.04 * extent or pos > 0.96 * extent:
            continue
        cut = (box[1] if kind == "h" else box[0]) + pos
        a = [i for i in idxs if centers[i][1 if kind == "h" else 0] < cut]
        b = [i for i in idxs if centers[i][1 if kind == "h" else 0] >= cut]
        if not a or not b:
            continue
        key = (min(len(a), len(b)), cov)
        if best is None or key > best[0]:
            best = (key, kind, cut, th, a, b)
    if best is None:
        return [(box, list(idxs))]
    _key, kind, cut, th, a, b = best
    half = int(th / 2.0) + 1
    if kind == "h":
        first, second = (box[0], box[1], box[2], int(cut - half)), (box[0], int(cut + half), box[2], box[3])
    else:
        first, second = (box[0], box[1], int(cut - half), box[3]), (int(cut + half), box[1], box[2], box[3])
    return (_split_by_borders(ink, first, a, centers, depth + 1)
            + _split_by_borders(ink, second, b, centers, depth + 1))


def _runs(mask):
    """Runs of True in a 1-D boolean array -> [(start, end)]."""
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    runs, start, prev = [], int(idx[0]), int(idx[0])
    for i in idx[1:]:
        i = int(i)
        if i != prev + 1:
            runs.append((start, prev))
            start = i
        prev = i
    runs.append((start, prev))
    return runs


def _xy_cut(ink, box, idxs, centers, depth=0):
    """Recursive XY-cut: split the box at the widest blank band (rows or columns without ink) that
    puts labels on both sides. Needs no drawn borders, only whitespace between the figures.
    Returns [(box, [label indexes])]."""
    if len(idxs) <= 1 or depth > 6:
        return [(box, list(idxs))]
    x0, y0, x1, y1 = box
    sub = ink[y0:y1, x0:x1] > 0
    h, w = sub.shape
    if h < 30 or w < 30:
        return [(box, list(idxs))]
    best = None
    for axis in ("y", "x"):
        prof = sub.sum(axis=1) if axis == "y" else sub.sum(axis=0)
        extent, cross = (h, w) if axis == "y" else (w, h)
        for a, b in _runs(prof <= max(1, 0.002 * cross)):
            length = b - a + 1
            if length < max(8, 0.02 * extent) or a == 0 or b == extent - 1:
                continue
            origin = y0 if axis == "y" else x0
            cut = origin + (a + b) / 2.0
            k = 1 if axis == "y" else 0
            ga = [i for i in idxs if centers[i][k] < cut]
            gb = [i for i in idxs if centers[i][k] >= cut]
            if ga and gb and (best is None or length > best[0]):
                best = (length, axis, origin + a, origin + b, ga, gb)
    if best is None:
        return [(box, list(idxs))]
    _l, axis, a, b, ga, gb = best
    mid = (a + b) // 2                      # each figure keeps its half of the blank band
    if axis == "y":
        first, second = (x0, y0, x1, mid), (x0, mid, x1, y1)
    else:
        first, second = (x0, y0, mid, y1), (mid, y0, x1, y1)
    return _xy_cut(ink, first, ga, centers, depth + 1) + _xy_cut(ink, second, gb, centers, depth + 1)


def _split_by_labels(box, idxs, centers, depth=0):
    """Last resort: guillotine cuts halfway between the labels (largest label gap first)."""
    if len(idxs) <= 1 or depth > 8:
        return [(box, list(idxs))]
    x0, y0, x1, y1 = box
    best = None
    for k, (lo, hi) in ((0, (x0, x1)), (1, (y0, y1))):
        order = sorted(idxs, key=lambda i: centers[i][k])
        for p, q in zip(order, order[1:]):
            gap = (centers[q][k] - centers[p][k]) / max(hi - lo, 1)
            if best is None or gap > best[0]:
                best = (gap, k, (centers[p][k] + centers[q][k]) / 2.0)
    _g, k, cut = best
    ga = [i for i in idxs if centers[i][k] < cut]
    gb = [i for i in idxs if centers[i][k] >= cut]
    if k == 0:
        first, second = (x0, y0, int(cut), y1), (int(cut), y0, x1, y1)
    else:
        first, second = (x0, y0, x1, int(cut)), (x0, int(cut), x1, y1)
    return _split_by_labels(first, ga, centers, depth + 1) + _split_by_labels(second, gb, centers, depth + 1)


def _split_by_blobs(ink, box, idxs, label_boxes):
    """No border lines: merge the ink into blobs (dilation) and give every blob to the nearest
    label. Returns {label index: (x0,y0,x1,y1)} or None if one blob swallows several labels."""
    x0, y0, x1, y1 = box
    sub = ink[y0:y1, x0:x1]
    k = max(9, int(0.14 * PANEL_DPI))
    dil = cv2.dilate(sub, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    n, lab_img, stats, _c = cv2.connectedComponentsWithStats(dil, connectivity=8)
    if n <= 1:
        return None
    # which blob does each label sit in?
    owner = {}
    for i in idxs:
        lx0, ly0, lx1, ly1 = label_boxes[i]
        cx, cy = int((lx0 + lx1) / 2 - x0), int((ly0 + ly1) / 2 - y0)
        cx, cy = min(max(cx, 0), sub.shape[1] - 1), min(max(cy, 0), sub.shape[0] - 1)
        owner[i] = int(lab_img[cy, cx])
    if any(v == 0 for v in owner.values()) or len(set(owner.values())) < len(idxs):
        return None                      # label on blank paper, or two labels in one blob
    boxes = {}
    for i in idxs:
        c = owner[i]
        boxes[i] = [stats[c, 0], stats[c, 1], stats[c, 0] + stats[c, 2], stats[c, 1] + stats[c, 3]]
    for c in range(1, n):
        if c in owner.values() or stats[c, 4] < 30:
            continue
        bx0, by0, bw, bh = stats[c, 0], stats[c, 1], stats[c, 2], stats[c, 3]
        best, bd = None, 1e18
        for i in idxs:
            lx0, ly0, lx1, ly1 = (label_boxes[i][0] - x0, label_boxes[i][1] - y0,
                                  label_boxes[i][2] - x0, label_boxes[i][3] - y0)
            dx = max(0, bx0 - lx1, lx0 - (bx0 + bw))
            dy = max(0, by0 - ly1, ly0 - (by0 + bh))
            d = dx * dx + dy * dy
            if d < bd:
                best, bd = i, d
        b = boxes[best]
        b[0], b[1], b[2], b[3] = min(b[0], bx0), min(b[1], by0), max(b[2], bx0 + bw), max(b[3], by0 + bh)
    # sanity: a label that received only its own text (or a sliver) means the drawings were not
    # separated properly (they touch, or the picture is too faint for this method)
    leaf_area = float((x1 - x0) * (y1 - y0))
    if any((b[2] - b[0]) * (b[3] - b[1]) < 0.15 * leaf_area / len(idxs) for b in boxes.values()):
        return None
    return {i: (int(b[0]) + x0, int(b[1]) + y0, int(b[2]) + x0, int(b[3]) + y0) for i, b in boxes.items()}


def _panel_boxes(page, g, labs, sensitive=False):
    """Crop rectangles (PDF points) for several labels that share the picture `g`.
    Returns (list of Rect aligned with labs, how) or None.
    Methods, best first:  borders (drawn panel lines)  >  gaps (blank bands between figures)  >
    blobs (drawing grouped around each label)  >  labels (plain cut halfway between labels)."""
    if cv2 is None or np is None:
        return None
    try:
        gray = detector._render_gray(page, PANEL_DPI, clip=g)
        H, W = gray.shape
        if H < 40 or W < 40:
            return None
        # thin (1 px) panel borders need the sharp picture; the denoised one suits whitespace / blobs
        t_otsu, _bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        # a bit above Otsu so that faint / down-sampled hairline borders still count; a border must
        # span 85 % of its panel, so stippled textures inside a drawing do not turn into "lines"
        ink_lines = (gray < max(t_otsu, 205)).astype(np.uint8) * 255
        _t, ink = cv2.threshold(cv2.GaussianBlur(gray, (3, 3), 0), 0, 255,
                                cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        if sensitive:       # hairline leader lines of the reference numerals count as ink, so a cut never
            ink = (gray < 235).astype(np.uint8) * 255   # separates a numeral from the drawing it points at
        sx, sy = W / max(g.width, 1e-6), H / max(g.height, 1e-6)
        lbox = []
        for lab in labs:
            r = lab["rect"]
            lbox.append(((r.x0 - g.x0) * sx, (r.y0 - g.y0) * sy, (r.x1 - g.x0) * sx, (r.y1 - g.y0) * sy))
        centers = [((b[0] + b[2]) / 2, (b[1] + b[3]) / 2) for b in lbox]
        rank = {"borders": 0, "gaps": 1, "blobs": 2, "labels": 3}
        worst = "borders"
        out = [None] * len(labs)

        def done(box, i, how, margin):
            nonlocal worst
            out[i] = (box, margin)
            if rank[how] > rank[worst]:
                worst = how

        for box, ids in _split_by_borders(ink_lines, (0, 0, W, H), list(range(len(labs))), centers):
            if not ids:
                continue
            if len(ids) == 1:
                done(box, ids[0], "borders", 0)         # cut along drawn borders: no extra margin
                continue
            for box2, ids2 in _xy_cut(ink, box, ids, centers):
                if len(ids2) == 1:
                    done(box2, ids2[0], "gaps", 2)
                    continue
                blobs = _split_by_blobs(ink, box2, ids2, lbox)
                if blobs is not None:
                    covered = sum((b[2] - b[0]) * (b[3] - b[1]) for b in blobs.values())
                    if covered >= 0.4 * (box2[2] - box2[0]) * (box2[3] - box2[1]):
                        for i, bb in blobs.items():
                            done(bb, i, "blobs", 3)
                        continue
                for box3, ids3 in _split_by_labels(box2, ids2, centers):
                    for i in ids3:
                        done(box3, i, "labels", int(MARGIN_PT))
        if any(v is None for v in out):
            return None
        res = []
        for i, (b, margin) in enumerate(out):
            r = fitz.Rect(g.x0 + b[0] / sx, g.y0 + b[1] / sy, g.x0 + b[2] / sx, g.y0 + b[3] / sy)
            r = _union(r, labs[i]["rect"])
            res.append(_pad(r, margin) if margin else r)
        return res, worst
    except Exception:
        return None



def _split_sheet_by_components(page, g, labs, dpi=150, k=7):
    """Several figures side by side on ONE picture of a sheet (captions may be printed sideways).  Ink including the
    hairline leader lines is joined into connected components, so a reference numeral stays with the drawing its
    leader points at - even when the numerals of two neighbouring figures overlap in the same column / row band.
    Every component goes to the nearest caption.  Returns crop rects aligned with labs, or None."""
    if cv2 is None or np is None or len(labs) < 2:
        return None
    try:
        gray = detector._render_gray(page, dpi, clip=g)
        H, W = gray.shape
        sx, sy = W / max(g.width, 1e-6), H / max(g.height, 1e-6)
        ink = (gray < 235).astype(np.uint8) * 255
        cap = []
        for lab in labs:                                   # caption text is not part of any drawing
            r = lab["rect"]
            x0, y0 = max(int((r.x0 - g.x0) * sx) - 3, 0), max(int((r.y0 - g.y0) * sy) - 3, 0)
            x1, y1 = min(int((r.x1 - g.x0) * sx) + 3, W), min(int((r.y1 - g.y0) * sy) + 3, H)
            ink[y0:y1, x0:x1] = 0
            cap.append((x0, y0, x1, y1))
        dil = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
        n, _l, stats, _c = cv2.connectedComponentsWithStats(dil, connectivity=8)
        comps = [(stats[c, 4], (stats[c, 0], stats[c, 1], stats[c, 0] + stats[c, 2], stats[c, 1] + stats[c, 3]))
                 for c in range(1, n) if stats[c, 4] >= 40]
        if not comps:
            return None
        big = max(a for a, _b in comps)
        bodies = [b for a, b in comps if a >= 0.1 * big]      # the drawings themselves
        loose = [b for a, b in comps if a < 0.1 * big]        # numerals, leader fragments, dashes
        owner_of = lambda b: min(range(len(labs)), key=lambda i: _gap(b, cap[i]))
        boxes = [None] * len(labs)

        def give(i, b):
            boxes[i] = list(b) if boxes[i] is None else [min(boxes[i][0], b[0]), min(boxes[i][1], b[1]),
                                                         max(boxes[i][2], b[2]), max(boxes[i][3], b[3])]
        body_owner = [owner_of(b) for b in bodies]
        for b, i in zip(bodies, body_owner):
            give(i, b)
        for b in loose:                                       # a numeral belongs to the drawing it sits next to
            j = min(range(len(bodies)), key=lambda t: _gap(b, bodies[t]))
            give(body_owner[j], b)
        if any(b is None for b in boxes):
            return None
        out = []
        for i, b in enumerate(boxes):
            r = fitz.Rect(g.x0 + b[0] / sx, g.y0 + b[1] / sy, g.x0 + b[2] / sx, g.y0 + b[3] / sy)
            out.append(_pad(_union(r, labs[i]["rect"]), MARGIN_PT))
        for i in range(len(out)):                          # figures must not overlap each other
            for j in range(i + 1, len(out)):
                a, b2 = fitz.Rect(out[i]), fitz.Rect(out[j])
                inter = fitz.Rect(a)
                inter.intersect(b2)
                if inter.is_empty:
                    continue
                if inter.width <= inter.height:            # overlap strip is narrow in x -> split it down the middle
                    mid = (inter.x0 + inter.x1) / 2
                    if out[i].x0 < out[j].x0:
                        out[i].x1, out[j].x0 = mid, mid
                    else:
                        out[j].x1, out[i].x0 = mid, mid
                else:
                    mid = (inter.y0 + inter.y1) / 2
                    if out[i].y0 < out[j].y0:
                        out[i].y1, out[j].y0 = mid, mid
                    else:
                        out[j].y1, out[i].y0 = mid, mid
        return out
    except Exception:
        return None


# --------------------------------------------------------------------------
# many figures on one scanned sheet: grow a region around every caption (OpenCV)
# --------------------------------------------------------------------------

GROW_DPI = 100
_JUNK_LINE = re.compile(r"applicant|sheet\s*[:\-]*\s*\d|\bipo\b|mumbai|\d{1,2}\s*[-/]\s*\d{1,2}\s*[-/]\s*\d{2,4}", re.I)


def junk_rects(lines):
    """Printed sheet header ("Applicant names ... sheet 1/8"), office stamp and dates: never part of a figure."""
    return [fitz.Rect(l["x0"], l["y0"], l["x1"], l["y1"]) for l in lines if _JUNK_LINE.search(l["text"])]


def _gap(a, b):
    dx = max(0.0, a[0] - b[2], b[0] - a[2])
    dy = max(0.0, a[1] - b[3], b[1] - a[3])
    return (dx * dx + dy * dy) ** 0.5


def _agap(a, b):
    """gap between two boxes; sideways gaps count 1.6x (figures sit in columns, neighbours side by side)"""
    dx = max(0.0, a[0] - b[2], b[0] - a[2]) * 1.6
    dy = max(0.0, a[1] - b[3], b[1] - a[3])
    return (dx * dx + dy * dy) ** 0.5


def _grow_boxes(page, g, labs, junk=()):
    """Crop rectangles for >=3 captions that share one scanned picture.  Ink is merged into blobs; header,
    stamp and signature blobs (isolated, in the page margins) are dropped; every caption claims the blob
    right next to it on the side its figure is printed (above or below the caption) and then absorbs the
    nearest remaining blobs.  Returns (rects aligned with labs, 'grown') or None."""
    if cv2 is None or np is None or len(labs) < 2:
        return None
    try:
        gray = detector._render_gray(page, GROW_DPI, clip=g)
        H, W = gray.shape
        if H < 60 or W < 60:
            return None
        sx, sy = W / max(g.width, 1e-6), H / max(g.height, 1e-6)
        t_otsu, _bw = cv2.threshold(cv2.GaussianBlur(gray, (3, 3), 0), 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        ink = (cv2.GaussianBlur(gray, (3, 3), 0) < min(t_otsu, 175)).astype(np.uint8) * 255

        def px(r, pad=2):
            return (max(int((r.x0 - g.x0) * sx) - pad, 0), max(int((r.y0 - g.y0) * sy) - pad, 0),
                    min(int((r.x1 - g.x0) * sx) + pad, W), min(int((r.y1 - g.y0) * sy) + pad, H))
        for r in list(junk) + [l["rect"] for l in labs]:
            # a junk line OUTSIDE the picture (sheet header above it) gives negative pixel bounds; as a
            # slice they would blank almost the whole picture, so clamp and skip rectangles outside it
            if r.x1 < g.x0 or r.x0 > g.x1 or r.y1 < g.y0 or r.y0 > g.y1:
                continue
            x0, y0, x1, y1 = px(r)
            if x1 > x0 and y1 > y0:
                ink[max(y0, 0):y1, max(x0, 0):x1] = 0
        k = 7
        dil = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
        n, _lab, stats, _c = cv2.connectedComponentsWithStats(dil, connectivity=8)
        blobs = []
        for c in range(1, n):
            if stats[c, 4] < 70:                                  # scanner speck
                continue
            bx, by, bw, bh = stats[c, 0], stats[c, 1], stats[c, 2], stats[c, 3]
            blobs.append([g.x0 + bx / sx, g.y0 + by / sy, g.x0 + (bx + bw) / sx, g.y0 + (by + bh) / sy])
        if not blobs:
            return None
        ph = page.rect.height
        def in_margin(b):
            cy = (b[1] + b[3]) / 2
            return cy > 0.90 * ph or cy < 0.09 * ph
        # side on which each caption has its figure
        sides = []
        gaps_ba = []
        for lab in labs:
            r = lab["rect"]
            gb = ga = 1e9
            for b in blobs:
                if in_margin(b):
                    continue
                if b[2] < r.x0 - 12 or b[0] > r.x1 + 12:         # the figure sits under / over its caption
                    continue
                bc = (b[1] + b[3]) / 2
                rc = (r.y0 + r.y1) / 2
                if bc > rc:
                    gb = min(gb, max(0.0, b[1] - r.y1))
                if bc < rc:
                    ga = min(ga, max(0.0, r.y0 - b[3]))
            sides.append("below" if gb <= ga else "above")
            gaps_ba.append((gb, ga))
        # Stacked figures sit so tight that a caption is hardly closer to its own drawing than to the next one.
        # The ends of the stack decide: the bottom-most caption has nothing under it when captions are printed
        # below their figures; the top-most has nothing over it when they are printed above.
        if len(labs) >= 2:
            cys = [(l["rect"].y0 + l["rect"].y1) / 2 for l in labs]
            top_row = [i for i, c in enumerate(cys) if c <= min(cys) + 30]
            bot_row = [i for i, c in enumerate(cys) if c >= max(cys) - 30]
            top_has_above = any(gaps_ba[i][1] < 60 for i in top_row)
            bot_has_below = any(gaps_ba[i][0] < 60 for i in bot_row)
            if top_has_above and not bot_has_below:
                sides = ["above"] * len(labs)
            elif bot_has_below and not top_has_above:
                sides = ["below"] * len(labs)
        # captions of one sheet are all printed on the same side of their figures; when most of them agree,
        # a caption squeezed between two stacked figures follows the majority (seeding falls back to the
        # other side when nothing is within reach there)
        if len(sides) >= 3:
            for cand in ("below", "above"):
                if sides.count(cand) >= 0.6 * len(sides):
                    sides = [cand] * len(sides)
                    break
        U = [None] * len(labs)
        owned = [[] for _ in labs]
        free = set(range(len(blobs)))
        for i, lab in enumerate(labs):                            # seeds
            r = lab["rect"]
            rc = (r.y0 + r.y1) / 2
            best, bd = None, 1e9
            for side in (sides[i], "above" if sides[i] == "below" else "below"):
                for j in free:
                    b = blobs[j]
                    if in_margin(b) or b[2] < r.x0 - 60 or b[0] > r.x1 + 60:
                        continue
                    bc = (b[1] + b[3]) / 2
                    if (side == "below") != (bc >= rc):
                        continue
                    d = _gap(b, (r.x0, r.y0, r.x1, r.y1))
                    if d < bd:
                        best, bd = j, d
                if best is not None and bd <= 90:
                    sides[i] = side
                    break
                best, bd = None, 1e9
            if best is None:
                return None
            free.discard(best)
            owned[i].append(best)
            U[i] = list(blobs[best])
        anchors = []                                              # centre of every caption and its seed drawing
        for i in range(len(labs)):
            r = labs[i]["rect"]
            sb = blobs[owned[i][0]]
            anchors.append([((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2), ((sb[0] + sb[2]) / 2, (sb[1] + sb[3]) / 2)])

        def swallows(j, i):
            """would the box of label i, grown by blob j, enclose another figure's caption / seed drawing?"""
            b = blobs[j]
            x0, y0 = min(U[i][0], b[0]), min(U[i][1], b[1])
            x1, y1 = max(U[i][2], b[2]), max(U[i][3], b[3])
            for o in range(len(labs)):
                if o == i:
                    continue
                for (cx, cy) in anchors[o]:
                    if x0 <= cx <= x1 and y0 <= cy <= y1:
                        return True
            return False

        def cost(j, i):
            b, r = blobs[j], labs[i]["rect"]
            if swallows(j, i):
                return 1e9
            d = min(_agap(b, blobs[o]) for o in owned[i])
            if sides[i] == "below" and b[3] < r.y0 - 4:
                d *= 3
            if sides[i] == "above" and b[1] > r.y1 + 4:
                d *= 3
            return d
        orphans = []
        while free:
            best = None
            for j in free:
                for i in range(len(labs)):
                    c = cost(j, i)
                    if best is None or c < best[0]:
                        best = (c, j, i)
            c, j, i = best
            limit = 22 if in_margin(blobs[j]) else 70
            free.discard(j)
            if c > limit:
                orphans.append(j)
                continue                                          # header / stamp / signature / noise
            owned[i].append(j)
            b = blobs[j]
            U[i] = [min(U[i][0], b[0]), min(U[i][1], b[1]), max(U[i][2], b[2]), max(U[i][3], b[3])]
        # a large drawing nobody could take (e.g. two pictures joined by a callout arrow): give it to the
        # nearest caption that has it on the side where its figure is printed
        for j in orphans:
            b = blobs[j]
            if in_margin(b) or (b[2] - b[0]) * (b[3] - b[1]) < 300:
                continue
            best = None
            for i, lab in enumerate(labs):
                r = lab["rect"]
                bc, rc = (b[1] + b[3]) / 2, (r.y0 + r.y1) / 2
                if sides[i] == "below" and bc < rc:
                    continue
                if sides[i] == "above" and bc > rc:
                    continue
                d = _gap(b, (r.x0, r.y0, r.x1, r.y1))
                if d < 250 and (best is None or d < best[0]):
                    best = (d, i)
            if best:
                i = best[1]
                U[i] = [min(U[i][0], b[0]), min(U[i][1], b[1]), max(U[i][2], b[2]), max(U[i][3], b[3])]
        res = []
        for i, lab in enumerate(labs):
            r = _union(fitz.Rect(*U[i]), lab["rect"])
            res.append(_pad(r, 8))
        return res, "grown"
    except Exception:
        return None


def _split_by_caption_side(g, labs):
    """Several figures stacked in ONE picture (a scan holding Fig. 6 and Fig. 7): every caption is printed on
    the same side of its figure, so cut right after each caption (caption below) or right before it
    (caption above).  Blank-band cutting alone can slice through a figure that has a white strip inside it
    (e.g. the label strip of a photo).  Returns boxes aligned with labs, or None when the layout is not clear."""
    if len(labs) < 2:
        return None
    order = sorted(range(len(labs)), key=lambda i: labs[i]["rect"].y0)
    rs = [labs[i]["rect"] for i in order]
    if any(rs[k + 1].y0 - rs[k].y1 < 30 for k in range(len(rs) - 1)):
        return None                                     # side by side or too close: not stacked
    h = max(g.height, 1.0)
    first_top = (rs[0].y0 - g.y0) / h
    last_bot = (g.y1 - rs[-1].y1) / h
    boxes = [None] * len(labs)
    if first_top >= 0.25 and last_bot <= 0.2:           # captions below their figures
        top = g.y0
        for k, i in enumerate(order):
            bottom = min(g.y1, rs[k].y1 + 3) if k < len(rs) - 1 else g.y1
            boxes[i] = fitz.Rect(g.x0, top, g.x1, max(bottom, top + 1))
            top = bottom
        return boxes
    if first_top <= 0.15 and last_bot >= 0.25:          # captions above their figures
        for k, i in enumerate(order):
            top = rs[k].y0 - 3 if k > 0 else g.y0
            bottom = rs[k + 1].y0 - 3 if k < len(rs) - 1 else g.y1
            boxes[i] = fitz.Rect(g.x0, max(top, g.y0), g.x1, max(bottom, top + 1))
        return boxes
    return None


def _pair_by_convention(graphics, labels):
    """Sheets with several figures stacked one above the other usually print every caption on the SAME
    side of its picture (below it, rarely above).  When one of the two conventions explains the whole
    sheet - every picture has a caption on that side and every caption owns a picture - use it; the plain
    'nearest picture' rule picks the wrong one when the next picture starts close under a caption.
    Returns {id(label): union rect of its pictures} or None."""
    if len(labels) < 2 or len(graphics) < len(labels):
        return None
    labs = sorted(labels, key=lambda l: l["rect"].y0)
    if any(labs[i + 1]["rect"].y0 - labs[i]["rect"].y1 < 40 for i in range(len(labs) - 1)):
        return None                                   # captions side by side / too close: not stacked
    best = None
    for below in (True, False):
        owner = {}
        gap_total = 0.0
        ok = True
        for gi, g in enumerate(graphics):
            if below:                                 # nearest caption that starts under the picture
                cand = [(l["rect"].y0 - g.y1, k) for k, l in enumerate(labs)
                        if l["rect"].y0 >= g.y1 - 0.25 * g.height]
            else:                                     # nearest caption that ends above the picture
                cand = [(g.y0 - l["rect"].y1, k) for k, l in enumerate(labs)
                        if l["rect"].y1 <= g.y0 + 0.25 * g.height]
            if not cand:
                ok = False
                break
            gap, k = min(cand)
            owner.setdefault(k, []).append(g)
            gap_total += max(gap, 0)
        if not ok or len(owner) != len(labs):
            continue
        if best is None or gap_total < best[0]:
            best = (gap_total, owner)
    if best is None:
        return None
    out = {}
    for k, gs in best[1].items():
        r = fitz.Rect(gs[0])
        for g in gs[1:]:
            r = _union(r, g)
        out[id(labs[k])] = r
    return out


def _strip_gap(a, b):
    """Plain distance between two boxes (0 when they touch / overlap)."""
    dx = max(0.0, b.x0 - a.x1, a.x0 - b.x1)
    dy = max(0.0, b.y0 - a.y1, a.y0 - b.y1)
    return (dx * dx + dy * dy) ** 0.5


def _absorb_caption_strips(graphics, labels, max_gap=30.0):
    """A caption that is itself a small picture strip (typical for a SIDEWAYS drawing: the rotated 'FIG. 1(B)' is
    a thin image printed next to the big drawing) must not become the figure.  Such a strip is merged into the
    large picture beside it."""
    if len(graphics) < 2 or not labels:
        return graphics
    gs = [fitz.Rect(g) for g in graphics]
    biggest = max(g.get_area() for g in gs)
    changed = True
    while changed:
        changed = False
        for i, small in enumerate(gs):
            holds_label = any(small.intersects(l["rect"]) for l in labels)
            if not holds_label or small.get_area() > 0.15 * biggest:
                continue
            short, long_ = min(small.width, small.height), max(small.width, small.height)
            if short > 50 or long_ < 2.5 * short:            # only a THIN strip (a caption line), never a small figure
                continue
            if any(g is not small and g.get_area() > 0.15 * biggest and small.intersects(g) for g in gs):
                continue                                   # already part of a big picture
            near = [j for j, g in enumerate(gs)
                    if j != i and g.get_area() >= 0.5 * biggest and _strip_gap(small, g) <= max_gap]
            if not near:
                continue
            j = min(near, key=lambda k: _strip_gap(small, gs[k]))
            gs[j] = _union(gs[j], small)
            del gs[i]
            changed = True
            break
    return gs


def _assign_crops(page_rect, graphics, labels, page=None, junk=()):
    """Give every label the crop rectangle of its own figure."""
    if not graphics and page is not None:
        # a picture sliced into many thin strips (scanner / export artefact): merge the strips into one picture
        try:
            strips = [fitz.Rect(i["bbox"]) for i in page.get_image_info() if i["bbox"][2] - i["bbox"][0] > 20]
            if len(strips) >= 5:
                u = fitz.Rect(strips[0])
                for r in strips[1:]:
                    u |= r
                u.intersect(page_rect)
                if u.get_area() > 0.04 * page_rect.get_area():
                    graphics = [u]
        except Exception:
            pass
    if not graphics:
        for lab in labels:
            lab["crop"] = fitz.Rect(page_rect)
            lab["note"] = WEAK_NOTE + " - whole page saved"
        return
    graphics = _absorb_caption_strips(graphics, labels)
    paired = _pair_by_convention(graphics, labels)
    if paired:
        for lab in labels:
            r = _pad(_union(paired[id(lab)], lab["rect"]), MARGIN_PT)
            r.intersect(page_rect)
            lab["crop"] = r
        return
    groups = {}
    for lab in labels:
        best = min(range(len(graphics)), key=lambda i: _dist(lab["rect"], graphics[i]))
        groups.setdefault(best, []).append(lab)
    for idx, labs in groups.items():
        g = graphics[idx]
        if len(labs) == 1:
            r = _pad(_union(g, labs[0]["rect"]), MARGIN_PT)
            r.intersect(page_rect)
            labs[0]["crop"] = r
            continue
        # two or more figures on one picture
        _split_shared(page, g, labs, page_rect, junk)


def _center(r):
    return ((r.x0 + r.x1) / 2.0, (r.y0 + r.y1) / 2.0)


def _inside(pt, r, shrink=0.0):
    return r.x0 + shrink <= pt[0] <= r.x1 - shrink and r.y0 + shrink <= pt[1] <= r.y1 - shrink


def _split_ok(page, g, labs, rects, max_overlap=0.10, min_cover=0.85):
    """A split of one picture into one crop per figure is only accepted when
       - every crop holds its own caption,
       - no crop holds the caption of ANOTHER figure (that is two figures in one image),
       - crops do not overlap each other noticeably,
       - together the crops still cover (nearly) all the drawing ink of the picture."""
    try:
        n = len(labs)
        rs = [fitz.Rect(r) for r in rects]
        for i in range(n):
            if rs[i].is_empty or not _inside(_center(labs[i]["rect"]), _pad(rs[i], 3)):
                return False
            for j in range(n):
                if j != i and _inside(_center(labs[j]["rect"]), rs[i], shrink=1.0):
                    return False
        for i in range(n):
            for j in range(i + 1, n):
                x = fitz.Rect(rs[i])
                x.intersect(rs[j])
                if not x.is_empty and x.get_area() > max_overlap * min(rs[i].get_area(), rs[j].get_area()):
                    return False
        if np is not None:                                   # ink coverage
            gr = fitz.Rect(g)
            gr.intersect(page.rect)
            gray = detector._render_gray(page, 60, clip=gr)
            ink = gray < 200
            H, W = ink.shape
            if ink.sum() > 50:
                sx, sy = W / max(gr.width, 1e-6), H / max(gr.height, 1e-6)
                cov = np.zeros_like(ink)
                for r in rs:
                    x0, y0 = max(int((r.x0 - gr.x0) * sx), 0), max(int((r.y0 - gr.y0) * sy), 0)
                    x1, y1 = min(int((r.x1 - gr.x0) * sx) + 1, W), min(int((r.y1 - gr.y0) * sy) + 1, H)
                    if x1 > x0 and y1 > y0:
                        cov[y0:y1, x0:x1] = True
                # caption text itself is ink too, so be a little generous
                if (ink & cov).sum() < min_cover * ink.sum():
                    return False
        return True
    except Exception:
        return True


def _split_by_owned_ink(page, g, labs, dpi=150, k=7):
    """Figures side by side whose leader lines / numerals interleave (the box of one figure unavoidably overlaps the
    box of its neighbour).  Every piece of ink - drawing, leader line, numeral - is given to the figure it is
    connected to; each figure gets a COMPLETE box, and the reference numerals that belong to the NEIGHBOUR and
    fall inside that box are listed in 'blank' so they are painted white when the image is made.
    Returns (boxes, blanks) aligned with labs, or None."""
    if cv2 is None or np is None or len(labs) < 2:
        return None
    try:
        gray = detector._render_gray(page, dpi, clip=g)
        H, W = gray.shape
        sx, sy = W / max(g.width, 1e-6), H / max(g.height, 1e-6)
        ink = (gray < 235).astype(np.uint8) * 255
        cap = []
        for lab in labs:
            r = lab["rect"]
            x0, y0 = max(int((r.x0 - g.x0) * sx) - 3, 0), max(int((r.y0 - g.y0) * sy) - 3, 0)
            x1, y1 = min(int((r.x1 - g.x0) * sx) + 3, W), min(int((r.y1 - g.y0) * sy) + 3, H)
            ink[y0:y1, x0:x1] = 0
            cap.append((x0, y0, x1, y1))
        dil = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
        n, lab_img, stats, _c = cv2.connectedComponentsWithStats(dil, connectivity=8)
        comps = {c: (stats[c, 4], (stats[c, 0], stats[c, 1], stats[c, 0] + stats[c, 2], stats[c, 1] + stats[c, 3]))
                 for c in range(1, n) if stats[c, 4] >= 40}
        if not comps:
            return None
        big = max(a for a, _b in comps.values())
        bodies = {c: b for c, (a, b) in comps.items() if a >= 0.1 * big}
        loose = {c: b for c, (a, b) in comps.items() if a < 0.1 * big}
        owner = {}
        for c, b in bodies.items():
            owner[c] = min(range(len(labs)), key=lambda i: _gap(b, cap[i]))
        if len(set(owner.values())) < len(labs):
            return None                                       # a figure without a drawing of its own
        # loose ink (numerals, leader fragments, arcs) goes to the figure whose drawing is nearest in PIXELS - bounding
        # boxes are useless here because the box of one figure can wrap around a numeral of its neighbour
        body_ids = {i: [c for c in bodies if owner[c] == i] for i in range(len(labs))}
        dist = []
        for i in range(len(labs)):
            m = (np.isin(lab_img, body_ids[i]) & (ink > 0)).astype(np.uint8)
            dist.append(cv2.distanceTransform(1 - m, cv2.DIST_L2, 3))

        def nearest_fig(mask):
            if not mask.any():
                return None
            ds = [float(d[mask].min()) for d in dist]
            return int(np.argmin(ds))
        for c in loose:
            o = nearest_fig((lab_img == c) & (ink > 0))
            if o is None:
                j = min(bodies, key=lambda t: _gap(loose[c], bodies[t]))
                o = owner[j]
            owner[c] = o
        boxes = [None] * len(labs)
        for c, i in owner.items():
            b = comps[c][1]
            boxes[i] = list(b) if boxes[i] is None else [min(boxes[i][0], b[0]), min(boxes[i][1], b[1]),
                                                         max(boxes[i][2], b[2]), max(boxes[i][3], b[3])]
        # distance maps for the numerals: ALL ink owned by a figure (drawing + leader fragments), text itself excluded
        try:
            wlist = [fitz.Rect(w[:4]) for w in page.get_text("words")]
        except Exception:
            wlist = []
        text_px = np.zeros((H, W), dtype=bool)
        for wr in wlist:
            if wr.intersects(g) and not any(wr.intersects(l["rect"]) for l in labs):
                text_px[max(int((wr.y0 - g.y0) * sy) - 1, 0):min(int((wr.y1 - g.y0) * sy) + 2, H),
                        max(int((wr.x0 - g.x0) * sx) - 1, 0):min(int((wr.x1 - g.x0) * sx) + 2, W)] = True
        dist = []
        for i in range(len(labs)):
            ids_i = [c for c, o in owner.items() if o == i]
            m = (np.isin(lab_img, ids_i) & (ink > 0) & ~text_px).astype(np.uint8)
            dist.append(cv2.distanceTransform(1 - m, cv2.DIST_L2, 3) if m.any() else np.full((H, W), 1e6, np.float32))
        # ownership raster: -1 = nobody, -2 = shared / ambiguous (kept in every figure), else the figure index
        own_map = np.full((H, W), -1, dtype=np.int16)
        ink_d = cv2.dilate(ink, np.ones((3, 3), np.uint8)) > 0
        for c, i in owner.items():
            own_map[(lab_img == c) & ink_d] = i
        # reference numerals (text) -> figure whose drawing is nearest in pixels; a numeral that sits between two
        # drawings (both leader lines end at it) is ambiguous and stays in both figures
        try:
            for w in page.get_text("words"):
                wr = fitz.Rect(w[:4])
                if not wr.intersects(g) or any(wr.intersects(l["rect"]) for l in labs):
                    continue
                wx0, wy0 = max(int((wr.x0 - g.x0) * sx) - 1, 0), max(int((wr.y0 - g.y0) * sy) - 1, 0)
                wx1, wy1 = min(int((wr.x1 - g.x0) * sx) + 2, W), min(int((wr.y1 - g.y0) * sy) + 2, H)
                if wx1 <= wx0 or wy1 <= wy0:
                    continue
                wm = np.zeros((H, W), dtype=bool)
                wm[wy0:wy1, wx0:wx1] = True
                wm &= (ink_d)
                if not wm.any():
                    continue
                ds = sorted((float(d[wm].min()), i) for i, d in enumerate(dist))
                near = [i for dv, i in ds if dv <= ds[0][0] + 12.0]
                if len(near) > 1:
                    own_map[wy0:wy1, wx0:wx1][wm[wy0:wy1, wx0:wx1]] = -2
                    owners_here = near
                else:
                    own_map[wy0:wy1, wx0:wx1][wm[wy0:wy1, wx0:wx1]] = ds[0][1]
                    owners_here = [ds[0][1]]
                for o in owners_here:                          # a numeral is always inside its own figure's box
                    bx = boxes[o]
                    boxes[o] = [min(bx[0], wx0), min(bx[1], wy0), max(bx[2], wx1), max(bx[3], wy1)]
        except Exception:
            pass
        crops, masks = [], []
        for i, bx in enumerate(boxes):
            r = fitz.Rect(g.x0 + bx[0] / sx, g.y0 + bx[1] / sy, g.x0 + bx[2] / sx, g.y0 + bx[3] / sy)
            crops.append(_pad(_union(r, labs[i]["rect"]), 3))
            foreign = ((own_map >= 0) & (own_map != i)).astype(np.uint8)
            foreign = cv2.dilate(foreign, np.ones((5, 5), np.uint8)) > 0       # anti-aliased fringe
            foreign &= ~((own_map == i) | (own_map == -2))
            # a pixel of THIS figure is never erased
            own_ink = cv2.dilate((own_map == i).astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
            foreign &= ~own_ink
            masks.append(_pack_mask(foreign, g, dpi) if foreign.any() else None)
        return crops, masks
    except Exception:
        return None


def _pack_mask(arr, g, dpi):
    """Compact, comparable (tuple) form of an erase mask: (x0, y0, x1, y1, dpi, width, height, packed bytes)."""
    import zlib
    h, w = arr.shape
    return (g.x0, g.y0, g.x1, g.y1, dpi, w, h, zlib.compress(np.packbits(arr.astype(np.uint8)).tobytes(), 6))


def _apply_mask(pix, mask, sc):
    """Paint the erase-mask white on a rendered crop (pix at scale sc = dpi / 72) and return the pixmap."""
    import zlib
    x0, y0, x1, y1, mdpi, w, h, data = mask
    bits = np.unpackbits(np.frombuffer(zlib.decompress(data), dtype=np.uint8))[:w * h].reshape(h, w)
    tw, th = max(int(round((x1 - x0) * sc)), 1), max(int(round((y1 - y0) * sc)), 1)
    big = cv2.resize(bits, (tw, th), interpolation=cv2.INTER_NEAREST) > 0
    pw, ph_, n = pix.width, pix.height, pix.n
    arr = np.frombuffer(bytes(pix.samples), dtype=np.uint8).reshape(ph_, pw, n).copy()
    ox, oy = int(round(x0 * sc)) - pix.x, int(round(y0 * sc)) - pix.y
    sx0, sy0 = max(-ox, 0), max(-oy, 0)
    dx0, dy0 = max(ox, 0), max(oy, 0)
    cw, ch = min(tw - sx0, pw - dx0), min(th - sy0, ph_ - dy0)
    if cw > 0 and ch > 0:
        region = arr[dy0:dy0 + ch, dx0:dx0 + cw]
        region[big[sy0:sy0 + ch, sx0:sx0 + cw]] = 255
    return fitz.Pixmap(fitz.csRGB, pw, ph_, arr.tobytes(), False)


def _split_by_valley(page, g, labs, dpi=150):
    """Figures in ONE row (or ONE column) whose drawings / leader lines interleave so that no blank band exists:
    cut each pair of neighbours along the straight line between their captions that crosses the LEAST ink
    (and never through a reference numeral).  Returns boxes aligned with labs, or None."""
    if cv2 is None or np is None or len(labs) < 2:
        return None
    try:
        cx = [(l["rect"].x0 + l["rect"].x1) / 2 for l in labs]
        cy = [(l["rect"].y0 + l["rect"].y1) / 2 for l in labs]
        row = (max(cy) - min(cy)) < 0.15 * max(g.height, 1)
        col = (max(cx) - min(cx)) < 0.15 * max(g.width, 1)
        if row == col:
            return None
        axis = 0 if row else 1                       # 0: cut with vertical lines (x), 1: horizontal lines (y)
        gray = detector._render_gray(page, dpi, clip=g)
        H, W = gray.shape
        sx, sy = W / max(g.width, 1e-6), H / max(g.height, 1e-6)
        ink = (gray < 235).astype(np.uint8)
        for lab in labs:                              # caption text is not part of any drawing
            r = lab["rect"]
            x0, y0 = max(int((r.x0 - g.x0) * sx) - 3, 0), max(int((r.y0 - g.y0) * sy) - 3, 0)
            x1, y1 = min(int((r.x1 - g.x0) * sx) + 3, W), min(int((r.y1 - g.y0) * sy) + 3, H)
            ink[y0:y1, x0:x1] = 0
        prof = ink.sum(axis=0 if axis == 0 else 1).astype(np.float64)
        # a cut must not slice through a reference numeral (text): heavy penalty for those positions
        try:
            for w in page.get_text("words"):
                wr = fitz.Rect(w[:4])
                if not wr.intersects(g) or any(wr.intersects(l["rect"]) for l in labs):
                    continue
                a, b = ((wr.x0 - g.x0) * sx, (wr.x1 - g.x0) * sx) if axis == 0 else ((wr.y0 - g.y0) * sy, (wr.y1 - g.y0) * sy)
                prof[max(int(a), 0):max(int(b) + 1, 0)] += 400.0
        except Exception:
            pass
        k = max(3, int(0.04 * dpi))
        prof = np.convolve(prof, np.ones(k) / k, mode="same")
        order = sorted(range(len(labs)), key=lambda i: cx[i] if axis == 0 else cy[i])
        cuts = []
        for p, q in zip(order, order[1:]):
            a = cx[p] if axis == 0 else cy[p]
            b = cx[q] if axis == 0 else cy[q]
            if axis == 0:
                lo, hi = int((a - g.x0) * sx), int((b - g.x0) * sx)
            else:
                lo, hi = int((a - g.y0) * sy), int((b - g.y0) * sy)
            lo, hi = max(lo, 0), min(hi, len(prof) - 1)
            if hi - lo < 6:
                return None
            seg = prof[lo:hi + 1]
            mid = (len(seg) - 1) / 2.0
            # lowest ink; among nearly equal positions prefer the one nearest the middle
            score = seg + 0.02 * np.abs(np.arange(len(seg)) - mid) * max(seg.max(), 1.0) / max(len(seg), 1)
            pos = lo + int(np.argmin(score))
            cuts.append(g.x0 + pos / sx if axis == 0 else g.y0 + pos / sy)
        boxes = [None] * len(labs)
        for n_, i in enumerate(order):
            lo = g.x0 if n_ == 0 else cuts[n_ - 1]
            hi = g.x1 if n_ == len(order) - 1 else cuts[n_]
            r = fitz.Rect(lo, g.y0, hi, g.y1) if axis == 0 else fitz.Rect(g.x0, lo, g.x1, hi)
            boxes[i] = _union(r, labs[i]["rect"]) if axis == 1 else r
            if axis == 0:                              # caption stays inside, but never crosses the cut
                boxes[i] = fitz.Rect(boxes[i].x0, min(boxes[i].y0, labs[i]["rect"].y0), boxes[i].x1,
                                     max(boxes[i].y1, labs[i]["rect"].y1))
        return boxes
    except Exception:
        return None


def _split_by_grid(g, labs, page=None):
    """Captions laid out as a grid (2x2, 3+2 ...): cluster the captions into rows, then cut the picture
    into one band per row and one cell per caption inside the band.  Captions are assumed to sit on the
    same side (below / above) of every panel; the side is read from where the outer rows sit."""
    if len(labs) < 3:
        return None
    hs = [l["rect"].height for l in labs]
    tol = max(1.5 * (sum(hs) / len(hs)), 0.04 * g.height)
    order = sorted(labs, key=lambda l: (l["rect"].y0 + l["rect"].y1) / 2)
    rows, cur = [], [order[0]]
    for l in order[1:]:
        cy = lambda x: (x["rect"].y0 + x["rect"].y1) / 2
        if abs(cy(l) - sum(cy(x) for x in cur) / len(cur)) <= tol:
            cur.append(l)
        else:
            rows.append(cur)
            cur = [l]
    rows.append(cur)
    if len(rows) < 2 or all(len(r) == 1 for r in rows):
        return None                              # a plain stack / plain row is handled by the other methods
    top = sum((l["rect"].y0 + l["rect"].y1) / 2 for l in rows[0]) / len(rows[0])
    bot = sum((l["rect"].y0 + l["rect"].y1) / 2 for l in rows[-1]) / len(rows[-1])
    above = top <= g.y0 + 0.12 * g.height and bot < g.y1 - 0.12 * g.height
    rects = {}
    gx1 = max([g.x1] + [l["rect"].x1 for l in labs if l.get("inferred")])
    gx0 = min([g.x0] + [l["rect"].x0 for l in labs if l.get("inferred")])
    gy0 = g.y0
    if page is not None and np is not None:
        try:                                     # real extent of the drawing = where there is ink on the sheet
            area = fitz.Rect(page.rect)
            gray = detector._render_gray(page, 60, clip=area)
            ink = gray < 200
            H, W = ink.shape
            sx, sy = W / area.width, H / area.height
            ys = ink.any(axis=1)
            y_lo = int(max(g.y0 - 40, area.y0) * sy)
            y_hi = int(min(max(l["rect"].y1 for l in labs) + 4, area.y1) * sy)
            band = ink[y_lo:y_hi]
            cols = np.where(band.sum(axis=0) > 0)[0]
            if cols.size:
                # leave the page furniture (margins / sheet numbers sit in the outer 4 %)
                lo = max(cols.min() / sx + area.x0 - 3, area.x0)
                hi = min(cols.max() / sx + area.x0 + 3, area.x1)
                if hi - lo > 0.3 * area.width:
                    gx0, gx1 = min(gx0, lo) if lo < gx0 else lo, max(gx1, hi)
            # header: a short ink block (sheet number / applicant line) separated from the drawing by a blank gap
            prof = band.any(axis=1)
            runs, start = [], None
            for i, v in enumerate(prof):
                if v and start is None:
                    start = i
                if not v and start is not None:
                    runs.append((start, i)); start = None
            if start is not None:
                runs.append((start, len(prof)))
            k0 = 0
            for j in range(len(runs) - 1):       # first wide blank gap under a short block of header lines
                block_h = (runs[j][1] - runs[0][0]) / sy
                gap = (runs[j + 1][0] - runs[j][1]) / sy
                if block_h > 40:
                    break
                if gap >= 20:
                    k0 = j + 1
                    break
            if k0:
                gy0 = max(gy0, (y_lo + runs[k0][0]) / sy + area.y0 - 2)
        except Exception:
            pass
    for k, row in enumerate(rows):
        row = sorted(row, key=lambda l: l["rect"].x0)
        if above:
            y0 = min(l["rect"].y0 for l in row)
            y1 = min(l["rect"].y0 for l in rows[k + 1]) if k + 1 < len(rows) else g.y1
        else:
            y0 = max(l["rect"].y1 for l in rows[k - 1]) if k > 0 else gy0
            y1 = max(l["rect"].y1 for l in row)
        cx = [(l["rect"].x0 + l["rect"].x1) / 2 for l in row]
        cuts = [gx0] + [(cx[i] + cx[i + 1]) / 2 for i in range(len(row) - 1)] + [gx1]
        for i, l in enumerate(row):
            r = fitz.Rect(min(cuts[i], l["rect"].x0), y0, max(cuts[i + 1], l["rect"].x1), y1)
            rects[id(l)] = r
    return [rects[id(l)] for l in labs]


def _split_shared(page, g, labs, page_rect, junk=()):
    """Cut the picture `g` that several captions share into one crop per caption.  Every method's result is
    checked with _split_ok(); a result that would put two figures into one image is rejected and the next
    method is tried.  The plain cut halfway between the captions is the last resort."""
    def finish(rects, note, tight=False, blanks=None, min_cover=0.85):
        out = []
        for r in rects:
            r = fitz.Rect(r)
            r.intersect(page_rect)
            out.append(r)
        if not _split_ok(page, g, labs, out, max_overlap=0.40 if blanks else 0.10, min_cover=min_cover):
            return False
        for k_, (lab, r) in enumerate(zip(labs, out)):
            lab["crop"] = r
            lab["note"] = note
            lab["mask"] = blanks[k_] if blanks else None
            if tight:
                lab["tight"] = True            # already cut between the figures: no extra trim / padding
        return True

    # 0. drawn panel borders are the most reliable cut - tried FIRST
    ruled = _panel_boxes(page, g, labs) if page is not None else None
    if ruled and ruled[1] == "borders":
        # the drawn border lines themselves lie outside the cut boxes, so less ink is "covered"
        if finish(ruled[0], "several figures on one picture - cut along the drawn panel borders, check the crop",
                  min_cover=0.65):
            return
    # 1. captions arranged as a grid (2x2, 3+2 ...) without drawn borders: cut the picture by rows, then by columns
    if not any(l.get("rot") for l in labs):
        grid = _split_by_grid(g, labs, page)
        if grid and finish(grid, "several figures on one picture - cut as a grid of panels, check the crop"):
            return
    # 2. a SIDEWAYS sheet: blank gaps between the figures do not depend on the rotation
    if page is not None and any(l.get("rot") for l in labs):
        comp = _split_sheet_by_components(page, g, labs)
        if comp and finish(comp, "several figures on one sideways sheet - drawing kept together with its numerals, check the crop", tight=True):
            return
    # 3. blank bands between the figures (works for figures side by side AND stacked)
    found = ruled if (ruled and ruled[1] == "gaps") else None
    if found and finish(found[0], "several figures on one picture - cut at the blank space between them, check the crop"):
        return
    # 4. region grown around every caption
    grown = _grow_boxes(page, g, labs, junk) if page is not None else None
    if grown and finish(grown[0], "several figures on one sheet - drawing grown around each caption, check the crop"):
        return
    # 5. every caption is printed on the same side of its figure: cut right after / before the captions
    side = _split_by_caption_side(g, labs)
    if side and finish([_pad(_union(r, lab["rect"]), 2) for lab, r in zip(labs, side)],
                       "several figures on one picture - cut at the captions, check the crop"):
        return
    # 6a. every piece of ink goes to the figure it is connected to; the neighbour's numerals are painted white
    if page is not None and not any(l.get("rot") for l in labs):
        own = _split_by_owned_ink(page, g, labs)
        if own and finish(own[0], "several figures on one picture - each figure kept complete, neighbour's numerals removed, check the crop",
                          tight=True, blanks=own[1]):
            return
    # 6b. lowest-ink straight cut between neighbouring captions (figures side by side / stacked with interleaving leader lines)
    val = _split_by_valley(page, g, labs) if page is not None else None
    if val and finish(val, "several figures on one picture - cut where the least drawing is crossed, check the crop"):
        return
    # 6c. connected drawings: ink incl. hairline leader lines is joined, every drawing goes to its nearest caption
    #    (figures side by side whose numerals / leader lines overlap in the same column band)
    comp = _split_sheet_by_components(page, g, labs) if page is not None else None
    if comp and finish(comp, "several figures on one picture - each drawing kept with its own numerals, check the crop", tight=True):
        return
    # 7. whatever the panel finder produced (drawing blobs / halfway between labels)
    if ruled and ruled[1] in ("blobs", "labels"):
        note = {"blobs": "several figures on one picture - drawing grouped around each label, check the crop",
                "labels": "several figures on one picture - cut halfway between the labels, check the crop"}[ruled[1]]
        if finish(ruled[0], note):
            return
    # 8. last resort: cut at the labels
    cy = [(l["rect"].y0 + l["rect"].y1) / 2 for l in labs]
    same_row = (max(cy) - min(cy)) < 0.15 * max(g.height, 1)
    if same_row:
        labs.sort(key=lambda l: l["rect"].x0)
        centers = [(l["rect"].x0 + l["rect"].x1) / 2 for l in labs]
        cuts = [g.x0] + [(centers[i] + centers[i + 1]) / 2 for i in range(len(labs) - 1)] + [g.x1]
        boxes = [fitz.Rect(cuts[i], g.y0, cuts[i + 1], g.y1) for i in range(len(labs))]
    else:
        labs.sort(key=lambda l: l["rect"].y0)
        centers = [(l["rect"].y0 + l["rect"].y1) / 2 for l in labs]
        cuts = [g.y0] + [(centers[i] + centers[i + 1]) / 2 for i in range(len(labs) - 1)] + [g.y1]
        boxes = [fitz.Rect(g.x0, cuts[i], g.x1, cuts[i + 1]) for i in range(len(labs))]
    for lab, box in zip(labs, boxes):
        r = _pad(_union(box, lab["rect"]), MARGIN_PT)
        r.intersect(page_rect)
        lab["crop"] = r
        lab["note"] = "shares a picture with other figures - cut at the labels, check the crop"


def _trim_thin_overlaps(labs, page_rect, max_strip=30.0):
    """Two neighbouring figures whose crops overlap in a THIN strip (padding / numerals reaching into the
    next picture) are separated along the middle of that strip.  A caption is never cut off."""
    for i in range(len(labs)):
        for j in range(i + 1, len(labs)):
            a, b = labs[i], labs[j]
            if a.get("crop") is None or b.get("crop") is None or a.get("mask") or b.get("mask"):
                continue
            ra, rb = fitz.Rect(a["crop"]), fitz.Rect(b["crop"])
            x = fitz.Rect(ra)
            x.intersect(rb)
            if x.is_empty:
                continue
            na, nb = fitz.Rect(ra), fitz.Rect(rb)
            if x.width <= x.height and x.width <= max_strip:
                mid = (x.x0 + x.x1) / 2.0
                lo, hi = (na, nb) if ra.x0 + ra.x1 <= rb.x0 + rb.x1 else (nb, na)
                lo.x1, hi.x0 = mid, mid
            elif x.height < x.width and x.height <= max_strip:
                mid = (x.y0 + x.y1) / 2.0
                lo, hi = (na, nb) if ra.y0 + ra.y1 <= rb.y0 + rb.y1 else (nb, na)
                lo.y1, hi.y0 = mid, mid
            else:
                continue
            if (_inside(_center(a["rect"]), na) and _inside(_center(b["rect"]), nb)
                    and not na.is_empty and not nb.is_empty):
                a["crop"], b["crop"] = na, nb


def _resolve_conflicts(page, labs, page_rect, junk=()):
    """SAFETY NET, run on every sheet after all crops are made: a crop that contains the caption of another
    figure holds two figures in one image.  Such figures are re-split together (union of their crops) with the
    validated splitter, so this can never reach the output unnoticed."""
    for _round in range(3):
        n = len(labs)
        bad = set()
        for i in range(n):
            ci = labs[i].get("crop")
            if ci is None:
                continue
            for j in range(n):
                if i != j and _inside(_center(labs[j]["rect"]), ci, shrink=1.0):
                    bad.update((i, j))
        if not bad:
            return
        group = [labs[i] for i in sorted(bad)]
        region = fitz.Rect(group[0]["crop"])
        for lab in group[1:]:
            region |= lab["crop"]
        region.intersect(page_rect)
        _split_shared(page, region, group, page_rect, junk)


# --------------------------------------------------------------------------
# public API
# --------------------------------------------------------------------------


def pages_to_skip(rows):
    """Pages whose pictures are not drawings: the Abstract page(s) (figure of abstract) and the
    Sequence Listing (residue tables, never figures)."""
    skip = set()
    for r in rows:
        if r.get("TITLE") in ("Abstract", "Sequence Listing") and str(r.get("FIRST pg.no", "")).isdigit():
            a = int(r["FIRST pg.no"])
            b = int(r["Last Pg.no"]) if str(r.get("Last Pg.no", "")).isdigit() else a
            skip.update(range(a, b + 1))
    return skip


def drawing_pages_of(rows):
    """1-based pages that the section detector classified as drawing sheets."""
    pages = set()
    for r in rows:
        if r.get("TITLE") == "Drawing" and str(r.get("FIRST pg.no", "")).isdigit():
            a = int(r["FIRST pg.no"])
            b = int(r["Last Pg.no"]) if str(r.get("Last Pg.no", "")).isdigit() else a
            pages.update(range(a, b + 1))
    return pages


UNLABELED_NOTE = ("no FIG. label could be read on this drawing sheet (the picture may hold several figures - "
                  "turn OCR on to separate them) - numbered by order, please check")


def _trim_sheet_margins(page, crop, dpi=40, header_gap_pt=18.0, header_max_pt=110.0, pad_pt=10.0):
    """For a drawing that fills a whole sheet (scans / sideways drawings): drop the printed sheet header
    (\"Applicant ...\", \"41 Sheets\", \"1/41\") that sits above the picture, and the empty margins.
    Returns the new crop rect (unchanged when nothing safe can be trimmed)."""
    try:
        import numpy as np
        r = fitz.Rect(crop)
        pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72.0, dpi / 72.0), clip=r,
                              colorspace=fitz.csGRAY, alpha=False)
        a = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
        ink = a < 190
        if ink.sum() < 20:
            return crop
        k = 72.0 / dpi
        rows = ink.sum(axis=1) > 0
        ys = np.where(rows)[0]
        top = ys[0]
        # header: ink at the very top, then a blank gap, then the real picture
        gap = int(header_gap_pt / k)
        y = top
        end = None
        while y < len(rows):
            if rows[y]:
                y += 1
                continue
            run = y
            while run < len(rows) and not rows[run]:
                run += 1
            if run - y >= gap and run < len(rows):
                if (y - top) * k > header_max_pt:
                    break
                end = (y, run)           # keep looking: header lines (\"1/41\") may follow the first gap
            y = run
        if end and (end[0] - top) * k <= header_max_pt:
            ink[:end[1]] = False
        cols = np.where(ink.any(axis=0))[0]
        rws = np.where(ink.any(axis=1))[0]
        if len(cols) == 0 or len(rws) == 0:
            return crop
        out = fitz.Rect(r.x0 + cols[0] * k - pad_pt, r.y0 + rws[0] * k - pad_pt,
                        r.x0 + (cols[-1] + 1) * k + pad_pt, r.y0 + (rws[-1] + 1) * k + pad_pt)
        out.intersect(r)
        return out if out.get_area() >= 0.15 * r.get_area() else crop
    except Exception:
        return crop


# --------------------------------------------------------------------------
# figure numbers the description itself announces ("FIGS. 10A-10C are ...")
# --------------------------------------------------------------------------
_REF_RUN = re.compile(r"\bFIGS?\.?\s*((?:\d{1,3}(?:\s*\(\s*[A-Z]\s*\)|[A-Z])?(?:\s*(?:-|\u2013|\u2014|to|through|and|or|,|&)\s*)*)+)", re.I)
_REF_TOKEN = re.compile(r"(\d{1,3})([A-Z]?)", re.I)


def _expand_refs(run):
    out = set()
    run = re.sub(r"\s*\(\s*([A-Za-z])\s*\)", r"\1", run)      # "3 (a)" / "3(B)" -> "3a" / "3B"
    parts = re.split(r"\s*(?:-|\u2013|\u2014|\bto\b|\bthrough\b)\s*", run.strip(), flags=re.I)
    toks = []
    for i, part in enumerate(parts):
        group = [(int(a), b.upper()) for a, b in _REF_TOKEN.findall(re.sub(r"\b(and|or)\b|[,&]", " ", part, flags=re.I))]
        toks.append(group)
    for group in toks:
        out.update(group)
    for left, right in zip(toks, toks[1:]):
        if not left or not right:
            continue
        (n1, s1), (n2, s2) = left[-1], right[0]
        if n1 == n2 and s1 and s2 and ord(s1) < ord(s2):
            out.update((n1, chr(c)) for c in range(ord(s1), ord(s2) + 1))
        elif not s1 and not s2 and n1 < n2 <= n1 + 80:
            out.update((n, "") for n in range(n1, n2 + 1))
        elif s1 and s2 and n1 < n2 <= n1 + 80:
            out.update((n, "") for n in range(n1 + 1, n2))
    return out


def known_figure_labels(texts):
    """{(num, 'A')...} announced by the specification text (empty set when it names none)."""
    known = set()
    for t in texts:
        for m in _REF_RUN.finditer(re.sub(r"\s+", " ", t)):
            known |= _expand_refs(m.group(1))
    return known


_DIGIT_AS_LETTER = {"8": "B", "0": "D", "6": "G", "4": "A"}


def _snap_to_known(num, suffix, known):
    """An OCR misread caption (FIG. 108 for 10B) is moved to the label the description announces."""
    if not known or (num, suffix) in known or suffix.startswith("."):
        return num, suffix
    if not suffix and num >= 10 and str(num)[-1] in _DIGIT_AS_LETTER:
        cand = (int(str(num)[:-1]), _DIGIT_AS_LETTER[str(num)[-1]])
        if cand in known:
            return cand
    return num, suffix



_CONFUSABLE = {"8": "53609", "5": "86", "3": "8", "6": "850", "0": "86", "1": "7", "7": "1", "9": "8"}


def _repair_sequence(labs, known, taken):
    """Captions on one sheet are printed in number order.  A caption that breaks that order and is not
    announced by the description (e.g. FIG. 15 read as FIG. 18 between 14 and 16) is re-read with the
    digit OCR most likely confused, keeping only a number that fits the order, that the description
    announces and that is not already used.  Needs the announced set, otherwise nothing is changed."""
    if not known or len(labs) < 2:
        return
    for i, lab in enumerate(labs):
        if lab["suffix"].startswith("."):
            continue
        lo = max([l["num"] for l in labs[:i]], default=-1)
        hi = min([l["num"] for l in labs[i + 1:]], default=10 ** 6)
        if lo <= lab["num"] <= hi:
            continue
        here = {(l["num"], l["suffix"]) for l in labs}
        best = None
        s = str(lab["num"])
        for pos, ch in enumerate(s):
            for alt in _CONFUSABLE.get(ch, ""):
                cand = int(s[:pos] + alt + s[pos + 1:])
                key = (cand, lab["suffix"])
                if lo <= cand <= hi and key in known and key not in taken and key not in here:
                    if best is None or abs(cand - lo) < abs(best - lo):
                        best = cand
        if best is not None:
            lab["num"] = best
            lab["reread"] = True


def _infer_missing_letters(labs, known, graphics, page_rect):
    """A caption that OCR could not read (e.g. overlapped by an axis title) leaves a hole in the lettered
    run printed on the sheet: FIG. 7A, 7B, (7C), 7D, 7E.  When the description announces the missing letter,
    a caption is placed where it should be - on the row of the previous caption, one caption pitch further
    right (or at the start of the next row when that falls outside the picture)."""
    if not known:
        return
    by_num = {}
    for l in labs:
        if l["suffix"] and not l["suffix"].startswith(".") and len(l["suffix"]) == 1:
            by_num.setdefault(l["num"], []).append(l)
    big = max(graphics, key=lambda g: g.get_area(), default=None)
    for num, group in by_num.items():
        if len(group) < 3:
            continue
        group.sort(key=lambda l: l["suffix"])
        letters = [l["suffix"] for l in group]
        for a, b in zip(group, group[1:]):
            for code in range(ord(a["suffix"]) + 1, ord(b["suffix"])):
                ch = chr(code)
                if (num, ch) not in known or any(l["num"] == num and l["suffix"] == ch for l in labs):
                    continue
                w, h = a["rect"].width, a["rect"].height
                pitches = [abs((q["rect"].x0 + q["rect"].x1) - (p["rect"].x0 + p["rect"].x1)) / 2
                           for p, q in zip(group, group[1:])
                           if abs(p["rect"].y0 - q["rect"].y0) < 2 * h]
                pitch = sorted(pitches)[len(pitches) // 2] if pitches else w * 1.5
                x0 = a["rect"].x0 + pitch
                y0 = a["rect"].y0
                if x0 + w > page_rect.x1:                # wraps to the next row
                    x0, y0 = b["rect"].x0 - pitch, b["rect"].y0
                    if x0 < page_rect.x0:
                        continue
                new = {"num": num, "suffix": ch, "kind": "short", "pic": True, "inferred": True,
                       "rect": fitz.Rect(x0, y0, x0 + w, y0 + h)}
                labs.append(new)


def audit_overlaps(order):
    """Last line of defence: two figures of ONE sheet whose crops overlap noticeably show the same drawing twice (two
    figures in one image).  Flag them in the note so that they are never trusted blindly.  Crops that overlap on
    purpose (neighbour's numerals erased by a mask) are not flagged."""
    by_page = {}
    for f in order:
        by_page.setdefault(f["page"], []).append(f)
    for figs in by_page.values():
        for i in range(len(figs)):
            for j in range(i + 1, len(figs)):
                a, b = figs[i], figs[j]
                if a.get("mask") or b.get("mask") or a.get("rot") or b.get("rot"):
                    continue
                ra, rb = fitz.Rect(*a["crop"]), fitz.Rect(*b["crop"])
                x = fitz.Rect(ra)
                x.intersect(rb)
                if x.is_empty:
                    continue
                if x.get_area() > 0.15 * min(ra.get_area(), rb.get_area()):
                    for f, o in ((a, b), (b, a)):
                        tag = f"WARNING: crop overlaps {o['label']} - check that only one figure is in the image"
                        if tag not in f["note"]:
                            f["note"] = (f["note"] + "; " if f["note"] else "") + tag


def find_figures(pdf_path, use_ocr=False, progress=None, skip_pages=None, drawing_pages=None):
    """Return a list of figures sorted by figure number.

    Each item: label, num, suffix, page (1-based), filename, crop (x0,y0,x1,y1 in PDF points),
    note, also_on (other pages that carry the same label).

    skip_pages: 1-based page numbers to ignore (e.g. the Abstract page, whose picture is only the
    "figure of abstract" and must not be listed as a drawing).
    drawing_pages: 1-based pages the section detector says are drawing sheets.  On such a page whose
    "FIG." captions cannot be read (picture-only captions and no OCR) every substantial picture is
    still cropped, numbered by order and flagged, instead of the sheet silently giving nothing.
    """
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.  Run:  py -m pip install PyMuPDF")
    doc = detector.open_pdf(pdf_path)
    n = len(doc)
    first_seen = {}
    order = []
    skip = set(skip_pages or ())
    if skip_pages is None or drawing_pages is None:
        # no ranges supplied: still never list the picture on the Abstract page ("figure of abstract")
        try:
            rows_ = detector.analyze_pdf(pdf_path, use_ocr=use_ocr)["rows"]
            if skip_pages is None:
                skip = pages_to_skip(rows_)
            if drawing_pages is None:
                drawing_pages = drawing_pages_of(rows_)
        except Exception:
            if skip_pages is None:
                skip = set()
    drawing_pages = set(drawing_pages or ())
    known = set()
    try:                                           # figure numbers the description announces
        texts = []
        for k in range(n):
            if (k + 1) in drawing_pages or (k + 1) in skip:
                continue
            ls_, _u, _e = detector._page_lines(doc[k], use_ocr)
            texts.append(" ".join(l["text"] for l in ls_))
        known = known_figure_labels(texts)
    except Exception:
        known = set()
    unlabeled = []                                # (page number, [picture rects]) of sheets without labels
    for pno in range(n):
        if (pno + 1) in skip:
            if progress:
                progress(pno + 1, n)
            continue
        page = doc[pno]
        lines, ocr_used, _err = detector._page_lines(page, use_ocr)
        words = sum(len(l["text"].split()) for l in lines)
        _all_graphics = _graphic_rects(page)
        graphics = _drop_signature_graphics(_all_graphics, lines)
        _sig_pics = [g for g in _all_graphics if g not in graphics]
        lines = _repair_split_labels(lines)
        labels = _labels_in_lines(lines)
        # Drawing printed as a PICTURE (labels are pixels, not text) on a page that may still have a
        # text layer - e.g. a header, "Figure 1: Illustrates ..." captions or a signature block.
        # OCR just the picture area in sparse mode to read the "FIG. n" captions inside it.
        want_ocr = use_ocr
        if not labels and want_ocr and not ocr_used:
            pics = _ocr_pictures(page)
            # all pictures of the sheet are read at the same time (one Tesseract per picture)
            def _read(pic, rot=0):
                try:
                    ls = detector.ocr_rect_lines(page, pic, rot=rot)
                    if rot == 0:
                        ls = _rescue_lone_fig(page, ls)
                    return _labels_in_lines(_repair_split_labels(ls))
                except Exception:
                    return []
            _w = max(1, min(len(pics) or 1, detector.ocr_engine.worker_count()))
            with ThreadPoolExecutor(max_workers=_w) as _ex:
                results = list(_ex.map(_read, pics))
            for found in results:
                for lab in found:
                    lab["pic"] = True
                labels += found
        for lab in labels:
            lab["num"], lab["suffix"] = _snap_to_known(lab["num"], lab["suffix"], known)
        accepted = []
        for lab in labels:
            gap = min((_dist(lab["rect"], g) for g in graphics), default=1e9)
            if lab.get("pic"):                      # caption read inside a large picture: a real label
                accepted.append(lab)
            elif lab["kind"] == "bare" and (words <= MAX_WORDS_DRAWING_PAGE or gap <= NEAR_GRAPHIC_PT):
                accepted.append(lab)
            elif lab["kind"] == "short" and words <= MAX_WORDS_DRAWING_PAGE and gap <= 150:
                accepted.append(lab)
        # the same label twice on one page: keep the first
        seen_here, unique = set(), []
        for lab in sorted(accepted, key=lambda l: (l["rect"].y0, l["rect"].x0)):
            key = (lab["num"], lab["suffix"])
            if key not in seen_here:
                seen_here.add(key)
                unique.append(lab)
        _repair_sequence(unique, known, set(first_seen))
        _infer_missing_letters(unique, known, graphics, page.rect)
        unique.sort(key=lambda l: (l["num"], _suffix_key(l["suffix"])))
        graphics = _grow_all_with_callouts(graphics, lines, page.rect)
        vec = _vector_picture(page) if len(unique) == 1 else None
        if vec is not None:
            keep = [g for g in graphics if _overlap_frac(g, vec) < 0.5]     # e.g. a signature image stays out
            graphics = [vec] + keep
        if not unique and (pno + 1) in drawing_pages:
            big = [g for g in graphics if g.get_area() >= 0.04 * page.rect.get_area()]
            if big:
                unlabeled.append((pno, sorted(big, key=lambda g: (g.y0, g.x0))))
        graphics = _absorb_caption_strips(graphics, unique)      # caption printed as a thin picture beside its drawing
        _assign_crops(page.rect, graphics, unique, page=page, junk=junk_rects(lines))
        _resolve_conflicts(page, unique, page.rect, junk=junk_rects(lines))   # never two figures in one image
        _trim_thin_overlaps(unique, page.rect)
        for lab in unique:
            key = (lab["num"], lab["suffix"])
            carried = []
            if key in first_seen and (pno + 1) in drawing_pages \
                    and first_seen[key]["page"] not in drawing_pages:
                # the same figure first shows up inline in the description and again on a real
                # drawing sheet: the drawing sheet is the one that belongs in the Drawings list
                old = first_seen.pop(key)
                carried = old["also_on"] + [old["page"]]
                if old in order:
                    order.remove(old)
            if key in first_seen:
                prev = first_seen[key]
                # An earlier page only carried the bare label (e.g. the "FIG. 1" printed under the
                # abstract) and had no picture; the page that really holds the drawing wins.
                if prev["note"].startswith(WEAK_NOTE) and not lab.get("note", "").startswith(WEAK_NOTE):
                    prev["also_on"].append(prev["page"])
                    prev["page"] = pno + 1
                    prev["crop"] = (lab["crop"].x0, lab["crop"].y0, lab["crop"].x1, lab["crop"].y1)
                    prev["note"] = lab.get("note", "")
                    prev["rot"] = lab.get("rot", 0)
                    prev["mask"] = lab.get("mask")
                else:
                    prev["also_on"].append(pno + 1)
                continue
            cr = lab["crop"]
            if not lab.get("tight") and (lab.get("rot") or (cr.y0 <= 5 and cr.width >= 0.8 * page.rect.width)):
                # full-sheet drawing: drop the printed sheet header and empty margins, but never
                # lose the "FIG. n" caption itself
                trimmed = _trim_sheet_margins(page, cr)
                lab["crop"] = _pad(_union(trimmed, lab["rect"]), MARGIN_PT)
                lab["crop"].intersect(page.rect)
            if vec is not None:                     # vector drawing: keep header / footer / signature out of the crop
                core = _union(vec, lab["rect"])
                obst = [fitz.Rect(l["x0"], l["y0"], l["x1"], l["y1"]) for l in lines]
                try:
                    for im in page.get_image_info():
                        obst.append(fitz.Rect(im["bbox"]))
                except Exception:
                    pass
                lab["crop"] = _trim_to_core(lab["crop"], core, obst)
            if not lab.get("rot") and vec is None:       # keep printed header / footer / signature text out of the crop
                lab["crop"] = _trim_page_furniture(page, lab, graphics, lines, extra_obst=_sig_pics)
            fig = {
                "label": fig_label(*key), "num": key[0], "suffix": key[1],
                "page": pno + 1, "filename": fig_filename(*key),
                "crop": (lab["crop"].x0, lab["crop"].y0, lab["crop"].x1, lab["crop"].y1),
                "note": lab.get("note", ""), "also_on": carried, "rot": lab.get("rot", 0),
                "mask": lab.get("mask"),
            }
            first_seen[key] = fig
            order.append(fig)
        if progress:
            progress(pno + 1, n)
    # drawing sheets whose captions could not be read: number the pictures by order, flag them
    if unlabeled:
        free = (k for k in range(1, 1000) if not any(key[0] == k for key in first_seen))
        for pno, rects in unlabeled:
            for g in rects:
                num = next(free)
                crop = _pad(fitz.Rect(g), MARGIN_PT)
                crop.intersect(doc[pno].rect)
                fig = {
                    "label": fig_label(num, ""), "num": num, "suffix": "",
                    "page": pno + 1, "filename": fig_filename(num, ""),
                    "crop": (crop.x0, crop.y0, crop.x1, crop.y1),
                    "note": UNLABELED_NOTE, "also_on": [], "rot": 0,
                }
                first_seen[(num, "")] = fig
                order.append(fig)
    doc.close()
    order.sort(key=lambda f: (f["num"], _suffix_key(f["suffix"])))
    audit_overlaps(order)
    return order


# --------------------------------------------------------------------------
# Tables  (type TN)
# --------------------------------------------------------------------------

# "Table 1", "TABLE 2:", "Table 5: Cytocompatibility", "Table-3".  A sentence such as
# "table 1 discloses weight percentages ..." is NOT a caption (no colon/dash after the number).
_TABLE_CAP = re.compile(
    r"^\s*(?:TABLE|TAB\.?)\s*[-\u2013]?\s*(\d{1,3})\s*([A-Za-z]?)\s*(?:[:.\-\u2013\u2014]\s*(.{0,140}))?$",
    re.I)


# "Table 1 (contd.)", "TABLE 3 (continued)", "Table 2 - continued": caption of a table running on from the page before
_TABLE_CONT = re.compile(
    r"^\s*(?:TABLE|TAB\.?)\s*[-\u2013]?\s*(\d{1,3})\s*[A-Za-z]?\s*[\(\[\-\u2013\u2014:,]*\s*cont(?:d|inued|\.)?\b", re.I)


def table_label(num, suffix=""):
    return f"TABLE {num}{suffix}"


def id_to_name(kind, img_id):
    """Hand-edited Image Id ('2', '1A', 'T3', '4(b)') -> (label, filename) in the same style as the detected ones."""
    import re as _re
    raw = str(img_id).strip()
    is_table = kind == "table"
    body = raw[1:] if is_table and raw[:1] in ("T", "t") else raw
    body = _re.sub(r"^(fig(ure)?\.?|table)\s*", "", body, flags=_re.I).strip()
    m = _re.match(r"^(\d+)(.*)$", body)
    safe = lambda t: _re.sub(r"[^A-Za-z0-9_-]", "_", t.replace(")", "")).strip("_")
    stem = (f"{int(m.group(1)):03d}" + safe(m.group(2))) if m else safe(body)
    if is_table:
        return f"TABLE {body}", f"table_{stem}.jpg"
    return f"FIG. {body}", f"figure_{stem}.jpg"


def table_filename(num, suffix=""):
    return f"table_{int(num):03d}{suffix.replace('.', '_')}.jpg"


def _ruled_boxes(page):
    """Tables found from their own ruling: horizontal + vertical line segments (plain lines or thin
    rectangles, or a stroked rectangle for the outer border) that touch each other are one grid.  A
    grid needs >= 2 horizontal and >= 2 vertical lines, so underlines and text artefacts are ignored."""
    segs = []                                              # (is_horizontal, x0, y0, x1, y1)

    def add(x0, y0, x1, y1):
        w, h = abs(x1 - x0), abs(y1 - y0)
        if h <= 1.8 and w >= 6:
            segs.append((True, min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)))
        elif w <= 1.8 and h >= 6:
            segs.append((False, min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)))
    try:
        drawings = page.get_drawings()
    except Exception:
        return []
    for d in drawings:
        for it in d.get("items", ()):
            op = it[0]
            if op == "l":
                add(it[1].x, it[1].y, it[2].x, it[2].y)
            elif op == "re":
                r = it[1]
                if r.height <= 1.8 or r.width <= 1.8:
                    add(r.x0, r.y0, r.x1, r.y1)
                elif d.get("color") is not None and r.width >= 20 and r.height >= 12:   # stroked outline
                    add(r.x0, r.y0, r.x1, r.y0); add(r.x0, r.y1, r.x1, r.y1)
                    add(r.x0, r.y0, r.x0, r.y1); add(r.x1, r.y0, r.x1, r.y1)
    if len(segs) < 4:
        return []
    parent = list(range(len(segs)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    tol = 2.0
    for i in range(len(segs)):
        a = segs[i]
        for j in range(i + 1, len(segs)):
            b = segs[j]
            if a[1] - tol <= b[3] and b[1] - tol <= a[3] and a[2] - tol <= b[4] and b[2] - tol <= a[4]:
                parent[find(i)] = find(j)
    comps = {}
    for i, sg in enumerate(segs):
        comps.setdefault(find(i), []).append(sg)
    boxes = []
    for sgs in comps.values():
        nh = len({round(s_[2]) for s_ in sgs if s_[0]})
        nv = len({round(s_[1]) for s_ in sgs if not s_[0]})
        r = fitz.Rect(min(s_[1] for s_ in sgs), min(s_[2] for s_ in sgs),
                      max(s_[3] for s_ in sgs), max(s_[4] for s_ in sgs))
        if nh >= 2 and nv >= 2 and r.width >= 80 and r.height >= 25:
            boxes.append(r)
    return sorted(boxes, key=lambda z: (z.y0, z.x0))


def _table_boxes(page):
    """Rectangles that look like tables: ruled grids first; only when a page has no ruled grid at all,
    PyMuPDF's own table finder and vector clusters (borders drawn as plain rectangles)."""
    ruled = _ruled_boxes(page)
    if ruled:
        return ruled
    pr = page.rect
    boxes = []
    try:
        for tb in page.find_tables().tables:
            r = fitz.Rect(tb.bbox)
            rows = getattr(tb, "row_count", 0)
            cols = getattr(tb, "col_count", 0)
            if r.width >= 80 and r.height >= 35 and rows >= 2 and cols >= 2:
                boxes.append(r)
    except Exception:
        pass
    try:
        for r in page.cluster_drawings():
            r = fitz.Rect(r)
            r.intersect(pr)
            if r.width >= 100 and r.height >= 35:
                boxes.append(r)
    except Exception:
        pass
    merged = []
    for r in sorted(boxes, key=lambda z: (z.y0, z.x0)):
        for m in merged:
            inter = fitz.Rect(m)
            inter.intersect(r)
            if not inter.is_empty and inter.get_area() >= 0.6 * min(m.get_area(), r.get_area()):
                m.include_rect(r)
                break
        else:
            merged.append(fitz.Rect(r))
    return merged


def _stack_boxes(boxes, max_gap=6.0, x_tol=40.0):
    """Ruled boxes printed directly one under the other with the same width (a table drawn in several pieces,
    e.g. Part A / Part B, or a second grid right below the first) are ONE table."""
    out = []
    for b in sorted((fitz.Rect(b) for b in boxes), key=lambda z: (z.y0, z.x0)):
        for m in out:
            if (abs(m.x0 - b.x0) <= x_tol and abs(m.x1 - b.x1) <= x_tol
                    and -2.0 <= b.y0 - m.y1 <= max_gap):
                m.include_rect(b)
                break
        else:
            out.append(fitz.Rect(b))
    return out


def find_tables(pdf_path, skip_pages=None, progress=None):
    """Find tables ("Table 1", "Table 2: ..." captions with a ruled/boxed table beneath).

    Same item format as find_figures() plus type='TN', kind='table'.  A table that runs on to the next
    page(s) is saved once per page: the first part as TABLE 1, the parts that follow as TABLE 1.1,
    TABLE 1.2 ... (file names table_001.jpg, table_001_1.jpg ...).  A caption with no table under it
    (a heading that introduces a table printed on the next page) is ignored."""
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.  Run:  py -m pip install PyMuPDF")
    doc = detector.open_pdf(pdf_path)
    n = len(doc)
    if skip_pages is None:
        try:
            skip_pages = pages_to_skip(detector.analyze_pdf(pdf_path, use_ocr=False)["rows"])
        except Exception:
            skip_pages = ()
    skip = set(skip_pages)
    items = []
    prev = None            # last table box on the previous page: dict(page, num, root, k, box, open_end)
    for pno in range(n):
        if progress:
            progress(pno + 1, n)
        if (pno + 1) in skip:
            prev = None
            continue
        page = doc[pno]
        try:
            lines, _o, _e = detector._page_lines(page, False)
        except Exception:
            prev = None
            continue
        ph = page.rect.height
        caps, conts = [], []
        for ln in lines:
            txt = ln["text"].strip()
            if len(txt.split()) > 20:
                continue
            mc = _TABLE_CONT.match(txt)
            if mc:
                conts.append((ln, int(mc.group(1))))
                continue
            m = _TABLE_CAP.match(txt)
            if m:
                caps.append((ln, m.group(1), (m.group(2) or "").upper()))
        boxes = _stack_boxes(_table_boxes(page)) if (caps or conts or prev) else []
        used = set()
        cur = None
        curs = []
        for ln, num, suf in sorted(caps, key=lambda c: c[0]["y0"]):
            cap = fitz.Rect(ln["x0"], ln["y0"], ln["x1"], ln["y1"])
            # a long caption wraps over several lines: the table starts under the LAST of them
            left = min((l["x0"] for l in lines if len(l["text"].strip()) > 30), default=cap.x0)
            for _ in range(5):
                nxt = [l for l in lines
                       if 0 <= l["y0"] - cap.y1 <= 0.8 * max(l["y1"] - l["y0"], 6)
                       and l["x0"] >= left - 3 and l["x0"] <= cap.x0 + 40
                       and not any(b.y0 - 1 <= (l["y0"] + l["y1"]) / 2 <= b.y1 for b in boxes)]
                if not nxt:
                    break
                l2 = min(nxt, key=lambda l: l["y0"])
                cap |= fitz.Rect(l2["x0"], l2["y0"], l2["x1"], l2["y1"])
            best, bd = None, 1e9
            for bi, b in enumerate(boxes):
                if bi in used:
                    continue
                gap = b.y0 - cap.y1                              # table under the caption
                inside = b.y0 - 6 <= cap.y0 <= b.y0 + 25 and cap.y1 <= b.y1 + 2   # caption is the box's first row
                if not (inside or -6 <= gap <= 60):
                    continue
                if min(cap.x1, b.x1) - max(cap.x0, b.x0) < 10 and not inside:
                    continue
                d = 0 if inside else max(gap, 0)
                if d < bd:
                    best, bd = bi, d
            if best is None:
                continue
            used.add(best)
            crop = _pad(fitz.Rect(boxes[best]) | cap, 6)
            crop.intersect(page.rect)
            items.append({
                "label": table_label(int(num), suf), "num": int(num), "suffix": suf,
                "page": pno + 1, "filename": table_filename(num, suf),
                "crop": (crop.x0, crop.y0, crop.x1, crop.y1),
                "note": "", "also_on": [], "type": "TN", "kind": "table"})
            cur = {"page": pno + 1, "num": int(num), "root": int(num), "k": 0, "box": boxes[best]}
            curs.append(cur)
        # tables with no caption on this page: the continuation of the table that ended the page before
        if prev is not None and prev["page"] == pno:
            body = [l for l in lines if len(l["text"].strip()) > 6 and 0.04 * ph < l["y0"] < 0.9 * ph]
            for bi, b in enumerate(boxes):
                if bi in used:
                    continue
                if abs(b.x0 - prev["box"].x0) > 20 or abs(b.x1 - prev["box"].x1) > 20:
                    continue
                if any(l["y1"] < b.y0 - 2 and not _TABLE_CONT.match(l["text"]) for l in body):
                    continue                                     # text above it: a new, caption-less table
                if conts:                                        # "Table 1 (contd.)" must name the same table
                    if not any(c[1] == prev["root"] for c in conts):
                        continue
                used.add(bi)
                k = prev["k"] + 1
                crop = _pad(fitz.Rect(b), 6)
                for ln, cnum in conts:
                    if cnum == prev["root"] and ln["y1"] <= b.y0 + 2 and b.y0 - ln["y1"] < 40:
                        crop |= fitz.Rect(ln["x0"], ln["y0"], ln["x1"], ln["y1"])
                crop.intersect(page.rect)
                suf = f".{k}"
                items.append({
                    "label": table_label(prev["root"], suf), "num": prev["root"], "suffix": suf,
                    "page": pno + 1, "filename": table_filename(prev["root"], suf),
                    "crop": (crop.x0, crop.y0, crop.x1, crop.y1),
                    "note": f"continuation of {table_label(prev['root'], '' if k == 1 else f'.{k - 1}')}",
                    "also_on": [], "type": "TN", "kind": "table"})
                cur = {"page": pno + 1, "num": prev["root"], "root": prev["root"], "k": k, "box": b}
                curs.append(cur)
                break
        # does the last table of this page run on to the next page?  (nothing but the footer below it)
        prev = None
        if curs:
            cur = max(curs, key=lambda c: c["box"].y1)          # the table at the BOTTOM of the page may run on
        if cur is not None:
            last = max((boxes[i] for i in used), key=lambda z: z.y1, default=None)
            if last is not None and abs(last.y1 - cur["box"].y1) < 1:
                below = [l for l in lines if l["y0"] > last.y1 + 3 and l["y1"] < 0.88 * ph
                         and len(l["text"].strip()) > 6]
                if not below:
                    prev = dict(cur, page=pno + 1)
    doc.close()
    return sorted(items, key=lambda f: (f["page"], f["crop"][1]))


def merge_items(figs, tabs):
    """Figures + tables in reading order (page, then top position)."""
    return sorted(list(figs) + list(tabs), key=lambda f: (f["page"], f["num"], _suffix_key(f["suffix"]), f["crop"][1]))


def _render_crop(page, fig, dpi):
    """Pixmap of a figure crop; a drawing printed sideways is turned upright (fig['rot'] = degrees
    clockwise)."""
    mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
    rot = fig.get("rot", 0) or 0
    if rot:
        mat = mat.prerotate(rot)
    pix = page.get_pixmap(matrix=mat, clip=fitz.Rect(*fig["crop"]),
                          colorspace=fitz.csRGB, alpha=False)
    mask = fig.get("mask")
    if mask and not rot and cv2 is not None and np is not None:      # fragments of the NEIGHBOURING figure inside this crop
        try:
            pix = _apply_mask(pix, mask, dpi / 72.0)
        except Exception:
            pass
    return pix


def export_figures(pdf_path, figures, out_dir, dpi=200, progress=None):
    """Save every figure as JPG into out_dir. Returns the list of written paths."""
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.  Run:  py -m pip install PyMuPDF")
    os.makedirs(out_dir, exist_ok=True)
    doc = detector.open_pdf(pdf_path)
    written = []
    for i, fig in enumerate(figures):
        page = doc[fig["page"] - 1]
        pix = _render_crop(page, fig, dpi)
        path = os.path.join(out_dir, fig["filename"])
        try:
            pix.save(path, jpg_quality=92)
        except TypeError:  # older PyMuPDF without jpg_quality
            pix.save(path)
        written.append(path)
        if progress:
            progress(i + 1, len(figures))
    doc.close()
    return written


def render_figure_png(pdf_path, fig, dpi=110, fmt="png"):
    """Image bytes of one figure crop for the in-app viewer (fmt 'png', or raw 'ppm' = no compression, fastest)."""
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.  Run:  py -m pip install PyMuPDF")
    doc = detector.open_pdf(pdf_path)
    try:
        page = doc[fig["page"] - 1]
        return _render_crop(page, fig, dpi).tobytes(fmt)
    finally:
        doc.close()


def build_report(pdf_name, rows, figures):
    """Text report in the requested layout. `rows` is analyze_pdf()['rows']."""
    by_title = {r["TITLE"]: r for r in rows}

    def span(title):
        r = by_title.get(title)
        if not r or r["FIRST pg.no"] == "":
            return None
        return f"{r['FIRST pg.no']}{DASH}{r['Last Pg.no']}"

    def line(name, title, sep):
        s = span(title)
        return f"{name} {sep} PDF pages {s}" if s else f"{name} {sep} not detected"

    tables = [f for f in figures if f.get("kind") == "table"]
    figures = [f for f in figures if f.get("kind") != "table"]
    out = [pdf_name, "",
           line("Abstract      ", "Abstract", ARROW),
           line("Description   ", "Description", ARROW)]
    if span("Sequence Listing"):               # last part of the description (shown only when present)
        out.append(line("Sequence Listing", "Sequence Listing", ARROW))
    out += [
           line("Claims        ", "Claim", ARROW),
           line("Drawings", "Drawing", "-"),
           "", "", "Drawing:"]
    if not figures:
        out.append("No figure labels (FIG. 1, FIG. 2 ...) were found.")
    for f in figures:
        s = f"{f['label']} {ARROW} PDF page {f['page']} {ARROW} {f['filename']}"
        if f["also_on"]:
            s += "   (label also on page " + ", ".join(str(p) for p in f["also_on"]) + ")"
        if f["note"]:
            s += f"   [{f['note']}]"
        out.append(s)
    if tables:
        out += ["", "Tables:"]
        for f in tables:
            s = f"{f['label']} {ARROW} PDF page {f['page']} {ARROW} {f['filename']}"
            if f["also_on"]:
                s += "   (label also on page " + ", ".join(str(p) for p in f["also_on"]) + ")"
            out.append(s)
    return "\n".join(out) + "\n"


def save_outputs(pdf_path, rows, figures, out_root, dpi=200, progress=None):
    """Write <out_root>/<pdf name>_output/{<pdf name>_report.txt, figures/figure_001.jpg ...}.
    Returns (output_folder, report_path)."""
    stem = os.path.splitext(os.path.basename(pdf_path))[0]
    folder = os.path.join(out_root, stem + "_output")
    os.makedirs(folder, exist_ok=True)
    export_figures(pdf_path, figures, os.path.join(folder, "figures"), dpi=dpi, progress=progress)
    report_path = os.path.join(folder, stem + "_report.txt")
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write(build_report(os.path.basename(pdf_path), rows, figures))
    return folder, report_path


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------

def _main(argv):
    if len(argv) < 2:
        print("usage: python figures.py file.pdf [--ocr] [--out DIR] [--dpi 200]")
        return 2
    pdf = argv[1]
    use_ocr = "--ocr" in argv
    out = os.path.dirname(os.path.abspath(pdf))
    dpi = 200
    if "--out" in argv:
        out = argv[argv.index("--out") + 1]
    if "--dpi" in argv:
        dpi = int(argv[argv.index("--dpi") + 1])
    res = detector.analyze_pdf(pdf, use_ocr=use_ocr)
    figs = find_figures(pdf, use_ocr=use_ocr, skip_pages=pages_to_skip(res["rows"]),
                        drawing_pages=drawing_pages_of(res["rows"]))
    figs = merge_items(figs, find_tables(pdf, skip_pages=pages_to_skip(res["rows"])))
    folder, report = save_outputs(pdf, res["rows"], figs, out, dpi=dpi)
    print(build_report(os.path.basename(pdf), res["rows"], figs))
    print("Saved to:", folder)
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
