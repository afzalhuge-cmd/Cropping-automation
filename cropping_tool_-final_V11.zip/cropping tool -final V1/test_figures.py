"""
 figures.py: synthetic patent with figures on a description page, on a vector
drawing sheet and on a sheet where two figures share one picture, plus traps
(a sentence starting with "FIG. 1 is ...", a line-wrapped "FIG. 1" in running text).

Run:   py test_figures.py
"""
import os
import sys
import tempfile

try:
    import pymupdf as fitz
except ImportError:
    import fitz

import figures
import test_detector as T

W, H = 595, 842


def picture(w, h, color):
    pix = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, w, h), False)
    pix.set_rect(pix.irect, color)
    return pix.tobytes("png")


def build(path):
    d = T.Doc()
    # p1: prose with traps
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", T.para(60)),
                 ("line", "FIG. 1 is a perspective view of the device."),
                 ("p", T.para(60)),
                 ("line", "as shown in"), ("line", "FIG. 1"), ("p", T.para(40))], footer="1")
    # p2: description page, embedded image + bare caption underneath  -> FIG. 1
    p = d.text_page([("p", T.para(90))], footer="2")
    p.insert_image(fitz.Rect(120, 300, 470, 520), stream=picture(200, 120, (200, 60, 60)))
    p.insert_text((280, 545), "FIG. 1", fontsize=11, fontname="helv")
    # p3: description page with image -> FIG. 2
    p = d.text_page([("p", T.para(90))], footer="3")
    p.insert_image(fitz.Rect(150, 420, 440, 640), stream=picture(200, 140, (60, 60, 200)))
    p.insert_text((285, 665), "Fig. 2", fontsize=11, fontname="helv")
    # p4: drawing sheet, vector drawing -> FIG. 3
    p = d.doc.new_page(width=W, height=H)
    p.insert_text((250, 40), "Sheet 1 of 2", fontsize=9, fontname="helv")
    for i in range(6):
        p.draw_rect(fitz.Rect(150 + i * 12, 200 + i * 12, 350 + i * 12, 330 + i * 12), color=(0, 0, 0))
    p.insert_text((270, 480), "FIG. 3", fontsize=12, fontname="hebo")
    # p5: drawing sheet, one picture containing two figures stacked -> FIG. 4A / FIG. 4B
    p = d.doc.new_page(width=W, height=H)
    p.insert_text((250, 40), "Sheet 2 of 2", fontsize=9, fontname="helv")
    p.insert_image(fitz.Rect(100, 80, 500, 760), stream=picture(300, 500, (230, 230, 230)))
    p.insert_text((280, 400), "FIG. 4A", fontsize=12, fontname="hebo")
    p.insert_text((280, 740), "FIG. 4B", fontsize=12, fontname="hebo")
    d.doc.save(path)
    return {"FIG. 1": 2, "FIG. 2": 3, "FIG. 3": 4, "FIG. 4A": 5, "FIG. 4B": 5}


def main():
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "Patent.pdf")
    expected = build(path)
    figs = figures.find_figures(path)
    got = {f["label"]: f["page"] for f in figs}
    ok = got == expected
    print("expected", expected)
    print("got     ", got, "->", "PASS" if ok else "FAIL")

    rows = [{"TITLE": "Abstract", "FIRST pg.no": 2, "Last Pg.no": 2},
            {"TITLE": "Description", "FIRST pg.no": 1, "Last Pg.no": 3},
            {"TITLE": "Claim", "FIRST pg.no": 4, "Last Pg.no": 4},
            {"TITLE": "Drawing", "FIRST pg.no": 4, "Last Pg.no": 5}]
    folder, report = figures.save_outputs(path, rows, figs, tmp)
    files = sorted(os.listdir(os.path.join(folder, "figures")))
    want_files = ["figure_001.jpg", "figure_002.jpg", "figure_003.jpg", "figure_004A.jpg", "figure_004B.jpg"]
    ok2 = files == want_files
    print("files", files, "->", "PASS" if ok2 else "FAIL")
    # FIG 4A / 4B crops must not overlap much
    c = {f["label"]: f["crop"] for f in figs}
    ok3 = c["FIG. 4A"][3] <= c["FIG. 4B"][1] + 20
    print("4A above 4B, separate crops ->", "PASS" if ok3 else "FAIL", c["FIG. 4A"], c["FIG. 4B"])
    print("\n" + open(report, encoding="utf-8").read())
    sys.exit(0 if (ok and ok2 and ok3) else 1)


if __name__ == "__main__":
    main()
