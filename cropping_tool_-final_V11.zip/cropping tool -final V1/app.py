import csv
import sys
import time
import os
import re
import queue
import shutil
import tempfile
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import detector
import ocr_engine
import figures

# (label shown in the table, TITLE used by detector.py)
EYE = "\U0001F441"            # view icon

DRAW_TYPES = ("PN", "TN")      # PN = Figure, TN = Table

SUB_PREFIX = "Sub:"
SUB_INDENT = "      \u21B3 "      # sub-parts of the Description are shown indented under it
META_TYPES = [("Abstract", "Abstract"), ("Claims", "Claim"),
              ("Description", "Description"), ("Drawings", "Drawing")]
# sub-parts are optional: many patents lack some of them, never reported as "not detected"
OPTIONAL_TYPES = {k for _l, k in META_TYPES if k.startswith(SUB_PREFIX)}


def _pg(v):
    """Page box text: a section with no page number shows 0."""
    return v if str(v).isdigit() else 0


def _row_no(idx):
    """Serial number of top-level rows only (sub-parts of the Description are not numbered)."""
    if META_TYPES[idx][1].startswith(SUB_PREFIX):
        return ""
    return sum(1 for _l, k in META_TYPES[:idx + 1] if not k.startswith(SUB_PREFIX))


class PatentExtractorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Cropping Tool")
        self.geometry("1150x760")
        self.minsize(950, 640)

        self.pdf_path = None
        self.result = None
        self.rows = []
        self.page_rows = []
        self.sub_rows = []
        self.figs = []
        self.report_text = ""
        self.q = queue.Queue()
        self.busy = False

        # background work (PyMuPDF / numpy) holds Python's lock for long stretches and makes the window freeze;
        # a short switch interval hands it back to the UI thread about 5x more often
        sys.setswitchinterval(0.001)
        self._last_progress = 0.0
        self._hover_cursor = None

        self.configure(bg="#f5f7fa")
        self._build_style()
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), background="#f5f7fa")
        style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground="#555", background="#f5f7fa")
        style.configure("Meta.TLabel", font=("Segoe UI", 11, "bold"), foreground="#1a7fd4", background="#f5f7fa")
        style.configure("Warn.TLabel", font=("Segoe UI", 10), foreground="#9a5b00", background="#f5f7fa")
        style.configure("Action.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 8))
        style.configure("Treeview", rowheight=30, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    def _build_ui(self):
        top = ttk.Frame(self, padding=(22, 18, 22, 6))
        top.pack(fill="x")

        ttk.Label(top, text="Cropping Tool",
                  style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            top,
            text="Mcpairs",
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(4, 12))

        actions = ttk.Frame(top)
        actions.pack(fill="x")

        self.btn_upload = ttk.Button(actions, text="\U0001F4C4 Upload Patent PDF",
                                     command=self.choose_pdf, style="Action.TButton")
        self.btn_upload.pack(side="left")
        self.btn_extract = ttk.Button(actions, text="Extract Page Numbers",
                                      command=self.extract, style="Action.TButton")
        self.btn_extract.pack(side="left", padx=10)
        self.btn_clear = ttk.Button(actions, text="\u2716 Clear",
                                    command=self.clear_all, style="Action.TButton")
        self.btn_clear.pack(side="left")

        self.ocr_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(actions, text="OCR",
                        variable=self.ocr_var).pack(side="left", padx=(8, 2))
        self.ocr_note = ttk.Label(actions, text="Tesseract: checking...", style="Sub.TLabel")
        self.ocr_note.pack(side="left", padx=(0, 8))
        self.ocr_note.bind("<Button-1>", lambda _e: self._show_ocr_info())
        self._ocr_probe = None
        threading.Thread(target=self._probe_ocr, daemon=True).start()
        self.after(200, self._check_ocr_probe)

        self.btn_save = ttk.Button(actions, text="Save report + figures",
                                   command=self.save_all, style="Action.TButton")
        self.btn_save.pack(side="right", padx=(10, 0))
        ttk.Button(actions, text="Export CSV",
                   command=self.export_csv, style="Action.TButton").pack(side="right")

        self.file_label = ttk.Label(top, text="No PDF selected.", style="Sub.TLabel")
        self.file_label.pack(anchor="w", pady=(10, 0))

        self.status = ttk.Label(top, text="Ready.", style="Sub.TLabel")
        self.status.pack(anchor="w", pady=(4, 0))

        self.progress = ttk.Progressbar(top, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(6, 0))

        self.warn_label = ttk.Label(top, text="", style="Warn.TLabel", justify="left", wraplength=1080)
        self.warn_label.pack(anchor="w", pady=(6, 0))

        # ---- Add Metadata table (front page) -------------------------------
        meta = ttk.Frame(self, padding=(22, 8, 22, 0))
        meta.pack(fill="x")
        ttk.Label(meta, text="Add Metadata", style="Meta.TLabel").pack(anchor="w", pady=(0, 8))

        cols = ("No", "MetaType", "Pagefrom", "Pageto")
        self.tree = ttk.Treeview(meta, columns=cols, show="headings",
                                 height=len(META_TYPES), selectmode="browse")
        widths = {"No": 50, "MetaType": 220, "Pagefrom": 200, "Pageto": 200}
        for col in cols:
            self.tree.heading(col, text="" if col == "No" else col)
            self.tree.column(col, width=widths[col], stretch=False,
                             anchor="center" if col in ("No", "Pagefrom", "Pageto") else "w")
        for i, (label, _key) in enumerate(META_TYPES):
            self.tree.insert("", "end", iid=str(i), values=(_row_no(i), label, 0, 0))
        self.tree.pack(anchor="w")
        self.tree.bind("<Double-1>", self._edit_cell)

        ttk.Label(meta, text="Double-click a page box to edit it.",
                  style="Sub.TLabel").pack(anchor="w", pady=(8, 0))

        # ---- Drawings table (below metadata) --------------------------------
        dr = ttk.Frame(self, padding=(22, 14, 22, 10))
        dr.pack(fill="both", expand=True)
        ttk.Label(dr, text="Drawings", style="Meta.TLabel").pack(anchor="w", pady=(0, 8))
        holder = ttk.Frame(dr)
        holder.pack(anchor="w", fill="both", expand=True)
        dcols = ("SNo.", "Page No", "Type", "Image Id", "View", "Action")
        self.dtree = ttk.Treeview(holder, columns=dcols, show="headings", height=8)
        dw = {"SNo.": 70, "Page No": 120, "Type": 120, "Image Id": 120, "View": 90, "Action": 90}
        for col in dcols:
            self.dtree.heading(col, text=col)
            self.dtree.column(col, width=dw[col], stretch=False, anchor="center")
        dys = ttk.Scrollbar(holder, orient="vertical", command=self.dtree.yview)
        self.dtree.configure(yscrollcommand=dys.set)
        self.dtree.pack(side="left", fill="y")
        dys.pack(side="left", fill="y")
        self.dtree.bind("<Button-1>", self._drawing_click)
        self.dtree.bind("<Motion>", self._drawing_hover)
        ttk.Label(dr, text="Type: PN = Figure, TN = Table (click the Type box to change). "
                       "Click an Image Id to edit it, eye = view image (and save its JPG), \u2716 = remove.",
                  style="Sub.TLabel").pack(anchor="w", pady=(8, 0))


    # ------------------------------------------------------------- actions
    def choose_pdf(self):
        path = filedialog.askopenfilename(
            title="Select Indian Patent PDF",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")]
        )
        if path:
            self.pdf_path = path
            self.file_label.config(text=f"Selected: {Path(path).name}")
            self.status.config(text="PDF selected. Click 'Extract Page Numbers'.")

    # ---------------------------------------------------------- OCR (Tesseract + OpenCV)
    def _probe_ocr(self):
        try:
            self._ocr_probe = ocr_engine.available()
        except Exception as exc:  # never let the probe crash the window
            self._ocr_probe = (False, str(exc))

    def _check_ocr_probe(self):
        if self._ocr_probe is None:
            self.after(200, self._check_ocr_probe)
            return
        ok, text = self._ocr_probe
        if ok:
            self.ocr_note.config(text="Tesseract found - OCR on")
            self.ocr_var.set(True)           # OCR only touches pages without text / pictures with labels
        else:
            self.ocr_note.config(text="Tesseract not found (click for help)", cursor="hand2")
            self.ocr_var.set(False)

    def _show_ocr_info(self):
        if self._ocr_probe is None:
            return
        ok, text = self._ocr_probe
        if ok:
            messagebox.showinfo("OCR", "OCR engine: " + text)
        else:
            messagebox.showwarning("OCR - Tesseract not found", text)

    def clear_all(self):
        """Reset everything so the next patent can be loaded from scratch."""
        if self.busy:
            messagebox.showinfo("Please wait", "Wait for the current task to finish, then click Clear.")
            return
        self.pdf_path = None
        self.result = None
        self.rows = []
        self.page_rows = []
        self.figs = []
        self.report_text = ""
        try:
            if self._viewer.winfo_exists():
                self._viewer.destroy()
        except Exception:
            pass
        for i, (label, _key) in enumerate(META_TYPES):
            self.tree.item(str(i), values=(_row_no(i), label, 0, 0), tags=("ok",))
        for item in self.dtree.get_children():
            self.dtree.delete(item)
        self.file_label.config(text="No PDF selected.")
        self.status.config(text="Ready.")
        self.warn_label.config(text="")
        self.progress.configure(value=0)

    def extract(self):
        if self.busy:
            return
        if not self.pdf_path:
            messagebox.showwarning("No PDF", "Please select an Indian patent PDF first.")
            return
        self.busy = True
        self.btn_extract.state(["disabled"])
        self.btn_upload.state(["disabled"])
        self.progress.configure(value=0)
        self.warn_label.config(text="")
        self.status.config(text="Reading PDF and analyzing pages...")
        threading.Thread(target=self._worker, args=(self.pdf_path, self.ocr_var.get()),
                         daemon=True).start()
        self.after(80, self._poll)

    def _progress(self, i, n):
        """Called from the worker for every page: send at most ~12 updates a second and yield to the UI."""
        now = time.monotonic()
        if i >= n or now - self._last_progress >= 0.08:
            self._last_progress = now
            self.q.put(("progress", i, n))
        time.sleep(0.0005)

    def _worker(self, path, use_ocr):
        try:
            res = detector.analyze_pdf(
                path, use_ocr=use_ocr,
                progress=self._progress)
            self.q.put(("status", "Looking for figures (FIG. 1, FIG. 2 ...)..."))
            try:
                figs = figures.find_figures(
                    path, use_ocr=use_ocr, skip_pages=figures.pages_to_skip(res["rows"]),
                    drawing_pages=figures.drawing_pages_of(res["rows"]),
                    progress=self._progress)
            except Exception as fe:  # page ranges are still useful without figures
                figs = []
                res["warnings"].append("Figure search failed: " + str(fe)[:160])
            try:
                self.q.put(("status", "Looking for tables (Table 1, Table 2 ...)..."))
                tabs = figures.find_tables(path, skip_pages=figures.pages_to_skip(res["rows"]))
                figs = figures.merge_items(figs, tabs)
            except Exception as te:
                res["warnings"].append("Table search failed: " + str(te)[:160])
            if not figs:
                drow = next((r for r in res["rows"] if r["TITLE"] == "Drawing" and r["FIRST pg.no"] != ""), None)
                if drow:
                    span = f"{drow['FIRST pg.no']}-{drow['Last Pg.no']}"
                    if not use_ocr:
                        res["warnings"].append(
                            f"Drawing pages {span} were found but no FIG. labels could be read - the labels are "
                            "probably part of the picture. Tick 'OCR' and run again.")
                    else:
                        res["warnings"].append(
                            f"Drawing pages {span} were found but no FIG. labels could be read even with OCR "
                            "(labels very small, rotated or missing).")
            self.q.put(("done", res, figs))
        except Exception as e:  # shown to the user, not swallowed
            self.q.put(("error", str(e)))

    def _poll(self):
        try:
            latest = None
            while True:
                msg = self.q.get_nowait()
                kind = msg[0]
                if kind == "progress":
                    latest = msg                    # draw only the newest one, after the loop
                    continue
                if latest is not None:
                    self._apply_progress(latest)
                    latest = None
                if kind == "status":
                    self.status.config(text=msg[1])
                elif kind == "done":
                    self._show_result(msg[1], msg[2])
                    self._finish()
                    return
                elif kind == "saved":
                    self._finish()
                    self.status.config(text="Saved: " + msg[1])
                    messagebox.showinfo("Saved", f"Report and figures saved to:\n{msg[1]}")
                    return
                elif kind == "error":
                    self.status.config(text="Extraction failed.")
                    messagebox.showerror("Extraction Error", msg[1])
                    self._finish()
                    return
        except queue.Empty:
            pass
        if latest is not None:
            self._apply_progress(latest)
        self.after(120, self._poll)

    def _apply_progress(self, msg):
        _, i, n = msg
        self.progress.configure(value=100.0 * i / max(n, 1))
        self.status.config(text=f"Reading page {i} of {n}...")

    def _finish(self):
        self.busy = False
        self.btn_extract.state(["!disabled"])
        self.btn_upload.state(["!disabled"])
        self.btn_save.state(["!disabled"])
        self.progress.configure(value=100)

    def _show_result(self, res, figs=None):
        self.result = res
        self.figs = figs or []
        self.rows = res["rows"]
        self.page_rows = res["page_rows"]
        self.sub_rows = res.get("sub_rows", [])
        by_title = {r["TITLE"]: r for r in self.rows}
        by_title.update({SUB_PREFIX + r["TITLE"]: r for r in self.sub_rows})

        for i, (label, key) in enumerate(META_TYPES):
            r = by_title.get(key, {})
            self.tree.item(str(i), values=(_row_no(i), label, _pg(r.get("FIRST pg.no", "")), _pg(r.get("Last Pg.no", ""))))

        self._refresh_drawings()
        self.report_text = figures.build_report(Path(self.pdf_path).name, self.rows, self.figs)

        # rows the detector is not sure about are highlighted yellow
        self.tree.tag_configure("check", background="#fff3b0")
        self.tree.tag_configure("ok", background="")
        needs_check = []
        for i, (label, key) in enumerate(META_TYPES):
            r = by_title.get(key, {})
            weak = r.get("Review") == "YES" and r.get("FIRST pg.no", "") != ""
            self.tree.item(str(i), tags=("check" if weak else "ok",))
            if weak:
                needs_check.append(label)

        # pages inside the document span that no section claimed
        extra_warn = []
        spans = [(r["FIRST pg.no"], r["Last Pg.no"]) for r in self.rows if r.get("FIRST pg.no", "") != ""]
        if spans:
            lo, hi = min(s[0] for s in spans), max(s[1] for s in spans)
            gaps = [pr["PDF page"] for pr in self.page_rows
                    if lo <= pr["PDF page"] <= hi
                    and not any(s[0] <= pr["PDF page"] <= s[1] for s in spans)]
            if gaps:
                extra_warn.append("Pages not assigned to any section: " + ", ".join(map(str, gaps[:12])))

        missing = [label for label, key in META_TYPES
                   if key not in OPTIONAL_TYPES and by_title.get(key, {}).get("FIRST pg.no", "") == ""]
        if missing:
            self.status.config(text=f"Completed. Not detected: {', '.join(missing)} (you can type them in)")
        else:
            self.status.config(text=f"Completed successfully. {res['n_pages']} PDF pages analyzed.")
        if needs_check and not missing:
            self.status.config(text=f"Completed. Please double-check (yellow): {', '.join(needs_check)}")
        msgs = list(res["warnings"]) + extra_warn
        self.warn_label.config(text=("\u26A0 " + "\n\u26A0 ".join(msgs)) if msgs else "")

    # ---------------------------------------------------------- drawings
    def _refresh_drawings(self):
        for item in self.dtree.get_children():
            self.dtree.delete(item)
        for n, f in enumerate(self.figs, 1):
            stem = os.path.splitext(f["filename"])[0]
            if f.get("image_id"):                        # hand-edited
                img_id = f["image_id"]
            elif f.get("kind") == "table":
                img_id = "T" + (stem.replace("table_", "").lstrip("0") or str(n))
            else:
                img_id = stem.replace("figure_", "").lstrip("0") or str(n)
            self.dtree.insert("", "end", iid=str(n - 1),     # row index (ids may be edited / repeated)
                              values=(n, f["page"], f.get("type", "PN"), img_id, EYE, "\u2716"))

    def _drawing_hover(self, event):
        want = "hand2" if (self.dtree.identify_row(event.y)
                           and self.dtree.identify_column(event.x) in ("#3", "#4", "#5", "#6")) else ""
        if want != self._hover_cursor:                   # changing the cursor on every mouse move is slow
            self._hover_cursor = want
            self.dtree.configure(cursor=want)

    def _drawing_click(self, event):
        if self.dtree.identify_region(event.x, event.y) != "cell":
            return
        iid = self.dtree.identify_row(event.y)
        col = self.dtree.identify_column(event.x)
        fig = self.figs[int(iid)] if iid.isdigit() and int(iid) < len(self.figs) else None
        if fig is None:
            return
        if col == "#3":
            self._pick_type(iid, fig)
        elif col == "#4":
            self._edit_image_id(iid, fig)
        elif col == "#5":
            self._view_drawing(fig)
        elif col == "#6":
            self.figs = [f for f in self.figs if f is not fig]
            self._refresh_drawings()
            self.report_text = figures.build_report(Path(self.pdf_path).name, self.rows, self.figs)
            self.status.config(text=f"Removed {fig['label']} from the list.")

    def _edit_image_id(self, iid, fig):
        """Type a new Image Id over the cell (Enter / click away = save, Esc = cancel).  The label, the saved
        file name and the report follow the new id automatically."""
        x, y, w, h = self.dtree.bbox(iid, "#4")
        cur = self.dtree.item(iid, "values")[3].replace("\u2B07", "").strip()
        entry = ttk.Entry(self.dtree, justify="center")
        entry.insert(0, cur)
        entry.select_range(0, "end")
        entry.place(x=x, y=y, width=w, height=h)
        entry.focus_set()
        state = {"done": False}

        def commit(_e=None):
            if state["done"]:
                return
            state["done"] = True
            val = entry.get().strip()
            entry.destroy()
            if not val or val == cur:
                return
            if not re.match(r"^[A-Za-z0-9._()\- ]{1,20}$", val):
                messagebox.showwarning("Image Id", "Use letters, digits, . ( ) - only (max 20 characters).")
                return
            fig["image_id"] = val
            fig["label"], fig["filename"] = figures.id_to_name(fig.get("kind"), val)
            dup = sum(1 for f in self.figs if f is not fig and f["filename"] == fig["filename"])
            self._refresh_drawings()
            self.report_text = figures.build_report(Path(self.pdf_path).name, self.rows, self.figs)
            self.status.config(text=f"Image Id changed to {val} - saved automatically."
                                    + ("  Warning: another drawing already has this id." if dup else ""))

        def cancel(_e=None):
            state["done"] = True
            entry.destroy()

        entry.bind("<Return>", commit)
        entry.bind("<FocusOut>", commit)
        entry.bind("<Escape>", cancel)

    def _pick_type(self, iid, fig):
        """Dropdown over the Type cell: PN = Figure, TN = Table."""
        x, y, w, h = self.dtree.bbox(iid, "#3")
        box = ttk.Combobox(self.dtree, values=list(DRAW_TYPES), state="readonly",
                           justify="center")
        box.set(fig.get("type", "PN"))
        box.place(x=x, y=y, width=w, height=h)
        box.focus_set()

        def done(_e=None):
            fig["type"] = box.get()
            box.destroy()
            vals = list(self.dtree.item(iid, "values"))
            vals[2] = fig["type"]
            self.dtree.item(iid, values=vals)

        box.bind("<<ComboboxSelected>>", done)
        box.bind("<FocusOut>", lambda _e: box.destroy())
        box.bind("<Escape>", lambda _e: box.destroy())
        self.after(60, lambda: box.winfo_exists() and box.event_generate("<Button-1>"))

    def _view_drawing(self, fig):
        """Preview window: zoom, fit, and previous / next drawing."""
        import base64
        try:
            top = self._viewer
            if top.winfo_exists():
                top.lift()
        except Exception:
            top = None
        if top is None or not top.winfo_exists():
            top = tk.Toplevel(self)
            self._viewer = top
            top.geometry("960x760")
            top.bind("<Escape>", lambda _e: top.destroy())
            bar = ttk.Frame(top, padding=6)
            bar.pack(fill="x")
            st = {"fig": fig, "dpi": None, "img": None}
            top._state = st
            title = ttk.Label(bar, font=("Segoe UI", 10, "bold"))
            title.pack(side="left", padx=(0, 14))
            body = ttk.Frame(top)
            body.pack(fill="both", expand=True)
            cv = tk.Canvas(body, background="#ffffff", highlightthickness=0)
            ys = ttk.Scrollbar(body, orient="vertical", command=cv.yview)
            xs = ttk.Scrollbar(top, orient="horizontal", command=cv.xview)
            cv.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
            ys.pack(side="right", fill="y")
            cv.pack(side="left", fill="both", expand=True)
            xs.pack(fill="x")

            def show(dpi=None):
                f = st["fig"]
                if dpi is None:                     # fit to the window
                    x0, y0, x1, y1 = f["crop"]
                    cw, ch = (x1 - x0), (y1 - y0)
                    if (f.get("rot", 0) or 0) % 180:      # turned sideways: width and height swap
                        cw, ch = ch, cw
                    w = max(cv.winfo_width(), 400) - 20
                    h = max(cv.winfo_height(), 300) - 20
                    dpi = max(30, min(300, int(72 * min(w / cw, h / ch))))
                st["dpi"] = dpi
                key = (self.pdf_path, f["page"], tuple(f["crop"]), f.get("rot", 0) or 0, dpi, bool(f.get("mask")))
                cache = st.setdefault("cache", {})
                img = cache.get(key)
                if img is None:
                    top.configure(cursor="watch")
                    top.update_idletasks()
                    try:
                        try:       # raw PPM: no PNG compression / decoding, several times faster to show
                            img = tk.PhotoImage(data=figures.render_figure_png(self.pdf_path, f, dpi=dpi, fmt="ppm"))
                        except tk.TclError:
                            img = tk.PhotoImage(data=base64.b64encode(figures.render_figure_png(self.pdf_path, f, dpi=dpi)))
                    except Exception as e:
                        top.configure(cursor="")
                        messagebox.showerror("View failed", str(e), parent=top)
                        return
                    top.configure(cursor="")
                    if len(cache) >= 6:
                        cache.pop(next(iter(cache)))
                    cache[key] = img
                st["img"] = img
                cv.delete("all")
                cv.create_image(0, 0, anchor="nw", image=st["img"])
                cv.configure(scrollregion=(0, 0, st["img"].width(), st["img"].height()))
                idx = self.figs.index(f) + 1 if f in self.figs else 0
                title.config(text=f"{f['label']}   (page {f['page']})   {idx}/{len(self.figs)}")

            def step(d):
                if not self.figs:
                    return
                i = self.figs.index(st["fig"]) if st["fig"] in self.figs else 0
                st["fig"] = self.figs[(i + d) % len(self.figs)]
                show()

            def rotate(deg):
                # applies to THIS drawing only and is saved straight away (fig["rot"] is what
                # the download / export uses), so no separate save step is needed
                f = st["fig"]
                f["rot"] = ((f.get("rot", 0) or 0) + deg) % 360
                show()
                self.status.config(text=f"{f['label']} rotated to {f['rot']}\u00B0 - saved automatically.")

            for txt, cmd in (("\u25C0 Prev", lambda: step(-1)), ("Next \u25B6", lambda: step(1)),
                             ("\u27F2 Left", lambda: rotate(-90)), ("Right \u27F3", lambda: rotate(90)),
                             ("Save JPG", lambda: self._download_drawing(st["fig"], top)),
                             ("\u2212", lambda: show(max(30, int(st["dpi"] / 1.25)))),
                             ("+", lambda: show(min(400, int(st["dpi"] * 1.25)))),
                             ("Fit", lambda: show()), ("Close", top.destroy)):
                ttk.Button(bar, text=txt, width=7, command=cmd).pack(side="left", padx=2)
            top.bind("<Left>", lambda _e: step(-1))
            top.bind("<Right>", lambda _e: step(1))
            top._show = show
        top.title("Drawing preview")
        top._state["fig"] = fig
        top.update_idletasks()
        top._show()

    def _download_drawing(self, fig, parent=None):
        path = filedialog.asksaveasfilename(
            parent=parent or self, title="Save drawing", defaultextension=".jpg", initialfile=fig["filename"],
            filetypes=[("JPEG image", "*.jpg")])
        if not path:
            return
        try:
            with tempfile.TemporaryDirectory() as tmp:
                written = figures.export_figures(self.pdf_path, [fig], tmp)
                shutil.copyfile(written[0], path)
            self.status.config(text="Saved: " + path)
        except Exception as e:
            messagebox.showerror("Save failed", str(e), parent=parent or self)

    # ------------------------------------------------------- cell editing
    def _edit_cell(self, event):
        if self.tree.identify_region(event.x, event.y) != "cell":
            return
        col = self.tree.identify_column(event.x)       # '#3' = Pagefrom, '#4' = Pageto
        if col not in ("#3", "#4"):
            return
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        x, y, w, h = self.tree.bbox(iid, col)
        idx = int(col[1:]) - 1
        values = list(self.tree.item(iid, "values"))
        entry = ttk.Entry(self.tree, justify="center")
        entry.insert(0, str(values[idx]))
        entry.select_range(0, "end")
        entry.place(x=x, y=y, width=w, height=h)
        entry.focus_set()

        def commit(_e=None):
            val = entry.get().strip()
            entry.destroy()
            if val and not val.isdigit():
                messagebox.showwarning("Page number", "Enter a page number (digits only).")
                return
            values[idx] = val
            self.tree.item(iid, values=values)
            self._sync_rows()

        entry.bind("<Return>", commit)
        entry.bind("<FocusOut>", commit)
        entry.bind("<Escape>", lambda _e: entry.destroy())

    def _sync_rows(self):
        """Push the (possibly hand-edited) table back into self.rows so exports use it."""
        by_title = {r["TITLE"]: r for r in self.rows}
        for i, (_label, key) in enumerate(META_TYPES):
            vals = self.tree.item(str(i), "values")
            first = int(vals[2]) if str(vals[2]).isdigit() and int(vals[2]) > 0 else ""   # 0 = none
            last = int(vals[3]) if str(vals[3]).isdigit() and int(vals[3]) > 0 else ""
            if key.startswith(SUB_PREFIX):
                name = key[len(SUB_PREFIX):]
                sr = next((x for x in self.sub_rows if x["TITLE"] == name), None)
                if sr is None:
                    sr = {"TITLE": name, "FIRST pg.no": "", "Last Pg.no": "", "Parent": "Description",
                          "Detection": ""}
                    self.sub_rows.append(sr)
                sr["FIRST pg.no"], sr["Last Pg.no"] = first, last
                if name != "Sequence Listing":
                    continue
                key = name          # the listing also feeds the report / figure search (pages to skip)
                if first == "" and key not in by_title:
                    continue
            r = by_title.get(key)
            if r is None:
                r = {"TITLE": key, "FIRST pg.no": "", "Last Pg.no": "",
                     "Confidence": "", "Review": "", "Detection": ""}
                self.rows.append(r)
                by_title[key] = r
            r["FIRST pg.no"] = first
            r["Last Pg.no"] = last
        if self.pdf_path:
            self.report_text = figures.build_report(Path(self.pdf_path).name, self.rows, self.figs)

    # -------------------------------------------------------------- export
    def _write_csv(self, rows, title):
        path = filedialog.asksaveasfilename(
            title=title, defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        messagebox.showinfo("Saved", f"CSV saved to:\n{path}")

    def export_csv(self):
        data = []
        for i, (label, _key) in enumerate(META_TYPES):
            v = self.tree.item(str(i), "values")
            data.append({"MetaType": label.replace(SUB_INDENT, "Description - "),
                         "Pagefrom": v[2], "Pageto": v[3]})
        if not any(str(d["Pagefrom"]) not in ("", "0") or str(d["Pageto"]) not in ("", "0") for d in data):
            messagebox.showinfo("Nothing to export", "Extract page numbers first.")
            return
        self._write_csv(data, "Save metadata")

    def save_all(self):
        if self.busy:
            return
        if not self.rows:
            messagebox.showinfo("Nothing to save", "Extract page numbers first.")
            return
        folder = filedialog.askdirectory(title="Choose where to save the report and figures")
        if not folder:
            return
        self.busy = True
        self.btn_save.state(["disabled"])
        self.btn_extract.state(["disabled"])
        self.btn_upload.state(["disabled"])
        self.progress.configure(value=0)
        self.status.config(text="Saving figures...")
        threading.Thread(target=self._save_worker, args=(folder,), daemon=True).start()
        self.after(80, self._poll)

    def _save_worker(self, folder):
        try:
            out, _report = figures.save_outputs(
                self.pdf_path, self.rows, self.figs, folder,
                progress=lambda i, n: self.q.put(("progress", i, n)))
            self.q.put(("saved", out))
        except Exception as e:
            self.q.put(("error", str(e)))


if __name__ == "__main__":
    app = PatentExtractorApp()
    app.mainloop()
