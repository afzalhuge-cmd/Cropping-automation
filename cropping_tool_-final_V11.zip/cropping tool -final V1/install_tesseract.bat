@echo off
setlocal
title Install Tesseract OCR
echo ==============================================
echo   Install Tesseract OCR (needed for the OCR box)
echo ==============================================
echo.
where tesseract >nul 2>nul
if not errorlevel 1 (
    echo Tesseract is already installed and on PATH.
    goto :done
)
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" (
    echo Tesseract is already installed in "%ProgramFiles%\Tesseract-OCR".
    goto :done
)
where winget >nul 2>nul
if errorlevel 1 (
    echo winget was not found on this PC.
    echo Download the Windows installer from:
    echo     https://github.com/UB-Mannheim/tesseract/wiki
    echo Install it with the default options ^(English language data is included^).
    goto :done
)
echo Installing with winget ...
winget install --id UB-Mannheim.TesseractOCR -e --accept-package-agreements --accept-source-agreements
:done
echo.
echo Restart the program afterwards; the status next to the OCR box should say "Tesseract found".
pause
