"""More adversarial ground-truth cases.  Run:  py test_robust.py"""
import os, sys, tempfile
import test_detector as T
from test_detector import Doc, para, claims_page, fitz, W, H
import detector

CASES = []
def case(fn): CASES.append(fn); return fn

def cover(d):
    d.text_page([("line","FORM 2"),("line","THE PATENTS ACT, 1970"),("h","COMPLETE SPECIFICATION"),
                 ("line","1. TITLE OF THE INVENTION"),("line","SMART VALVE"),("line","3. PREAMBLE TO THE DESCRIPTION"),
                 ("line","The following specification particularly describes the invention.")])

def desc(d, n=3):
    d.text_page(T.DESC_HEADINGS + [("p", para(120))])
    for _ in range(n-1): d.text_page([("p", para(230))])

@case
def statement_of_claims_heading(path):
    d=Doc(); cover(d); desc(d); d.text_page([("h","STATEMENT OF CLAIMS")]+claims_page(1,heading=None,n=5))
    d.text_page([("h","ABSTRACT"),("p",para(100))]); d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,7)}

@case
def abstract_of_invention_heading(path):
    d=Doc(); cover(d); desc(d); d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT OF INVENTION"),("p",para(100))])
    d.draw_page("FIG. 1","Sheet 1 of 2"); d.draw_page("FIG. 2","Sheet 2 of 2"); d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,8)}

@case
def abstract_before_claims(path):
    d=Doc(); cover(d); desc(d); d.text_page([("h","ABSTRACT"),("p",para(100))]); d.text_page(claims_page(1))
    d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,4),"Abstract":(5,5),"Claim":(6,6),"Drawing":(7,7)}

@case
def drawings_before_claims(path):
    d=Doc(); cover(d); desc(d); d.draw_page("FIG. 1","Sheet 1 of 2"); d.draw_page("FIG. 2","Sheet 2 of 2")
    d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))]); d.save(path)
    return {"Description":(2,4),"Drawing":(5,6),"Claim":(7,7),"Abstract":(8,8)}

@case
def tight_margin_headings(path):
    d=Doc(); cover(d); desc(d)
    d.text_page(claims_page(1), first_y=12)             # heading inside top 7 %
    d.text_page([("h","ABSTRACT"),("p",para(100))], first_y=12)
    d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,7)}

@case
def forms_after_drawings(path):
    d=Doc(); cover(d); desc(d); d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))])
    d.draw_page("FIG. 1","Sheet 1 of 1")
    d.text_page([("line","FORM 26"),("line","THE PATENTS ACT, 1970"),("line","POWER OF AUTHORITY"),("line","I, ACME LTD hereby authorise")])
    d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,7)}

@case
def claims_without_heading_numbers_only(path):
    d=Doc(); cover(d); desc(d); d.text_page(claims_page(1,heading=None,n=6)); d.text_page([("h","ABSTRACT"),("p",para(100))])
    d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,7)}

@case
def fig_mentions_inside_description(path):
    d=Doc(); cover(d)
    d.text_page(T.DESC_HEADINGS + [("p","FIG. 1 shows a block diagram. FIG. 2 shows a flow chart. "+para(120))])
    d.text_page([("line","FIG. 3 is a side view"),("line","FIG. 4 is a top view"),("p",para(200))])
    d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))]); d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,3),"Claim":(4,4),"Abstract":(5,5),"Drawing":(6,6)}

@case
def no_cover_description_first(path):
    d=Doc(); desc(d); d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))]); d.draw_page("FIG. 1",None); d.save(path)
    return {"Description":(1,3),"Claim":(4,4),"Abstract":(5,5),"Drawing":(6,6)}

@case
def long_claim_tail_with_signature(path):
    d=Doc(); cover(d); desc(d); d.text_page(claims_page(1,n=8))
    d.text_page([("p","wherein the processor is configured to determine the distance, and wherein said device comprising a sensor. "+para(20)),
                 ("line","Dated this 4th day of March 2025"),("line","Dr. A Singh"),("line","IN/PA- 5887"),("line","Agent for the Applicant")])
    d.text_page([("h","ABSTRACT"),("p",para(100))]); d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(2,4),"Claim":(5,6),"Abstract":(7,7),"Drawing":(8,8)}

@case
def two_page_cover_with_applicants(path):
    d=Doc()
    d.text_page([("line","FORM 2"),("h","COMPLETE SPECIFICATION"),("line","1. TITLE OF THE INVENTION"),("line","SMART VALVE"),
                 ("line","2. APPLICANTS"),("line","(a) A Kumar")])
    d.text_page([("line","(a) B Rao"),("line","3. PREAMBLE TO THE DESCRIPTION"),("line","The following specification describes the invention.")])
    desc(d); d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))]); d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Description":(3,5),"Claim":(6,6),"Abstract":(7,7),"Drawing":(8,8)}

@case
def drawing_page_with_flowchart_text(path):
    d=Doc(); cover(d); desc(d); d.text_page(claims_page(1)); d.text_page([("h","ABSTRACT"),("p",para(100))])
    pg=d.draw_page("FIG. 1","Sheet 1 of 1")
    for i in range(14): pg.insert_text((130,100+i*12),"RECEIVING THE INPUT WAVEFORM FROM SENSOR UNIT STEP",fontsize=6)
    d.save(path)
    return {"Description":(2,4),"Claim":(5,5),"Abstract":(6,6),"Drawing":(7,7)}

@case
def numbered_description_lists_and_bottom_heading(path):
    """Regression (v17): numbered LISTS in the description are not claims; a heading in the bottom
    7 % of the page ('DETAILED DESCRIPTION:') is body text; claims written as 'Claim 1 (...): ...'."""
    lst = [("p", "1. Provides enhanced thermal insulation and acoustic attenuation for walls."),
           ("p", "2. Reduces self-weight through a cellular insulating core."),
           ("p", "3. Improves vibration damping and crack mitigation."),
           ("p", "4. Promotes sustainable construction using industrial waste."),
           ("p", "5. Facilitates rapid construction with reduced mortar.")]
    d=Doc(); cover(d)
    d.text_page([("h","ABSTRACT:"),("p",para(100))] + T.DESC_HEADINGS + [("p", para(120))])
    d.text_page([("h","ADVANTAGES OF THE INVENTION")] + lst + [("p", para(120))])
    pg = d.text_page([("p", para(230))])
    pg.insert_text((60, H - 24), "DETAILED DESCRIPTION:", fontsize=13, fontname="hebo")   # bottom band
    d.text_page([("p", para(60))] + lst + [("p", para(60))])
    d.text_page([("p", para(80))] + lst)
    d.text_page([("h","WE CLAIM:"),
                 ("p","Claim 1 (Independent Claim): A block comprising an outer shell containing cement, "
                      "an intermediate layer containing crumb rubber and a core wherein spheres are arranged in cells."),
                 ("p","Claim 2: The block as claimed in Claim 1, wherein the core is honeycomb shaped."),
                 ("p","Claim 3: The block as claimed in Claim 1, wherein the spheres are coated.")])
    d.draw_page("FIG. 1","Sheet 1 of 1"); d.save(path)
    return {"Abstract":(2,2),"Description":(2,6),"Claim":(7,7),"Drawing":(8,8)}

def run():
    ok_docs=ok_rng=tot=0
    for fn in CASES:
        path=os.path.join(tempfile.mkdtemp(),fn.__name__+".pdf")
        exp=fn(path)
        try:
            r=detector.analyze_pdf(path)
            got={x["TITLE"]:(x["FIRST pg.no"],x["Last Pg.no"]) for x in r["rows"]}
        except Exception as e:
            print("ERROR",fn.__name__,e); tot+=len(exp); continue
        bad=[(k,got.get(k),v) for k,v in exp.items() if got.get(k)!=v]
        tot+=len(exp); ok_rng+=len(exp)-len(bad); ok_docs+=not bad
        print(("OK   " if not bad else "FAIL ")+fn.__name__, "" if not bad else bad)
    print(f"\n{ok_docs}/{len(CASES)} documents, {ok_rng}/{tot} ranges correct")
if __name__=="__main__": run()
