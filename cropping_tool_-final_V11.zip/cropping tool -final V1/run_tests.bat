@echo off
py -m pip install -r requirements.txt
py test_detector.py
py test_extra.py
py test_robust.py
py test_figures.py
py test_stacked.py
py test_decimal.py
py test_tablecont.py
py test_tables.py
py test_ocr.py
py test_sheets.py
py test_sequence.py
py test_subsections.py
py test_claimtail.py
pause
