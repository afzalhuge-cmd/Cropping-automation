"""
Regression tests for a real Patent Office download (Application 202531076975):

 1. "Application Number - ... Granted Specification - Page N" is stamped just OUTSIDE the visible
    page box, so normal text extraction never returned it and the 'Printed page' column stayed empty.
 2. The drawing sheet has the header "No. of Sheet: 1 / Sheet No. 1" and ONE big embedded picture whose
    "Fig. 1" caption is only pixels.  It was classified as Abstract, so no drawing / figure came out.

No OCR needed.   py test_sheets.py
"""
import os
import sys
import tempfile

import numpy as np
import cv2

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz

import detector
import figures
import test_detector as T

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name + (("   " + detail) if detail else ""))


def picture_png():
    img = np.full((457, 702, 3), 255, np.uint8)
    cv2.rectangle(img, (60, 120), (640, 160), (0, 0, 0), 2)
    cv2.rectangle(img, (60, 300), (640, 340), (0, 0, 0), 2)
    cv2.rectangle(img, (250, 160), (420, 300), (120, 60, 0), -1)
    cv2.circle(img, (330, 230), 30, (255, 255, 255), -1)
    return cv2.imencode(".png", img)[1].tobytes()


def signature_png():
    img = np.full((80, 236, 3), 255, np.uint8)
    cv2.putText(img, "signature", (10, 50), cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 1.4, (0, 0, 0), 2)
    return cv2.imencode(".png", img)[1].tobytes()


def build():
    """cover, description, claims, abstract (with 'Fig. 1.'), drawing sheet.  Every page carries the
    stamp below the visible area; the media box is cut so the stamp is outside the page."""
    d = T.Doc()
    d.text_page([("p", "COMPLETE SPECIFICATION  FORM-2  THE PATENTS ACT, 1970  The following specification "
                       "particularly describes the invention and the manner in which it is to be performed.")])
    d.text_page([("h", "FIELD OF INVENTION:"), ("p", T.para(120)), ("h", "SUMMARY OF THE INVENTION:"),
                 ("p", T.para(80))])
    d.text_page(T.claims_page(1))
    d.text_page([("h", "ABSTRACT"), ("p", T.para(90)), ("p", "Fig. 1.")])
    path0 = os.path.join(tempfile.mkdtemp(), "base.pdf")
    d.save(path0)
    doc = fitz.open(path0)
    # drawing sheet: header, big picture, small signature picture
    pg = doc.new_page(width=595, height=842)
    pg.insert_text((44, 67), "Indian Institute of Technology, Dhanbad            No. of Sheet: 1",
                   fontsize=11, fontname="hebo")
    pg.insert_text((400, 80), "Sheet No. 1", fontsize=11, fontname="hebo")
    pg.insert_image(fitz.Rect(44, 142, 530, 459), stream=picture_png())
    pg.insert_image(fitz.Rect(285, 555, 370, 584), stream=signature_png())
    pg.insert_text((250, 600), "Patent Agent (Regd. No. IN/PA-3198)", fontsize=12, fontname="hebo")
    for i, page in enumerate(doc):
        page.insert_text((150, 830), f"Application Number - 202531076975 Granted Specification - Page {i + 1}",
                         fontsize=10, fontname="helv")
        page.set_mediabox(fitz.Rect(0, 67, 595, 842))      # hides the bottom 67 pt incl. the stamp
    path = os.path.join(tempfile.mkdtemp(), "stamped.pdf")
    doc.save(path)
    return path, path0


def main():
    path, baseline = build()
    doc = fitz.open(path)
    p = doc[1]
    hidden = "Granted Specification" not in p.get_text()
    check("setup: stamp is outside the visible page box (normal extraction cannot see it)",
          hidden and p.rect.height < 800, f"page height {p.rect.height:.0f}")

    r = detector.analyze_pdf(path)
    printed = [x["Printed page"] for x in r["page_rows"]]
    check("printed page numbers read from the clipped stamp", printed == ["1", "2", "3", "4", "5"], str(printed))
    got = {x["TITLE"]: (x["FIRST pg.no"], x["Last Pg.no"]) for x in r["rows"]}
    exp = {"Abstract": (4, 4), "Description": (2, 2), "Claim": (3, 3), "Drawing": (5, 5)}
    check("sections: 'No. of Sheet / Sheet No.' sheet + big picture = Drawing, not Abstract",
          all(got.get(k) == v for k, v in exp.items()), str(got))
    base_words = detector.analyze_pdf(baseline)["page_rows"][1]["Words"]       # same page, no stamp
    check("stamp text never leaks into the word count", r["page_rows"][1]["Words"] == base_words,
          f"words p.2 = {r['page_rows'][1]['Words']} (without stamp: {base_words})")

    figs = figures.find_figures(path, use_ocr=False, skip_pages=figures.pages_to_skip(r["rows"]),
                                drawing_pages=figures.drawing_pages_of(r["rows"]))
    ok = len(figs) == 1 and figs[0]["page"] == 5 and figs[0]["label"] == "FIG. 1"
    check("uncaptioned drawing sheet still yields FIG. 1 (flagged)", ok and figs[0]["note"] == figures.UNLABELED_NOTE,
          str([(f["label"], f["page"], f["note"][:30]) for f in figs]))
    if ok:
        x0, y0, x1, y1 = figs[0]["crop"]
        # crop = the big picture; it must not reach down to the signature (y>=555) or up to the header (y<130)
        check("crop covers the picture only (no header / signature)",
              x0 <= 50 and x1 >= 525 and y0 >= 120 and y1 <= 480, f"crop = {[round(v) for v in figs[0]['crop']]}")
    abstract_fig = figures.find_figures(path, use_ocr=False, skip_pages=None, drawing_pages=None)
    check("auto mode (no ranges passed) gives the same single figure", len(abstract_fig) == 1)

    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
