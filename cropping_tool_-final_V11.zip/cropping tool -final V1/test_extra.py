"""Harder ground-truth cases (independent of the first test-suite).  Run:  py test_extra.py [new|old]"""
import os, sys, tempfile
import test_detector as T
from test_detector import Doc, para, claims_page, fitz, W, H

CASES = []
def case(fn): CASES.append(fn); return fn

@case
def inid_front_page_abstract(path):
    """Journal-style: bibliographic front page carries the (57) Abstract; then spec, claims, drawings."""
    d = Doc()
    d.text_page([("line", "(12) PATENT APPLICATION PUBLICATION"), ("line", "(19) INDIA"),
                 ("line", "(21) Application No.202441012345 A"), ("line", "(22) Date of filing of Application :20/02/2024"),
                 ("line", "(43) Publication Date : 30/08/2024"),
                 ("line", "(54) Title of the invention : SMART VALVE CONTROL SYSTEM"),
                 ("line", "(71)Name of Applicant : ACME LTD"), ("line", "(72)Name of Inventor : A KUMAR"),
                 ("line", "(57) Abstract :"), ("p", para(90)),
                 ("line", "No. of Pages : 12 No. of Claims : 5")])
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(80)), ("h", "BACKGROUND OF THE INVENTION"), ("p", para(140))])
    d.text_page([("h", "SUMMARY OF THE INVENTION"), ("p", para(220))])
    d.text_page([("h", "DETAILED DESCRIPTION"), ("p", para(220))])
    d.text_page(claims_page(1, heading="CLAIMS", n=5))
    for i in range(2):
        d.draw_page(f"FIG. {i+1}", f"Sheet {i+1} of 2")
    d.save(path)
    return {"Abstract": (1, 1), "Description": (2, 4), "Claim": (5, 5), "Drawing": (6, 7)}

@case
def wrapped_and_spaced_headings(path):
    d = Doc()
    d.text_page([("h", "TITLE OF THE INVENTION"), ("p", "Valve"), ("h", "FIELD OF THE INVENTION"), ("p", para(60)),
                 ("h", "BACKGROUND OF THE INVENTION"), ("p", para(120))])
    d.text_page([("h", "BRIEF DESCRIPTION OF"), ("h", "THE DRAWINGS"),
                 ("line", "FIG. 1 illustrates a block diagram."), ("line", "FIG. 2 shows a flow chart."),
                 ("h", "DETAILED DESCRIPTION OF THE INVENTION"), ("p", para(160))])
    d.text_page([("p", para(230))])
    d.text_page([("h", "C L A I M S")] + claims_page(1, heading=None, n=5))
    d.text_page([("h", "A B S T R A C T"), ("p", para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Abstract": (5, 5), "Description": (1, 3), "Claim": (4, 4), "Drawing": (6, 6)}

@case
def every_heading_in_users_list(path):
    d = Doc()
    d.text_page([("h", "TITLE OF THE INVENTION"), ("p", "Valve"), ("h", "TECHNICAL FIELD"), ("p", para(60)),
                 ("h", "STATE OF THE ART"), ("p", para(120))])
    d.text_page([("h", "OBJECTS OF THE INVENTION"), ("p", para(60)), ("h", "ADVANTAGES OF THE PRESENT INVENTION"),
                 ("p", para(60)), ("h", "PRESENTATION OF THE INVENTION"), ("p", para(80))])
    d.text_page([("h", "DESCRIPTION OF THE PREFERRED EMBODIMENTS"), ("p", para(140)),
                 ("h", "WORKING EXAMPLES"), ("p", para(80))])
    d.text_page([("h", "INDUSTRIAL APPLICABILITY"), ("p", para(50)), ("h", "ADVANTAGEOUS EFFECTS"), ("p", para(50)),
                 ("h", "CITATION LIST"), ("h", "NON-PATENT LITERATURE"), ("p", para(30))])
    d.text_page([("h", "WHAT IS CLAIMED IS:")] + claims_page(1, heading=None, n=5)[0:])
    d.text_page([("h", "ABSTRACT"), ("p", para(100))])
    d.draw_page("FIG. 1", "1/1")
    d.save(path)
    return {"Abstract": (6, 6), "Description": (1, 4), "Claim": (5, 5), "Drawing": (7, 7)}

@case
def brief_description_spills_to_next_page(path):
    """Figure list continues on the next page (no heading, FIG lines) - must stay Description."""
    d = Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(50)), ("h", "BRIEF DESCRIPTION OF THE DRAWINGS")] +
                [("line", f"FIG. {k} is a view of part {k} of the assembly.") for k in range(1, 12)])
    d.text_page([("line", f"FIG. {k} is a sectional view of part {k}.") for k in range(12, 22)] +
                [("h", "DETAILED DESCRIPTION"), ("p", para(120))])
    d.text_page([("p", para(230))])
    d.text_page(claims_page(1, heading="We claim:", n=5))
    d.text_page([("h", "ABSTRACT"), ("p", para(90))])
    for i in range(3):
        d.draw_page(f"FIG. {i+1}", f"Sheet {i+1} of 3")
    d.save(path)
    return {"Abstract": (5, 5), "Description": (1, 3), "Claim": (4, 4), "Drawing": (6, 8)}

@case
def abstract_after_drawings(path):
    d = Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(60)), ("h", "BACKGROUND"), ("p", para(120))])
    d.text_page([("h", "DETAILED DESCRIPTION"), ("p", para(230))])
    d.text_page(claims_page(1, heading="CLAIMS", n=6))
    d.draw_page("FIG. 1", "Sheet 1 of 2")
    d.draw_page("FIG. 2", "Sheet 2 of 2")
    d.text_page([("h", "ABSTRACT"), ("p", para(100))])
    d.save(path)
    return {"Abstract": (6, 6), "Description": (1, 2), "Claim": (3, 3), "Drawing": (4, 5)}

@case
def blank_page_inside_description(path):
    d = Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(60)), ("h", "BACKGROUND OF THE INVENTION"), ("p", para(140))])
    d.doc.new_page(width=W, height=H)                       # blank page in the middle
    d.text_page([("h", "DETAILED DESCRIPTION"), ("p", para(230))])
    d.text_page(claims_page(1, heading="We claim:", n=5))
    d.text_page([("h", "ABSTRACT"), ("p", para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Abstract": (5, 5), "Description": (1, 3), "Claim": (4, 4), "Drawing": (6, 6)}

@case
def claims_continue_on_short_last_page(path):
    """Long claim set; last claims page is short and carries the signature block."""
    d = Doc()
    d.text_page([("h", "FIELD OF THE INVENTION"), ("p", para(60)), ("h", "SUMMARY"), ("p", para(140))])
    d.text_page([("h", "DETAILED DESCRIPTION"), ("p", para(220))])
    d.text_page(claims_page(1, heading="I/We claim:", n=7))
    d.text_page(claims_page(8, heading=None, n=6))
    d.text_page(claims_page(14, heading=None, n=1) + [("line", "Dated this 3rd day of March 2024"), ("line", "Signature"), ("line", "Patent Agent")])
    d.text_page([("h", "ABSTRACT"), ("p", para(110))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Abstract": (6, 6), "Description": (1, 2), "Claim": (3, 5), "Drawing": (7, 7)}

@case
def description_without_any_headings(path):
    d = Doc()
    d.text_page([("p", para(230))]); d.text_page([("p", para(230))]); d.text_page([("p", para(230))])
    d.text_page(claims_page(1, heading="CLAIMS", n=6))
    d.text_page([("h", "ABSTRACT"), ("p", para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    d.save(path)
    return {"Abstract": (5, 5), "Description": (1, 3), "Claim": (4, 4), "Drawing": (6, 6)}

def run(engine):
    fn_engine = T._new_engine
    tmp = tempfile.mkdtemp(); okc = oks = tot = 0
    for fn in CASES:
        path = os.path.join(tmp, fn.__name__ + ".pdf"); exp = fn(path)
        n, got, warns = fn_engine(path, False)
        line = []; ok_case = True
        for name in ("Abstract", "Description", "Claim", "Drawing"):
            g = got[name][0]; ok = g == exp[name]; ok_case &= ok; tot += 1; oks += ok
            if not ok: line.append(f"{name}: got {g} expected {exp[name]}")
        okc += ok_case
        print(f"  {'OK  ' if ok_case else 'FAIL'} {fn.__name__:38s} {'; '.join(line)}")
    print(f"[{engine}] {okc}/{len(CASES)} docs, {oks}/{tot} ranges\n")

if __name__ == "__main__":
    for e in ["new"]: run(e)
