"""Claims that run on over pages without '1.' / 'claim N' patterns (long last method claim) + signature.
py test_claimtail.py"""
import os, sys, tempfile
import detector
import test_detector as T

LONG = ("receiving an image through the interface; preprocessing the image wherein the image is aligned; "
        "validating the aligned document comprising a plurality of operations configured to run; ") * 4


def main():
    d = T.Doc()
    d.text_page([("p", "COMPLETE SPECIFICATION FORM-2 THE PATENTS ACT, 1970 The following specification "
                       "particularly describes the invention and the manner in which it is to be performed.")])
    for k in range(3):
        d.text_page([("h", "DETAILED DESCRIPTION" if k == 0 else ""), ("p", "[00%02d] " % (k + 1) + T.para(160))])
    d.text_page(T.claims_page(1))
    d.text_page([("p", LONG)])
    d.text_page([("p", "wherein said step is repeated. " + LONG[:300]), ("line", "Dated this 17 August 2026"),
                 ("line", "(Agent for the applicant)"), ("line", "Reg. No.: IN/PA-1773")])
    d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    path = os.path.join(tempfile.mkdtemp(), "tail.pdf")
    d.save(path)
    rows = {r["TITLE"]: (r["FIRST pg.no"], r["Last Pg.no"]) for r in detector.analyze_pdf(path)["rows"]}
    ok = rows.get("Claim") == (5, 7) and rows.get("Abstract") == (8, 8)
    print(("PASS  " if ok else "FAIL  ") + "claims extend over unnumbered pages up to the signature", rows)

    # last claim spills onto a short page that uses "comprise" (not "comprising/wherein/said") and ends with
    # the agent's signature: that page is still the claims, never the abstract
    d = T.Doc()
    d.text_page([("p", "COMPLETE SPECIFICATION FORM-2 THE PATENTS ACT, 1970 The following specification "
                       "particularly describes the invention and the manner in which it is to be performed.")])
    for k in range(3):
        d.text_page([(("h", "DETAILED DESCRIPTION") if k == 0 else ("h", "")), ("p", "[00%02d] " % (k + 1) + T.para(160))])
    d.text_page(T.claims_page(1))
    d.text_page([("p", "distilled water, methanol, ethanol, or a mixture thereof, the carbon fibers comprise an "
                       "amount of 70-99% and the metal particles comprise an amount of 30-1%."),
                 ("line", "Dated this 10th day of December 2024"), ("line", "Saurabh Kumar Jain"),
                 ("line", "(IN/PA-3637)"), ("line", "Agent of the Applicant")])
    d.text_page([("h", "ABSTRACT"), ("p", T.para(90))])
    d.draw_page("FIG. 1", "Sheet 1 of 1")
    path2 = os.path.join(tempfile.mkdtemp(), "tail2.pdf")
    d.save(path2)
    rows2 = {r["TITLE"]: (r["FIRST pg.no"], r["Last Pg.no"]) for r in detector.analyze_pdf(path2)["rows"]}
    ok2 = rows2.get("Claim") == (5, 6) and rows2.get("Abstract") == (7, 7)
    print(("PASS  " if ok2 else "FAIL  ") + "signature page with few claim words stays in the claims, abstract is only its own page", rows2)
    return 0 if (ok and ok2) else 1


if __name__ == "__main__":
    sys.exit(main())
