"""Table detection checks.  Run:  py test_tables.py
Uses a synthetic PDF (ruled tables with captions above) so it needs no sample file."""
import os, tempfile
import fitz
import figures

def build(path):
    doc = fitz.open()
    def page_with(tables, extra_heading=None):
        pg = doc.new_page(width=495, height=764)
        pg.insert_text((60, 70), "Some description text about the invention goes here.", fontsize=10)
        if extra_heading:
            pg.insert_text((60, 700), extra_heading, fontsize=10)
        for (y, cap, rows) in tables:
            pg.insert_text((220, y - 8), cap, fontsize=10)
            for r in range(rows + 1):
                pg.draw_line((100, y + r * 22), (400, y + r * 22))
            for c in (100, 200, 300, 400):
                pg.draw_line((c, y), (c, y + rows * 22))
            for r in range(rows):
                pg.insert_text((108, y + r * 22 + 15), f"cell {r}", fontsize=9)
                pg.insert_text((208, y + r * 22 + 15), "1.0", fontsize=9)
    page_with([(150, "Table 1", 4)])
    page_with([(120, "TABLE 2: Results", 3), (400, "Table 3", 3)], extra_heading="Table 4: Next result")
    page_with([(150, "Table 4", 3)])
    page_with([])                                     # no table
    doc.save(path)

def run():
    path = os.path.join(tempfile.mkdtemp(), "t.pdf"); build(path)
    got = [(t["label"], t["page"]) for t in figures.find_tables(path, skip_pages=())]
    exp = [("TABLE 1", 1), ("TABLE 2", 2), ("TABLE 3", 2), ("TABLE 4", 3)]
    ok = got == exp
    print(("OK   " if ok else "FAIL ") + "synthetic tables", "" if ok else (got, exp))
    # a heading that introduces a table on the next page must not become a table itself
    ok2 = all(t["type"] == "TN" and t["kind"] == "table" for t in figures.find_tables(path, skip_pages=()))
    print(("OK   " if ok2 else "FAIL ") + "type TN")
    print(f"\n{int(ok)+int(ok2)}/2 checks passed")

if __name__ == "__main__":
    run()
