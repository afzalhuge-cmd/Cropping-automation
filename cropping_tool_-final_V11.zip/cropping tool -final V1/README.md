# Indian Patent Page Number Extractor - Windows Desktop Version

Native Windows GUI (Python/Tkinter + PyMuPDF). Upload an Indian patent PDF and get

    MetaType | Pagefrom | Pageto

for **Abstract, Claims, Description, Drawings** in an "Add Metadata" table on the front page.
The Sequence Listing is part of the Description, so the Description range includes it when it closes the description.
Double-click a Pagefrom / Pageto box to correct it by hand; Export CSV and the saved report use your edits.
Below it a **Drawings** table lists every FIG. found (SNo., Page No, Type, Image Id, Action): click the arrow in Image Id to save that figure as JPG, Type is PN (Figure) or TN (Table) - click the Type box to switch it; click the eye icon in View to preview the figure (zoom, Fit, Prev/Next, arrow keys); click the red cross to drop it from the list (it is then skipped by Save report + figures). Page numbers are PDF page positions
(page 1 = first page of the file).

## Run / build

    run_source.bat        (runs from source)
    build_exe.bat         (builds dist\Indian_Patent_Page_Extractor.exe)
    run_tests.bat         (self-tests on generated sample patents)

Command line (handy for checking many PDFs):

    py detector.py patent.pdf --pages          # add --ocr for scanned files (needs Tesseract)

## How detection works

1. **Real headings only.** A line counts as a heading only if it starts with a heading
   pattern (Title of invention, Technical field, Background, Prior art, Summary,
   Brief description of drawings, Detailed description, Claims / What is claimed is /
   We claim, Abstract ...) *and* is heading-shaped: short, stand-alone, capitals/bold/
   larger font, or "Heading: text". A sentence such as "as described in the prior art"
   is ignored. Numbering ("4.", "(57)", "IV.") is stripped, letter-spaced headings
   ("C L A I M S") and headings wrapped over two lines are handled.
2. **"Brief description of the drawings" belongs to the Description**, not the Drawing
   section. Drawing pages are recognised by sheet markers ("Sheet 2 of 5", "2/5"),
   FIG labels, images/vector graphics and almost no prose.
3. **Claims** are confirmed by content ("1.", "2." numbering, "as claimed in claim 1").
4. **Section order is not assumed.** Each page is scored for every section, then the best
   page-by-page labelling is chosen with each section forced to be one contiguous block.
   So Description > Claims > Abstract > Drawings, Abstract-first (INID 57 on the journal
   front page) and Abstract-after-drawings all work.
5. **Shared pages.** If the Description ends and "WE CLAIM" starts on the same page (or
   the Abstract sits under the last claims) both sections report that page.
6. **Forms in the same PDF** (Form 1, 3, 5, 26, ...) and cover pages are ignored.
7. **Cross-checks** raise warnings: "No. of Claims" on the front page vs numbered claims
   found, sheet "n of N" vs drawing pages found, several Claims/Abstract headings,
   figures mentioned but no drawing pages, scanned PDF without OCR.

Detection details are still available from the command line (`py detector.py patent.pdf --pages`).

## OCR (Tesseract + OpenCV)

OCR is used for (1) scanned pages that have no text layer and (2) drawings whose "FIG. 1" captions are
part of a picture. It is **lightweight**: the small `tesseract` program does the reading and OpenCV cleans the
page first (evens out shadows / yellow paper, straightens a tilted scan, removes scanner noise). There are no
models to download and nothing to load - OCR starts instantly and several pages are read at the same time.

**Set up once (Windows)**

    install_tesseract.bat        (uses winget; or install from https://github.com/UB-Mannheim/tesseract/wiki)

The status next to the OCR box then says "Tesseract found - OCR on" and the box is ticked automatically.
OCR only touches pages that need it, so leaving it on costs nothing for normal PDFs with a text layer.

**No install on other PCs (portable / inside the exe)**

    prepare_tesseract.bat        (copies the installed Tesseract into .\tesseract)
    build_exe.bat                (packs .\tesseract into the exe)

The program looks for Tesseract in this order: environment variable `TESSERACT_CMD`, a `tesseract` folder next to
the program / inside the exe, `PATH`, then the usual install folders (`C:\Program Files\Tesseract-OCR` ...).
Set `PATENT_OCR_WORKERS=2` (for example) to change how many pages are read in parallel (default: up to 4).

Python: any recent 3.x; `requirements.txt` = PyMuPDF, opencv-python-headless, numpy.

Limits: pages scanned sideways (rotated 90 degrees) are not turned upright; a very noisy page is skipped after
45 seconds instead of freezing the program.

## Honest limits

Tested on generated sample patents (`test_detector.py`, `test_extra.py`: 16 layouts,
`test_ocr.py` checks the OCR and picture-only drawings and is skipped when Tesseract is not installed). It has **not** been validated on a large set of real Indian patent PDFs.
For real-world tuning, run `py detector.py file.pdf --pages` on files that come out wrong;
the per-page evidence shows which rule fired. Weights are constants at the top of
`detector.py` (`ORDER_PEN`, `SWITCH_COST`) and in `page_emissions()`.


## Figures (FIG. 1, FIG. 2 ...)

After "Extract Page Numbers" the **Figures** tab lists every figure label found, the PDF page
it is on and the file name it will get (`figure_001.jpg`, `figure_002A.jpg` for FIG. 2A).
The **Report** tab shows the result in copy/paste form:

    Patent.pdf

    Abstract       -> PDF pages 2-2
    Description    -> PDF pages 3-15
    Claims         -> PDF pages 16-20
    Drawings - PDF pages 21-22

    Drawing:
    FIG. 1 -> PDF page 7 -> figure_001.jpg

**Save report + figures** writes `<pdf name>_output/` with the report `.txt` and a `figures/`
folder of JPGs. Command line: `py figures.py Patent.pdf [--ocr] [--out DIR] [--dpi 200]`.

* A figure is found by a label that stands alone on its line ("FIG. 1"), on drawing sheets and on
  description pages that contain the picture. Sentences like "FIG. 1 is a perspective view" are ignored.
* If two figures share one picture, it is cut at the labels (the row is yellow - check the crop).
* If a label repeats on another page, the first page is used and the others are noted.
* Scanned drawings, and drawings whose captions are part of a picture, need OCR so the labels can be read.
  Several figures on ONE picture are cut apart along drawn panel borders (OpenCV), else at the blank space
  between them, else by grouping the drawing around each label; the note column says which, and such rows
  are yellow - check the crop.

Accuracy notes (v14): rows the detector is unsure about are highlighted yellow on the front page, and any
page inside the document that no section claimed is listed as a warning. Fix a value by double-clicking it.
Run `run_tests.bat` (or `py test_detector.py`, `py test_extra.py`, `py test_robust.py`) after changing detector.py.

Tables (v16): captions such as "Table 1" / "TABLE 2: Results" that sit above a boxed or ruled table are listed in the
Drawings table with Type TN (Table) and Image Id T1, T2 ...  View (eye), save (arrow) and remove (cross) work the same as for
figures; Save report + figures writes table_001.jpg ... and a "Tables:" section in the report. A heading that only introduces
a table printed on the next page is ignored (the table is found through its own caption). Tables with no ruling/border and
tables that continue over several pages are not detected yet.
Run `py test_tables.py` to check this.


Page numbers (v17 fixes): text in the top/bottom 7 % of a page is only ignored as header/footer when it looks like one
(long sentences and headings such as "DETAILED DESCRIPTION:" at the very bottom are body text); numbered lists in the
description ("1. Provides ...") are no longer mistaken for numbered claims - an item counts as a claim only if it refers
to another claim or reads like one (comprising / wherein / consisting ...); "Claim 1: ..." style claims are recognised.

OCR (v18): PaddleOCR replaced by Tesseract + OpenCV (see "OCR" above); captions inside a raster picture are read even when
the page has a text layer; new Clear button / OCR status note in the window; warning when drawing pages are found but no
FIG. labels could be read.

Drawing sheets / page numbers (v19): a drawing sheet marked "No. of Sheet: 1 / Sheet No. 1" (not only "Sheet 1 of 1") and
a page that is mostly one big picture are recognised as Drawing, so they are no longer mistaken for Abstract continuation;
page-number stamps such as "Application Number - ... Granted Specification - Page 2" are read for the Printed column even
when the stamp lies just outside the visible page box; and a recognised drawing sheet whose "FIG." captions cannot be read
(picture-only captions, OCR off) still produces a flagged crop numbered by order instead of nothing.

Sequence Listing (v20): a sequence listing (WIPO ST.26 tables - "Sequence Listing", "Sequence Number [ID]", "Residues" ... - or
ST.25 "<210>/<400>" tags) is the LAST PART OF THE DESCRIPTION.  It gets its own "Sequence Listing" row (first/last page), the
Description range includes it when it closes the description (before the claims), and the per-page table marks its pages
"Description (Sequence Listing)".  A listing attached after the claims / drawings can never become Drawing or Abstract: it stays a
separate row, kept apart from the Description, and the detection note says where it was found.  A few "SEQ ID NO" mentions or a CDR
table in the description do not count as a listing; the row stays blank when there is none (it is optional and never flagged as
"not detected").  Listing pages are skipped by the figure search, and a bare number near the page edge inside a listing is not read
as a printed page number.


## Scanned PDFs and sideways drawings (v22)

For a scanned PDF (no text layer) tick **Use OCR**, otherwise every page is taken for a drawing.
Drawings printed sideways on a portrait sheet are read by turning the picture 90 degrees, so their
"FIG. n" captions are found; they are saved upright with the sheet header ("Applicant ... 41 Sheets", "1/41")
and empty margins trimmed. A section with no page number shows 0 in the Add Metadata table.

## Clipped drawing sheets and stacked figures (v25)

Some PDFs store the drawing sheets with a page size (MediaBox) smaller than the sheet itself (CropBox), so
viewers cut the figures off ("NETWOR / K") and half the figures seem to be missing. The tool now opens such
pages at their full size. A white page-sized background no longer merges all drawings into one block, and
for sheets with several figures stacked one above the other the captions are paired with the picture on the
side where they are printed (normally below), so each figure is saved with its own "FIG. n" caption.

## Several figures inside one scanned picture (v26)

When one scanned picture holds two figures (e.g. Fig. 6 and Fig. 7 on the same sheet), the picture is now cut
right after each "Fig. n" caption (or right before it, if the captions are printed above their figures),
instead of at a blank band that can fall inside a figure. Scanned sheets need **Use OCR** so the captions can
be read.

## Claims that run over several pages (v27)

The last claim (often a long method claim) can fill whole pages without any "1." or "claim N" wording, and the
signature page after it was left out of the Claims range. Pages after the claims that read like claim wording
(no [0001]-style paragraph numbers) are now added up to the attorney's signature, before the Abstract.


## v28 - decimal figure numbers and many figures on one scanned sheet

* Captions such as `FIG. 1.1`, `FIG. 10.7`, `FIG.6.1`, `FIG. 8.3(100)` are now recognised (file names `figure_001_1.jpg`,
  `figure_010_7.jpg`). Several captions that OCR returns as ONE line (`FIG. 9.0 FIG. 9.1 FIG. 9.2`) are cut apart using the
  exact word positions from Tesseract; a dropped dot (`FIG. 91` on a sheet of 9.x figures) is repaired; running text
  ("figures 3.2 and 3.3 illustrate ...") is never taken for a caption.
* New crop method for 2 or more figures on one picture ("drawing grown around each caption"): header, office stamp and
  signatures are removed, every caption claims the drawing next to it (above or below, detected per caption) and absorbs
  nearby pieces, and a crop is never allowed to swallow another figure's caption. Drawn panel borders are still tried first.
* The Drawings list is ordered by page, then figure number.
* New self-test: `py test_decimal.py`.


## v29 - tables: correct crops and continuation tables

* Tables are found from their own ruling (touching horizontal + vertical lines). Before, a caption could be matched
  to a bogus "box" covering the paragraph text above it, so the crop was mostly body text.
* A table that runs onto the next page(s) is saved once per page and numbered **TABLE 1**, **TABLE 1.1**, **TABLE 1.2** ...
  (files `table_001.jpg`, `table_001_1.jpg`, `table_001_2.jpg`). A continuation is a ruled table at the top of the
  next page, with no caption, the same width as the table that ended the previous page at the bottom of its page.
  A caption such as "Table 1 (contd.)" is also understood. The report marks it "continuation of TABLE 1".
* New self-test: `py test_tablecont.py`.


## v30 - claim tail / abstract page range

* A short page that closes the claims (last claim running on, "Dated ...", agent's name and IN/PA number) is now kept in the
  Claims even when it has none of the usual claim words (wherein / comprising / said). It was being read as the Abstract,
  so Abstract started one page too early (for example 18-19 instead of 19-19, Claims 15-17 instead of 15-18).
  A page carrying the agent's signature block is never taken for an unheaded abstract.
* Test added to `test_claimtail.py`.


## v31 - drawings whose lettering is vector outlines

* Some PDFs draw the whole figure - including "FIG. 1" and the reference numerals - as vector outlines, so there is no text
  layer and no embedded picture. With OCR on, the vector artwork of a drawing sheet is now OCR'd like a picture
  (also turned sideways), so the figure numbers are read. A caption read as just "FIG" is re-read from a zoomed-in strip.
* A sheet with one vector figure is cropped around ALL of the artwork (caption, arrows and callout numbers are no longer
  cut off), and the crop never runs into the sheet header, the footer or the agent's signature.

## Two figures in one image - how it is prevented (v38)

Every figure crop goes through these safeguards (`figures.py`):

1. Reference numerals (100, 2, 101 ...) are attached only to the picture that is nearest to them and never chain
   into the neighbouring figure.
2. When several captions share one picture, each cutting method (borders, blank gaps, minimum-ink cut, connected
   ink, caption side ...) is **validated**: a crop that holds another figure's caption, overlaps its neighbour
   or loses drawing ink is rejected and the next method is tried.
3. Figures side by side whose leader lines interleave get a complete box each; the neighbour's numerals and
   fragments inside it are erased (white) when the JPG is made.
4. Safety net on every sheet: a crop that still holds another figure's caption is re-split, thin overlap strips are
   cut in the middle, and the printed sheet header / signature block is trimmed off.
5. `audit_overlaps()` flags any two figures of one sheet whose crops still overlap (note shows `WARNING: crop overlaps ...`).

`py test_stacked.py` checks the failing layouts; `py test_stacked.py some_patent.pdf` audits a real PDF
(prints every figure that is flagged).
