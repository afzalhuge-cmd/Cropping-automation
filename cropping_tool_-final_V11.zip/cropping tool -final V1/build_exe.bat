@echo off
setlocal
title Indian Patent Page Extractor - EXE Builder

echo ==============================================
echo   Indian Patent Page Number Extractor
echo   Windows EXE Builder
echo ==============================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python 3.10+ and select "Add Python to PATH".
    pause
    exit /b 1
)

if not exist tesseract\tesseract.exe (
    echo NOTE: no .\tesseract folder. The exe will need Tesseract installed on the PC that runs it.
    echo       To bundle it: run install_tesseract.bat, then prepare_tesseract.bat, then build again.
    echo.
)

echo [1/4] Upgrading pip...
py -m pip install --upgrade pip
if errorlevel 1 goto :error

echo [2/4] Installing dependencies...
py -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo [3/4] Installing PyInstaller...
py -m pip install pyinstaller
if errorlevel 1 goto :error

echo [4/4] Building EXE...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

py -m PyInstaller --clean --noconfirm Indian_Patent_Page_Extractor.spec
if errorlevel 1 goto :error

echo.
echo ==============================================
echo BUILD COMPLETE
echo ==============================================
echo EXE:
echo %CD%\dist\Indian_Patent_Page_Extractor.exe
echo.
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Check the error above.
pause
exit /b 1
