"""
Indian patent section / page-range detector.

No GUI code lives here so the logic can be tested from the command line:

    python detector.py some_patent.pdf [--ocr] [--pages]

How it works (short version)
----------------------------
1. Read every page as positioned text lines (font size, bold, position).
2. Find *real headings*: a line only counts as a heading when it starts with one
   of the HEADING patterns AND is heading-shaped (short, stand-alone, caps/bold/
   larger, or "Heading: text"). Body sentences that merely contain the words
   "prior art" or "background" are ignored.
3. Score every page for Description / Claim / Abstract / Drawing / Other using
   headings + content evidence (numbered claims, "of claim 1", "Sheet 2 of 5",
   FIG. labels, word count, images / vector drawings, Form 1 / Form 3 markers).
4. Decode the best page-by-page labelling with dynamic programming, under the
   rule that each section is one contiguous block. Section order is NOT assumed
   (Indian PDFs come as Description > Claims > Abstract > Drawings, or with the
   Abstract on the front page (INID 57), etc.).
5. Fix shared pages (a page where the Description ends and "WE CLAIM" begins is
   the last Description page AND the first Claim page).
6. Cross-check (sheet "n of N", "No. of Claims", figures mentioned but no drawing
   pages, ...) and report confidence + evidence + warnings.
"""

import os
import re
import statistics
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

try:
    import pymupdf as fitz  # PyMuPDF >= 1.24.3
except ImportError:  # pragma: no cover
    try:
        import fitz  # older PyMuPDF
    except ImportError:
        fitz = None

try:  # OCR = Tesseract (command line) + OpenCV; both are optional unless "Use OCR" is ticked
    import numpy as np
    import ocr_engine
except Exception as _exc:  # pragma: no cover
    np = None

    class ocr_engine:  # minimal stand-in so the rest of the program still works without OCR
        class OcrUnavailable(RuntimeError):
            pass

        @staticmethod
        def find_tesseract():
            raise ocr_engine.OcrUnavailable("OCR needs: py -m pip install opencv-python-headless numpy ("
                                            + str(_exc) + ")")

        @staticmethod
        def available():
            return False, "OCR needs: py -m pip install opencv-python-headless numpy"


_CLAIM_BANNER = re.compile(
    r"^\s*(amended|replacement|revised|substitute|clean)\s+(set\s+of\s+)?claims?\b"
    r"|^\s*claims?\s*\(\s*(clean|amended|marked|revised)", re.I)

FORM2_DESC_WORDS = 450   # Form 2 pages with fewer words are cover pages

SECTION_ORDER = ["Abstract", "Description", "Claim", "Drawing"]   # display order
SECTION_LIST = ["Description", "Claim", "Abstract", "Drawing"]    # decoder order
LABELS = ["Other"] + SECTION_LIST

# --------------------------------------------------------------------------
# HEADING PATTERNS
# --------------------------------------------------------------------------

# The list you supplied, split by the section each heading belongs to.
DESCRIPTION_HEADINGS = [
    r"title of (the )?invention",
    r"technical (area|field)",
    r"field of (the )?invention",
    r"field of (the )?disclosure",
    r"field of application",
    r"background( of the invention)?",
    r"state of the art",
    r"prior art",
    r"related art",
    r"object(s)? of (the )?invention",
    r"object(s)? of (the )?(present )?disclosure",
    r"advantage(s)? of (the )?(present )?(invention|disclosure)",
    r"summary( of the invention)?",
    r"presentation of the invention",
    r"brief description of (the )?drawing(s)?",
    r"detailed description( of the invention| of embodiments)?",
    r"description of (the )?(preferred |exemplary )?embodiment(s)?",
    r"working example(s)?",
    r"industrial applicability",
    r"advantageous effects",
    r"^description$",
    r"citation list",
    r"list of prior art",
    r"patent literature",
    r"non.patent literature",
    # --- extra headings common in Indian specifications ---
    r"^description of (the )?(present )?(invention|disclosure)",
    r"^description of (the )?(related|prior) art",
    r"^description of (the )?drawing(s)?",
    r"background art",
    r"cross.reference",
    r"statement of (the )?invention",
    r"disclosure of (the )?invention",
    r"technical problem",
    r"technical solution",
    r"summary of (the )?disclosure",
    r"brief summary",
    r"best mode",
    r"objective(s)? of (the )?(present )?(invention|disclosure)",
]

CLAIM_HEADINGS = [
    r"^claims?$",
    r"what is claimed is",
    r"^claims?(?=\s*:)",
    r"^(we|i)\s+claim",
    r"^i\s*/\s*we\s+claim",
    r"^the claims? defining the invention",
    r"^the invention claimed is",
    r"^patent claims?$",
    r"^claims? of the (present )?invention$",
]

ABSTRACT_HEADINGS = [
    r"^abstract$",
    r"^abstract(?=\s*[:\-\u2013\u2014])",
    r"^abstract of (the )?(present )?(invention|disclosure|technical disclosure)",
    r"^technical abstract$",
    r"^(the )?(figure|fig\.?|drawing) of (the )?abstract$",     # "FIGURE OF ABSTRACT" (abstract page)
    r"^abstract (page|sheet)$",
    r"^abstract of (the )?(specification|complete specification)",
]

DRAWING_HEADINGS = [
    r"^drawings?$",
    r"^drawing sheets?$",
    r"^sheets? of drawings?$",
]

_HEADING_TABLE = (
    [("Description", re.compile(p, re.I)) for p in DESCRIPTION_HEADINGS]
    + [("Claim", re.compile(p, re.I)) for p in CLAIM_HEADINGS]
    + [("Abstract", re.compile(p, re.I)) for p in ABSTRACT_HEADINGS]
    + [("Drawing", re.compile(p, re.I)) for p in DRAWING_HEADINGS]
)

# --------------------------------------------------------------------------
# Other regexes
# --------------------------------------------------------------------------

_NUM_PREFIX = re.compile(
    r"^\s*(?:\(\s*\d{1,3}\s*\)"                                   # (57)  (54)
    r"|[\(\[]?(?:\d{1,2}(?:\.\d{1,2})*|[ivxIVX]{1,4}|[A-Za-z])\s*[\)\]\.:](?=\s))\s*"
)
_INID_ABSTRACT = re.compile(r"^\s*\(\s*57\s*\)")
_PAGE_NUM_LINE = re.compile(
    r"^[-\u2013\u2014\s]*(?:page\s*)?(\d{1,4})[-\u2013\u2014\s]*(?:(?:of|/)\s*\d{1,4})?[-\u2013\u2014\s]*$",
    re.I,
)
# Sequence Listing (WIPO ST.26 tables / ST.25 <210> tags) - part of the description, normally its last part
_SEQ_HEADING = re.compile(
    r"^\W*(?:sequence\s+listings?(?:\s+information)?|listings?\s+of\s+sequences|sequence\s+listing\s+"
    r"(?:\(?\s*part\s+of\s+(?:the\s+)?description\s*\)?))\W*$", re.I)
_SEQ_FIELD = re.compile(
    r"sequence\s+number\s*\[id\]|\bmolecule\s+type\b|features\s+location\s*/\s*qualifiers"
    r"|<\s*(?:110|120|130|160|170|210|211|212|213|220|221|222|223|400)\s*>", re.I)
_SEQ_RESIDUES = re.compile(r"^\s*(?:[A-Za-z]{10}\s+){2,}[A-Za-z]{1,10}\s*\d*\s*$")
_PAGE_STAMP = re.compile(
    r"(?:^|[\s\-\u2013\u2014:,|])page\s*(?:no\.?)?\s*[-:]?\s*(\d{1,4})(?:\s*(?:of|/)\s*\d{1,4})?\s*$", re.I)
_SHEET_NO = re.compile(r"\bsheet\s*no\.?\s*[:\-]?\s*(\d{1,3})\b", re.I)
_SHEET_COUNT = re.compile(r"\bno\.?\s*of\s*sheets?\s*[:\-]?\s*(\d{1,3})\b", re.I)
_SHEET = re.compile(r"\bsheet\s*(?:no\.?\s*)?(\d{1,3})\s*(?:of|/)\s*(\d{1,3})\b", re.I)
_FRACTION_LINE = re.compile(r"^\s*(\d{1,3})\s*/\s*(\d{1,3})\s*$")
_CLAIM_START = re.compile(r"(?m)^\s*(\d{1,3})\s*[\.\)](?:\s+\S|\s*$)")
_CLAIM_WORD_START = re.compile(r"(?mi)^\s*claims?\s+(\d{1,3})\s*(?:\([^)\n]*\))?\s*[:.\)\-\u2013]")
_CLAIM_PHRASE = re.compile(r"\b(?:comprising|wherein|consisting|characteri[sz]ed)\b", re.I)
_CLAIM_REF = re.compile(
    r"\bclaims?\s+\d{1,3}\b"
    r"|\bas claimed in\b"
    r"|\baccording to (?:any (?:one )?of )?(?:the )?(?:preceding |previous )?claims?\b"
    r"|\bof any (?:one )?of (?:the )?(?:preceding |previous )?claims\b",
    re.I,
)
_FIG_LABEL_LINE = re.compile(r"\bfig(?:ure)?s?\.?\s*\d+", re.I)
_FIG_CAPTION = re.compile(
    r"^\s*fig(?:ure)?s?\.?\s*\d+[a-z]?(?:\s*(?:,|and|to|-|\u2013)\s*(?:fig(?:ure)?s?\.?\s*)?\d+[a-z]?)*"
    r"\s+(?:is|are|shows?|illustrates?|depicts?|represents?|schematically|illustrate|show)\b",
    re.I,
)
_DESC_PHRASES = re.compile(
    r"\bpresent (?:invention|disclosure|subject matter)\b|\bembodiments?\b|\bin accordance with\b"
    r"|\bthe invention relates\b|\bpreferred\b|\bthe disclosure relates\b|\bhereinafter\b",
    re.I,
)
_FRONT_MARKERS = [
    re.compile(p, re.I) for p in (
        r"application for grant of (?:a )?patent",
        r"patent application publication",
        r"\(\s*19\s*\)\s*india",
        r"\(\s*21\s*\)\s*application no",
        r"\(\s*22\s*\)\s*date of filing",
        r"\(\s*43\s*\)\s*date of publication",
        r"no\.?\s*of\s*pages",
        r"no\.?\s*of\s*claims",
        r"the controller of patents",
        r"patent office journal",
    )
]
_OTHER_FORM = re.compile(r"^\s*form\s*(?:no\.?\s*)?(\d{1,2})\b", re.I)
_OTHER_MARKERS = [
    re.compile(p, re.I) for p in (
        r"statement and undertaking under section 8",
        r"declaration as to inventorship",
        r"power of (?:authority|attorney)",
        r"undertaking under section",
    )
]
_NO_OF_CLAIMS = re.compile(r"no\.?\s*of\s*claims?\s*[:\-]?\s*(\d{1,3})", re.I)
_SMALL_WORDS = {"of", "the", "and", "a", "an", "in", "for", "to", "on", "or", "with", "by"}

# --------------------------------------------------------------------------
# Decoder settings
# --------------------------------------------------------------------------

SWITCH_COST = 1.0
OTHER_COST = 0.8
DEFAULT_ORDER_PEN = 2.5
ORDER_PEN = {
    (None, "Description"): 0.0, (None, "Abstract"): 0.4,
    (None, "Claim"): 2.5, (None, "Drawing"): 2.5,
    ("Description", "Claim"): 0.0, ("Description", "Abstract"): 1.0,
    ("Description", "Drawing"): 0.8,
    ("Claim", "Abstract"): 0.0, ("Claim", "Drawing"): 0.2,
    ("Claim", "Description"): 3.5,
    ("Abstract", "Description"): 0.4, ("Abstract", "Claim"): 1.5,
    ("Abstract", "Drawing"): 0.0,
    ("Drawing", "Abstract"): 1.5, ("Drawing", "Claim"): 1.2,
    ("Drawing", "Description"): 3.0,
}
# Sub-parts of the DESCRIPTION shown under it (Field of Invention, Background, Summary, Sequence Listing).
# Other description headings still act as boundaries so each sub-part ends where the next heading starts.
SUB_SECTIONS = ["Field of Invention", "Background of the Invention", "Summary of Invention", "Sequence Listing"]
_SUB_CLASSES = [
    ("Field of Invention", re.compile(r"technical (area|field)|field of", re.I)),
    ("Background of the Invention", re.compile(r"background|state of the art|prior art|related art", re.I)),
    ("Summary of Invention", re.compile(
        r"summary|statement of (the )?invention|disclosure of (the )?invention|presentation of the invention"
        r"|brief summary|technical (problem|solution)|object(ive)?s? of", re.I)),
]


def _sub_class(label):
    t = re.sub(r"^[\W_]*(?:\d+(?:\.\d+)*|[ivxIVX]+)?[\W_]*", "", label or "").strip()
    for name, rx in _SUB_CLASSES:
        if rx.match(t):
            return name
    return "other"


_BIT = {s: 1 << i for i, s in enumerate(SECTION_LIST)}


# --------------------------------------------------------------------------
# Text helpers
# --------------------------------------------------------------------------

def norm_space(s):
    return re.sub(r"\s+", " ", s or "").strip()


def collapse_spaced(raw):
    """'C L A I M S' -> 'CLAIMS'  (letter-spaced headings)."""
    raw = (raw or "").strip()
    tokens = raw.split()
    if len(tokens) >= 4 and all(len(t) == 1 for t in tokens):
        parts = re.split(r"\s{2,}", raw)
        if len(parts) > 1:
            return " ".join(p.replace(" ", "") for p in parts)
        return raw.replace(" ", "")
    return raw


def _is_styled(text, bold, size, median_size):
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return False
    if sum(c.isupper() for c in letters) / len(letters) > 0.8:
        return True
    if bold or size >= 1.08 * median_size:
        return True
    words = [w for w in text.split() if w[:1].isalpha() and w.lower() not in _SMALL_WORDS]
    return bool(words) and all(w[0].isupper() for w in words)


_FORM_FIELD_NOTE = re.compile(
    r"\(\s*(to be given|not applicable|description shall|claims? shall|see (section|sec)|to be filled)"
    r"|attached\s+separately|shall start from next page", re.I)


def classify_heading(raw_text, bold=False, size=10.0, median_size=10.0):
    """Return {'role','label','inid','title'} if the text is a real heading, else None."""
    raw = collapse_spaced(raw_text)
    inid = bool(_INID_ABSTRACT.match(raw))
    s = norm_space(raw)
    if _FORM_FIELD_NOTE.search(s):
        return None                      # "5. CLAIMS (not applicable for provisional ...)" etc.
    s = _NUM_PREFIX.sub("", s)
    s = s.strip(" \t*#_")
    s = s.rstrip(" :;-\u2013\u2014._*")
    if not s or len(s) > 140:
        return None
    styled = _is_styled(s, bold, size, median_size)
    for role, rx in _HEADING_TABLE:
        m = rx.match(s)
        if not m:
            continue
        rest = s[m.end():]
        rest_clean = rest.strip(" :;-\u2013\u2014._*")
        ok = False
        if rest_clean == "":
            # a wrapped sentence ending ("...the appended claim.") is not a heading
            ok = styled or not raw.rstrip().endswith(".")
        elif rest.lstrip().startswith(":"):
            ok = True                                     # "Heading: inline text"
        elif len(rest_clean.split()) <= 4 and styled and not rest_clean.endswith("."):
            ok = True                                     # "BACKGROUND OF THE INVENTION AND PRIOR ART"
        if ok:
            is_title = role == "Description" and re.match(r"title of", s, re.I) is not None
            return {"role": role, "label": s[:60], "inid": inid and role == "Abstract",
                    "title": is_title}
    return None


# --------------------------------------------------------------------------
# PDF reading
# --------------------------------------------------------------------------

OCR_DPI = 200            # resolution used to OCR whole scanned pages (150 misses small FIG. labels on drawing sheets)
OCR_PICTURE_DPI = 200    # resolution used to read small labels inside a picture ("FIG. 3") - 200 is ~2x faster than 300
_OCR_CACHE = {}          # (file, mtime, size, page, kind, dpi) -> lines | Future
_OCR_CACHE_LOCK = threading.Lock()


def get_ocr_engine():
    """Check that OCR can run (Tesseract + OpenCV). Raises RuntimeError with a clear message."""
    try:
        return ocr_engine.find_tesseract()
    except ocr_engine.OcrUnavailable as exc:
        raise RuntimeError(str(exc))


def ocr_status():
    """(ok, text) for the user interface."""
    return ocr_engine.available()


def _render_gray(page, dpi, clip=None):
    pix = page.get_pixmap(dpi=dpi, colorspace=fitz.csGRAY, alpha=False, clip=clip)
    return np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width).copy()


def _to_points(items, dpi, ox=0.0, oy=0.0, min_score=0.3):
    """OCR pixel boxes -> text-layer style line dicts in PDF points."""
    k = 72.0 / dpi
    lines = []
    for it in items:
        text = norm_space(it["text"])
        if it["conf"] < min_score or not text:
            continue
        x0, y0, x1, y1 = it["x0"] * k + ox, it["y0"] * k + oy, it["x1"] * k + ox, it["y1"] * k + oy
        lines.append({"text": text, "raw": it["text"], "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                      "size": max((y1 - y0) * 0.85, 4.0), "bold": False,
                      "words": [(a * k + ox, b * k + ox, t) for a, b, t in it.get("words", ())]})
    return lines


def _ocr_page_job(gray, dpi):
    """OCR one rendered page (thread-safe). Running text first; a page that comes out nearly empty
    is probably a drawing sheet, so scattered small labels are searched as well (sparse mode)."""
    items = ocr_engine.ocr_image(gray, dpi, psm=3)
    if sum(len(i["text"].split()) for i in items) < 80:
        items = ocr_engine.merge_lines(items, ocr_engine.ocr_image(gray, dpi, psm=11, deskew=False, retry=False))
    return _to_points(items, dpi)


def _cache_key(page, kind, dpi):
    doc = page.parent
    name = getattr(doc, "name", "") or ""
    try:
        st = os.stat(name)
        sig = (name, st.st_mtime_ns, st.st_size)
    except OSError:
        sig = (name, 0, 0)
    return sig + (page.number, kind, dpi)


def _cached(key, compute):
    with _OCR_CACHE_LOCK:
        hit = _OCR_CACHE.get(key)
    if hit is not None:
        return hit.result() if hasattr(hit, "result") else hit
    value = compute()
    with _OCR_CACHE_LOCK:
        _OCR_CACHE[key] = value
    return value


def ocr_page_lines(page, dpi=OCR_DPI, min_score=0.3):
    """OCR a whole PDF page (Tesseract + OpenCV); returns lines in the text-layer format
    (coordinates in PDF points). Results are cached, so the page-number pass and the figure
    pass never OCR the same page twice."""
    ocr_engine.find_tesseract()          # raises OcrUnavailable early with the install hint
    key = _cache_key(page, "page", dpi)
    lines = _cached(key, lambda: _ocr_page_job(_render_gray(page, dpi), dpi))
    return [dict(l) for l in lines]


def ocr_rect_lines(page, rect, dpi=OCR_PICTURE_DPI, pad=6, rot=0):
    """OCR only one rectangle of the page (a raster picture) in sparse mode - this is how the
    'FIG. 1' captions printed inside a drawing are read. Lines come back in page coordinates.

    rot: 0, 90 or 270 - degrees to turn the picture CLOCKWISE before reading, for drawings printed
    sideways on a portrait sheet (the caption then reads upright).  Boxes are mapped back."""
    ocr_engine.find_tesseract()
    r = fitz.Rect(rect)
    r = fitz.Rect(r.x0 - pad, r.y0 - pad, r.x1 + pad, r.y1 + pad)
    r.intersect(page.rect)
    if r.is_empty:
        return []
    key = _cache_key(page, "rect%d,%d,%d,%d,r%d" % (r.x0, r.y0, r.x1, r.y1, rot), dpi)

    def compute():
        import numpy as np
        gray = _render_gray(page, dpi, clip=r)
        if rot == 0:
            # FAST pass first (one Tesseract run).  The slower second reading (grey + black/white merge)
            # is only done when no "FIG" caption was found by the fast pass.
            items = ocr_engine.ocr_image(gray, dpi, psm=11, deskew=False, retry=False)
            if not any(re.search(r"fig", i["text"], re.I) for i in items):
                items = ocr_engine.ocr_image(gray, dpi, psm=11, deskew=False, retry=True)
            return _to_points(items, dpi, ox=r.x0, oy=r.y0)
        h, w = gray.shape[:2]
        rotated = np.ascontiguousarray(np.rot90(gray, -1 if rot == 90 else 1))
        items = ocr_engine.ocr_image(rotated, dpi, psm=11, deskew=False)
        for it in items:
            x0, y0, x1, y1 = it["x0"], it["y0"], it["x1"], it["y1"]
            if rot == 90:      # clockwise turn: original x = y', original y = h - x'
                it["x0"], it["x1"], it["y0"], it["y1"] = y0, y1, h - x1, h - x0
            else:              # counter-clockwise turn: original x = w - y', original y = x'
                it["x0"], it["x1"], it["y0"], it["y1"] = w - y1, w - y0, x0, x1
        return _to_points(items, dpi, ox=r.x0, oy=r.y0)
    return [dict(l) for l in _cached(key, compute)]


def _has_text_layer(page):
    try:
        return bool(_page_lines(page, False)[0])
    except Exception:
        return True


_LINES_CACHE = {}
_LINES_CACHE_MAX = 4000


def _extract_text_lines(page):
    """Text-layer lines of one page -> (lines, has_text).  ONE PyMuPDF text extraction per page: the text
    page is built once over the page plus a margin (to catch stamps printed just outside the page box) and
    is read twice (inside the page = body text, outside = stamp lines)."""
    pr = page.rect
    big = fitz.Rect(pr.x0 - 400, pr.y0 - 400, pr.x1 + 400, pr.y1 + 400)
    try:
        tp = page.get_textpage(clip=big)
        d = tp.extractDICT(cropbox=pr)
        d_big = tp.extractDICT(cropbox=big)
    except Exception:
        d = page.get_text("dict")
        d_big = None
    has_text = any(
        b.get("type") == 0 and any(norm_space("".join(s["text"] for s in ln["spans"]))
                                   for ln in b.get("lines", []))
        for b in d.get("blocks", [])
    )
    lines = []
    for b in d.get("blocks", []):
        if b.get("type") != 0:
            continue
        for ln in b.get("lines", []):
            spans = ln.get("spans", [])
            text = "".join(s["text"] for s in spans)
            if not norm_space(text):
                continue
            x0, y0, x1, y1 = ln["bbox"]
            size = max((s["size"] for s in spans), default=10.0)
            bold = any((s.get("flags", 0) & 16) or "bold" in s.get("font", "").lower()
                       for s in spans)
            lines.append({"text": norm_space(text), "raw": text, "x0": x0, "y0": y0,
                          "x1": x1, "y1": y1, "size": size, "bold": bool(bold)})
    lines += _offpage_stamp_lines(page, d_big)
    lines.sort(key=lambda l: (round(l["y0"] / 3.0), l["x0"]))
    return lines, has_text


def _page_lines(page, use_ocr):
    """Return (lines, ocr_used, error). Each line is a dict.  Text-layer results are cached per page, so the
    page-number pass and the figure pass never read the same page twice."""
    ocr_used, error = False, None
    key = None
    try:
        doc = page.parent
        if getattr(doc, "name", ""):
            key = _cache_key(page, "txt", 0)
    except Exception:
        key = None
    hit = _LINES_CACHE.get(key) if key else None
    if hit is None:
        hit = _extract_text_lines(page)
        if key:
            with _OCR_CACHE_LOCK:
                if len(_LINES_CACHE) >= _LINES_CACHE_MAX:
                    _LINES_CACHE.clear()
                _LINES_CACHE[key] = hit
    lines, has_text = hit
    if not has_text and use_ocr:
        try:
            ocr_lines = ocr_page_lines(page)
            ocr_lines.sort(key=lambda l: (round(l["y0"] / 3.0), l["x0"]))
            return ocr_lines, True, None
        except Exception as exc:  # Tesseract missing / run failure
            error = str(exc)
    return [dict(l) for l in lines], ocr_used, error


def _offpage_stamp_lines(page, d=None):
    """Some PDFs (e.g. Patent Office downloads) carry a stamp such as
    'Application Number - ... Granted Specification - Page 2' just OUTSIDE the visible page box,
    so normal text extraction never returns it.  Read it back - but keep only lines that look like
    a page-number stamp, so hidden junk can never leak into the body text."""
    out = []
    try:
        pr = page.rect
        if d is None:
            big = fitz.Rect(pr.x0 - 400, pr.y0 - 400, pr.x1 + 400, pr.y1 + 400)
            d = page.get_text("dict", clip=big)
    except Exception:
        return out
    for b in d.get("blocks", []):
        if b.get("type") != 0:
            continue
        for ln in b.get("lines", []):
            x0, y0, x1, y1 = ln["bbox"]
            inside = x0 >= pr.x0 - 1 and x1 <= pr.x1 + 1 and y0 >= pr.y0 - 1 and y1 <= pr.y1 + 1
            if inside:
                continue
            spans = ln.get("spans", [])
            text = norm_space("".join(s["text"] for s in spans))
            if not text or len(text.split()) > 14:
                continue
            if _PAGE_NUM_LINE.match(text) or _PAGE_STAMP.search(text):
                out.append({"text": text, "raw": text, "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                            "size": max((s["size"] for s in spans), default=10.0), "bold": False,
                            "off_page": True})
    return out


def read_document(pdf_path, use_ocr=False, progress=None):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.  Run:  py -m pip install PyMuPDF")
    doc = open_pdf(pdf_path)
    pages = []
    ocr_error = None
    n = len(doc)

    # Scanned pages are OCR'd several at a time: pages are rendered here (one after the other, a few
    # ahead of the page being analysed) and the Tesseract runs happen in worker threads.
    pool, need, submitted = None, [], 0
    if use_ocr:
        need = [i for i in range(n) if not _has_text_layer(doc[i])]
        if need and ocr_engine.available()[0]:
            pool = ThreadPoolExecutor(max_workers=ocr_engine.worker_count())
    ahead = (ocr_engine.worker_count() * 2) if pool else 0
    try:
        for i, page in enumerate(doc):
            while pool and submitted < len(need) and need[submitted] <= i + ahead:
                pg = doc[need[submitted]]
                key = _cache_key(pg, "page", OCR_DPI)
                with _OCR_CACHE_LOCK:
                    known = key in _OCR_CACHE
                if not known:
                    fut = pool.submit(_ocr_page_job, _render_gray(pg, OCR_DPI), OCR_DPI)
                    with _OCR_CACHE_LOCK:
                        _OCR_CACHE[key] = fut
                submitted += 1
            lines, ocr_used, err = _page_lines(page, use_ocr)
            if err and not ocr_error:
                ocr_error = err
            try:
                n_images = len(page.get_images(full=False))
            except Exception:
                n_images = 0
            words_quick = sum(len(l["text"].split()) for l in lines)
            n_paths = 0
            if words_quick < 120:
                try:
                    n_paths = len(page.get_drawings())
                except Exception:
                    n_paths = 0
            pic_frac = 0.0
            if n_images and words_quick < 120:
                try:
                    area = page.rect.get_area() or 1.0
                    for img in page.get_images(full=True):
                        for r_ in page.get_image_rects(img[0]):
                            rr = fitz.Rect(r_)
                            rr.intersect(page.rect)
                            pic_frac = max(pic_frac, rr.get_area() / area)
                except Exception:
                    pic_frac = 0.0
            pages.append({
                "pdf_page": i + 1, "lines": lines, "height": page.rect.height,
                "n_images": n_images, "n_paths": n_paths, "ocr_used": ocr_used, "pic_frac": pic_frac,
            })
            if progress:
                progress(i + 1, n)
    finally:
        if pool:
            pool.shutdown(wait=True)
        # finished jobs keep their (small) results in the cache; drop any that never completed
        with _OCR_CACHE_LOCK:
            for k in [k for k, v in _OCR_CACHE.items() if hasattr(v, "result")]:
                f = _OCR_CACHE[k]
                try:
                    _OCR_CACHE[k] = f.result()
                except Exception:
                    del _OCR_CACHE[k]
    doc.close()
    return pages, ocr_error


# --------------------------------------------------------------------------
# Page analysis
# --------------------------------------------------------------------------

def analyze_page(p, median_size):
    lines = p["lines"]
    H = p["height"] or 842.0
    body, furniture_printed, all_text_lines = [], None, []
    printed_explicit = False

    for ln in lines:
        zone = None
        if ln["y1"] < 0.07 * H:
            zone = "header"
        elif ln["y0"] > 0.93 * H:
            zone = "footer"
        if zone:
            # tight-margin pages: "We Claim:" / "ABSTRACT" / "DETAILED DESCRIPTION:" can sit inside
            # the top or bottom 7 %.  Running headers/footers are short, so a heading or a long
            # sentence in these bands is real body text, not page furniture.
            hh = classify_heading(ln["text"], ln["bold"], ln["size"], median_size)
            if hh and not hh["title"] and hh["role"] in ("Claim", "Abstract", "Drawing", "Description"):
                zone = None
            elif len(ln["text"].split()) >= 12:
                zone = None
        if ln.get("off_page"):
            zone = "footer" if ln["y0"] >= 0.5 * H else "header"
        ln["zone"] = zone
        all_text_lines.append(ln["text"])
        m = _PAGE_NUM_LINE.match(ln["text"])
        if not m and zone and len(ln["text"].split()) <= 14:
            m = _PAGE_STAMP.search(ln["text"])      # "... Granted Specification - Page 2"
        if m:
            if zone and furniture_printed is None:
                furniture_printed = m.group(1)
                printed_explicit = bool(re.search(r"\bpage\b", ln["text"], re.I))
            continue                       # page numbers / margin numbers are not body text
        if zone:
            continue
        body.append(ln)

    body_text = "\n".join(l["text"] for l in body)
    words = len(body_text.split())

    # ---- headings -------------------------------------------------------
    headings, word_running = [], 0
    i = 0
    while i < len(body):
        ln = body[i]
        h = classify_heading(ln["text"], ln["bold"], ln["size"], median_size)
        span = 1
        if h is None and i + 1 < len(body):
            nxt = body[i + 1]
            if (len(ln["text"].split()) <= 6 and not ln["text"].endswith(".")
                    and len(nxt["text"].split()) <= 5
                    and abs(nxt["y0"] - ln["y1"]) < 1.3 * max(ln["size"], 8)):
                h = classify_heading(ln["text"] + " " + nxt["text"],
                                     ln["bold"] and nxt["bold"], ln["size"], median_size)
                span = 2 if h else 1
        if h:
            h["line_idx"] = i
            h["words_before"] = word_running
            headings.append(h)
        for k in range(span):
            word_running += len(body[i + k]["text"].split())
        i += span

    # ---- content features ------------------------------------------------
    # numbered items: "1. ...", "1) ..." and "Claim 1: ..." in reading order
    starts = [(m.start(), m.end(), int(m.group(1))) for m in _CLAIM_START.finditer(body_text)]
    starts += [(m.start(), m.end(), int(m.group(1))) for m in _CLAIM_WORD_START.finditer(body_text)]
    starts = sorted(x for x in starts if 1 <= x[2] <= 200)
    claim_nums = [x[2] for x in starts]
    claim_starts = len(set(claim_nums))
    # A numbered LIST in the description ("1. Provides enhanced insulation ...") is not a claim.
    # An item only counts as claim-like if it refers to another claim, or reads like a claim
    # (comprising / wherein / consisting ...) and is not a one-line list entry.
    claim_like_nums = set()
    for k, (st, en, num) in enumerate(starts):
        end = starts[k + 1][0] if k + 1 < len(starts) else len(body_text)
        item = body_text[en:min(end, en + 1500)]
        if _CLAIM_REF.search(item) or (_CLAIM_PHRASE.search(item) and len(item.split()) >= 12):
            claim_like_nums.add(num)
    claim_like = len(claim_like_nums)
    claim_refs = len(_CLAIM_REF.findall(body_text))

    fig_label_lines = sum(1 for l in body
                          if len(l["text"].split()) <= 5 and _FIG_LABEL_LINE.search(l["text"]))
    fig_captions = sum(1 for l in body if _FIG_CAPTION.match(l["text"]))
    fig_mentions = len(_FIG_LABEL_LINE.findall(body_text))
    desc_phr = len(_DESC_PHRASES.findall(body_text))

    seq_heading = next((t for t in all_text_lines if len(t.split()) <= 8 and _SEQ_HEADING.match(t)), None)
    seq_hits = len(_SEQ_FIELD.findall("\n".join(all_text_lines)))
    seq_residues = sum(1 for t in all_text_lines if _SEQ_RESIDUES.match(t))

    sheet = None
    for t in all_text_lines:
        m = _SHEET.search(t)
        if m:
            sheet = (int(m.group(1)), int(m.group(2)))
            break
    if sheet is None:                                  # "No. of Sheet: 1" / "Sheet No. 1"
        head = " ".join(all_text_lines[:12])
        m_no, m_cnt = _SHEET_NO.search(head), _SHEET_COUNT.search(head)
        if m_no or m_cnt:
            n_ = int(m_no.group(1)) if m_no else 1
            sheet = (n_, int(m_cnt.group(1)) if m_cnt else 0)
    if sheet is None:                                  # "Page No.1 ... Total Page no. 9" drawing-sheet header
        head = " ".join(all_text_lines[:6])
        m_pn = re.search(r"\bpage\s*no\.?\s*(\d{1,3})\b", head, re.I)
        m_tp = re.search(r"\btotal\s*page\s*no\.?\s*(\d{1,3})\b", head, re.I)
        if m_pn and m_tp and int(m_pn.group(1)) <= int(m_tp.group(1)):
            sheet = (int(m_pn.group(1)), int(m_tp.group(1)))
    if sheet is None and words < 40:
        for t in all_text_lines:
            m = _FRACTION_LINE.match(t)
            if m and 1 <= int(m.group(1)) <= int(m.group(2)) <= 60:
                sheet = (int(m.group(1)), int(m.group(2)))
                break

    top_lines = [l["text"] for l in body[:8]]
    form_no = None
    for t in top_lines:
        m = _OTHER_FORM.match(t)
        if m and len(t.split()) <= 10:
            form_no = int(m.group(1))
            break
    joined = " ".join(all_text_lines)
    front_hits = sum(1 for rx in _FRONT_MARKERS if rx.search(joined))
    inid_count = len(re.findall(r"\(\s*\d{2}\s*\)", joined))
    other_hits = sum(1 for rx in _OTHER_MARKERS if rx.search(body_text))
    spec_marker = bool(re.search(r"complete specification|provisional specification",
                                 " ".join(top_lines), re.I))
    # "3. PREAMBLE TO THE DESCRIPTION" belongs to the Form 2 cover (it may spill to page 2)
    preamble = bool(re.search(r"preamble\s+to\s+(the\s+)?description", joined, re.I))
    claim_banner = any(_CLAIM_BANNER.search(t) for t in all_text_lines[:6])
    claim_phr = len(re.findall(r"\bwherein\b|\bcomprising\b|\bconfigured to\b|\bsaid\b|\bas claimed\b",
                               body_text, re.I))
    para_tags = len(re.findall(r"\[\s*\d{3,4}\s*\]", joined))
    signed = bool(re.search(r"agent\s+for\s+the\s+applicant|attorneys?\s+for\s+the\s+applicant|\bIN/PA\b",
                            joined, re.I))
    m = _NO_OF_CLAIMS.search(joined)
    declared_claims = int(m.group(1)) if m else None

    return {
        "pdf_page": p["pdf_page"], "words": words, "headings": headings,
        "claim_nums": claim_nums, "claim_starts": claim_starts, "claim_like": claim_like,
        "claim_refs": claim_refs,
        "fig_label_lines": fig_label_lines, "fig_captions": fig_captions,
        "fig_mentions": fig_mentions, "desc_phrases": desc_phr,
        "sheet": sheet, "form_no": form_no, "front_hits": front_hits,
        "inid_count": inid_count, "other_hits": other_hits, "spec_marker": spec_marker, "preamble": preamble, "claim_banner": claim_banner, "claim_phr": claim_phr, "signed": signed, "para_tags": para_tags,
        "declared_claims": declared_claims,
        "n_images": p["n_images"], "n_paths": p["n_paths"],
        "seq_heading": seq_heading, "seq_hits": seq_hits, "seq_residues": seq_residues,
        "seq_page": bool(seq_heading) or seq_hits >= 3 or seq_residues >= 3,
        "ocr_used": p["ocr_used"], "printed": furniture_printed, "printed_explicit": printed_explicit, "pic_frac": p.get("pic_frac", 0.0),
        "body_text": body_text,
    }


def page_emissions(f):
    """Evidence score for each label on this page."""
    e = {lab: 0.0 for lab in LABELS}
    w = f["words"]
    form1_like = (f["form_no"] is not None and f["form_no"] != 2) or f["front_hits"] >= 3
    tags = []

    # ---------------- Description
    d = 1.8 if w >= 120 else (1.0 if w >= 60 else 0.3)
    d += min(f["desc_phrases"], 4) * 0.3
    d += min(f["fig_captions"], 3) * 0.8
    d -= min(f["claim_refs"], 6) * 0.5
    desc_heads = [h for h in f["headings"] if h["role"] == "Description"]
    strong = [h for h in desc_heads if not h["title"]]
    title_only = [h for h in desc_heads if h["title"]]
    form2_page = f["form_no"] == 2 or f["spec_marker"] or f["preamble"]
    # Form 2 cover (title / applicant / preamble only): the description has NOT started yet,
    # so this page is not part of it.  If a real description heading or a body of text is on
    # the same page (e.g. "4. DESCRIPTION - Background ..."), the description starts here.
    # Rule: a Form 2 page (form header / title / applicant / preamble) is never the first
    # description page, even when "4. DESCRIPTION ..." starts at its bottom.  The description
    # starts on the first page that begins with description text.  Only a Form 2 page that is
    # mostly description text (>= FORM2_DESC_WORDS words) is kept as description.
    cover_only = form2_page and f["words"] < FORM2_DESC_WORDS
    if cover_only:
        d = 0.0
        tags.append("Form 2 cover page (description not started)")
    else:
        if form2_page:
            d += 1.5
            tags.append("Form 2/specification header")
        if strong:
            d += min(3.0 + 0.5 * (len(strong) - 1), 4.5)
        if title_only and not form1_like:
            d += 2.0
    for h in desc_heads[:3]:
        tags.append(f"Heading[Description]: {h['label']}")
    e["Description"] = d

    # ---------------- Claim
    c = min(f["claim_like"], 6) * 0.9 + min(f["claim_refs"], 8) * 0.9
    if f["claim_like"] >= 2 and f["claim_refs"] >= 1:
        c += 1.0
    claim_heads = [h for h in f["headings"] if h["role"] == "Claim"]
    if claim_heads:
        c += 6.0
        tags.append(f"Heading[Claim]: {claim_heads[0]['label']}")
    if f["signed"] and f["claim_phr"] >= 2 and w < 200 and not claim_heads:
        c += 2.0 + min(f["claim_phr"], 5) * 0.4           # tail of the claims + attorney signature
        tags.append("claim wording + attorney signature (tail of claims)")
    if f["claim_banner"]:
        c += 3.5
        tags.append("claims banner (e.g. 'Amended claims (Clean copy)')")
    if f["claim_starts"] or f["claim_refs"]:
        tags.append(f"claim-numbering={f['claim_like']} (of {f['claim_starts']} numbered items), 'claim N' refs={f['claim_refs']}")
    e["Claim"] = c

    # ---------------- Abstract
    a = 0.0
    abs_heads = [h for h in f["headings"] if h["role"] == "Abstract"]
    if abs_heads:
        a += 8.0 if any(h["inid"] for h in abs_heads) else 6.0
        tags.append(f"Heading[Abstract]: {abs_heads[0]['label']}"
                    + (" (INID 57)" if abs_heads[0]["inid"] else ""))
    elif 25 <= w <= 260 and f["claim_starts"] == 0 and f["claim_refs"] == 0 \
            and f["fig_label_lines"] == 0 and not f["claim_banner"] \
            and not f["signed"]:
        a += 1.0
    e["Abstract"] = a

    # ---------------- Drawing
    r = 0.0
    if f["sheet"]:
        r += 4.0
        tags.append(f"sheet marker {f['sheet'][0]}/{f['sheet'][1] or '?'}")
    if f["fig_label_lines"] >= 1 and w < 150:
        r += 2.5 + 0.3 * min(f["fig_label_lines"] - 1, 3)
        tags.append(f"FIG labels={f['fig_label_lines']}")
    if (f["n_images"] >= 1 or f["n_paths"] >= 15) and w < 80:
        r += 2.0 if w > 0 else 2.5
        tags.append(f"graphics (images={f['n_images']}, vector paths={f['n_paths']})")
    if f.get("pic_frac", 0.0) >= 0.2 and w < 120:
        r += 1.5                       # the page is mostly one big picture (a small signature image is not)
        tags.append(f"large picture ({int(f['pic_frac'] * 100)}% of page)")
    draw_heads = [h for h in f["headings"] if h["role"] == "Drawing"]
    if draw_heads:
        r += 2.5 if w < 150 else 0.5
        tags.append(f"Heading[Drawing]: {draw_heads[0]['label']}")
    if w >= 250:
        r -= 3.0
    elif w >= 150:
        r -= 1.5
    r -= min(f["fig_captions"], 3) * 0.6
    e["Drawing"] = r

    # ---------------- Other (cover forms, Form 3/5..., blank pages)
    o = 0.2
    if cover_only:
        o += 4.0
    if f["form_no"] is not None and f["form_no"] != 2:
        o += 4.5
        tags.append(f"Form {f['form_no']} header")
    o += min(f["front_hits"], 4) * 1.2
    if f["inid_count"] >= 4:
        o += 1.5
        tags.append(f"bibliographic front page ({f['inid_count']} INID codes)")
    o += min(f["other_hits"], 2) * 2.0
    if w == 0 and f["n_images"] == 0 and f["n_paths"] == 0:
        o += 0.6
        tags.append("blank page")
    e["Other"] = o
    return e, tags


def find_sequence_block(feats):
    """(first, last) 0-based pages of a Sequence Listing, or None.  A run of consecutive sequence
    pages (heading 'Sequence Listing', ST.26 field labels, ST.25 <210> tags or blocks of 10-letter
    residue groups).  The run must carry the heading or be clearly sequence data on several pages,
    so a few 'SEQ ID NO' mentions or a CDR table in the description never qualify."""
    n = len(feats)
    flag = [bool(f.get("seq_page")) for f in feats]
    runs, i = [], 0
    while i < n:
        if not flag[i]:
            i += 1
            continue
        j = i
        while True:
            if j + 1 < n and flag[j + 1]:
                j += 1
            elif j + 2 < n and flag[j + 2] and feats[j + 1]["words"] < 60:
                j += 2                                  # one near-empty page inside the listing
            else:
                break
        runs.append((i, j))
        i = j + 1
    good = []
    for a, b in runs:
        has_head = any(feats[k].get("seq_heading") for k in range(a, b + 1))
        strong = sum(1 for k in range(a, b + 1) if feats[k]["seq_hits"] >= 3 or feats[k]["seq_residues"] >= 3)
        if has_head or (b - a + 1 >= 3 and strong >= 3):
            good.append((a, b))
    if not good:
        return None
    a, b = max(good, key=lambda r: (r[1] - r[0], r[0]))
    head = [k for k in range(a, b + 1) if feats[k].get("seq_heading")]
    if head:
        a = head[0]                                     # the listing starts at its heading
    return (a, b)


def decode(emis):
    """Best labelling; each section is one contiguous block (Other may recur)."""
    n = len(emis)
    START = (None, 0, False)
    dp = {START: (0.0, None)}
    history = []
    for i in range(n):
        new = {}
        for st, (sc, _) in dp.items():
            last, mask, in_other = st
            opts = []
            if i == 0:
                opts.append(((last, mask, True), 0.0, "Other"))
                for s in SECTION_LIST:
                    opts.append(((s, mask | _BIT[s], False),
                                 ORDER_PEN.get((None, s), DEFAULT_ORDER_PEN), s))
            else:
                opts.append((st, 0.0, "Other" if in_other else last))
                if not in_other:
                    opts.append(((last, mask, True), OTHER_COST, "Other"))
                for s in SECTION_LIST:
                    if in_other and s == last:
                        opts.append(((s, mask, False), OTHER_COST, s))
                    elif not (mask & _BIT[s]):
                        opts.append(((s, mask | _BIT[s], False),
                                     SWITCH_COST + ORDER_PEN.get((last, s), DEFAULT_ORDER_PEN), s))
            for nst, cost, label in opts:
                val = sc - cost + emis[i][label]
                if nst not in new or val > new[nst][0]:
                    new[nst] = (val, st)
        history.append(new)
        dp = new
    if not dp:
        return []
    state = max(dp, key=lambda k: dp[k][0])
    labels = []
    for i in range(n - 1, -1, -1):
        last, _, in_other = state
        labels.append("Other" if in_other else last)
        state = history[i][state][1]
    labels.reverse()
    return labels


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

def open_pdf(path):
    """fitz.open() that repairs pages whose MediaBox is SMALLER than their CropBox (some exporters write
    the drawing sheets that way).  Viewers then show the sheet clipped (\"NETWOR / K\", missing figures);
    the artwork is still in the file, so the page is opened at its full size instead."""
    doc = fitz.open(path)
    try:
        for page in doc:
            mb, cb = page.mediabox, page.cropbox
            if not mb.contains(cb) and (cb.width > mb.width * 1.02 or cb.height > mb.height * 1.02):
                page.set_mediabox(cb | mb)
    except Exception:
        pass
    return doc


def analyze_pdf(pdf_path, use_ocr=False, progress=None):
    """
    Returns dict:
      rows       - one per section: TITLE / FIRST pg.no / Last Pg.no / Confidence / Detection / Review
      page_rows  - one per PDF page (label, printed page number, words, evidence)
      warnings   - list of strings that deserve a manual look
      n_pages    - page count
    """
    pages, ocr_error = read_document(pdf_path, use_ocr, progress)
    n = len(pages)
    sizes = [l["size"] for p in pages for l in p["lines"]]
    median_size = statistics.median(sizes) if sizes else 10.0

    feats = [analyze_page(p, median_size) for p in pages]
    emis, tags = [], []
    for f in feats:
        e, t = page_emissions(f)
        emis.append(e)
        tags.append(t)

    warnings = []
    no_text_pages = sum(1 for f in feats if f["words"] == 0 and f["n_images"] > 0)
    scanned = n > 0 and no_text_pages / n > 0.5
    if scanned:
        if use_ocr and ocr_error:
            warnings.append("Scanned PDF and OCR failed: " + ocr_error[:160])
        elif use_ocr:
            warnings.append("Scanned PDF: OCR could not read most pages.")
        else:
            warnings.append("Most pages have no text layer (scanned PDF). "
                            "Tick 'Use OCR' (needs Tesseract) - results below are unreliable.")
    elif use_ocr and ocr_error:
        warnings.append("OCR unavailable for some pages: " + ocr_error[:160])

    seq_block = find_sequence_block(feats) if n else None
    if seq_block:
        # A Sequence Listing is the last part of the DESCRIPTION.  Its pages may only be Description or
        # unassigned: they can never be taken for Drawing / Abstract / Claim (e.g. when the listing is
        # attached after the drawings, where it cannot join the Description and stays unassigned).
        for i in range(seq_block[0], seq_block[1] + 1):
            emis[i] = {"Other": 0.2, "Description": 3.0, "Claim": -3.0, "Abstract": -3.0, "Drawing": -3.0}
    labels = decode(emis) if n else []
    if n and not any(lab in SECTION_LIST for lab in labels) and not scanned and not seq_block:
        warnings.append("No patent sections were recognised in this PDF - is it a patent specification?")

    # ---- section ranges ---------------------------------------------------
    rng = {}
    for s in SECTION_LIST:
        idx = [i for i, lab in enumerate(labels) if lab == s]
        if idx:
            rng[s] = [idx[0], idx[-1]]

    def heads_on(i, role):
        return [h for h in feats[i]["headings"] if h["role"] == role]

    def real_heads_on(i, role):
        # "Title of the invention" is also a cover-page / form field, so it never
        # counts as evidence that a section *starts mid-page*.
        return [h for h in heads_on(i, role) if not h["title"]]

    # heading rescue: a section that owns no page of its own because its heading sits on a
    # page dominated by another section (e.g. "ABSTRACT" under the last claims)
    rescued = set()
    for s in ("Claim", "Abstract"):
        if s in rng:
            continue
        cand = [i for i in range(n) if heads_on(i, s)]
        if cand:
            if s == "Claim":
                i = max(cand, key=lambda k: feats[k]["claim_like"] + feats[k]["claim_refs"])
            else:
                i = cand[0]
            rng[s] = [i, i]
            rescued.add(s)

    # shared pages: previous section also owns the page where the next one starts
    for s, (a, b) in list(rng.items()):
        hs = real_heads_on(a, s)
        if hs and hs[0]["words_before"] >= 15:
            # only the section that sits IMMEDIATELY before this heading shares its page.
            # (Extending every section that ended within 2 pages wrongly dragged e.g. the
            # Description onto the Abstract page when Claims sat in between.)
            prev = [(ob, oa, other) for other, (oa, ob) in rng.items()
                    if other != s and ob < a and ob >= a - 2 and ob != a]
            if prev:
                _, _, other = max(prev)
                rng[other][1] = a
        # heading sits on the last page of the previous run (labelled previous section)
        if a > 0 and labels[a - 1] not in ("Other", s):
            hs2 = real_heads_on(a - 1, s)
            if hs2 and hs2[0]["words_before"] >= 15:
                rng[s][0] = a - 1

    # claims that run on over unnumbered pages: the last claim (often a method with many steps) can fill
    # whole pages that have no "1." / "claim N" pattern, and the page is then labelled "Other".  Pages right
    # after the claims, before the next section starts, that read like claim wording (and have no
    # [0001]-style paragraph numbers) still belong to the claims.
    if "Claim" in rng:
        stop = min([rng[o][0] for o in rng if o != "Claim" and rng[o][0] > rng["Claim"][1]] + [n])
        gap = []
        j = rng["Claim"][1] + 1
        while j < stop and labels[j] == "Other" and feats[j]["para_tags"] == 0 and not feats[j]["headings"]:
            gap.append(j)
            j += 1
        # the attorney's signature closes the claims: everything up to it is claim wording
        signed_at = next((k for k in gap if feats[k]["signed"]
                          and (feats[k]["claim_phr"] >= 1 or k == gap[0])), None)
        if signed_at is not None:
            take = [k for k in gap if k <= signed_at]
        else:
            take = []
            for k in gap:
                if feats[k]["claim_phr"] < 3:
                    break
                take.append(k)
        for k in take:
            labels[k] = "Claim"
        if take:
            rng["Claim"][1] = take[-1]

    # ---- Sequence Listing: the LAST part of the description ----------------
    seq_in_desc, seq_after = False, None
    if seq_block:
        sa, sb = seq_block
        in_desc = sum(1 for k in range(sa, sb + 1) if labels[k] == "Description")
        if in_desc * 2 >= (sb - sa + 1) and "Description" in rng:
            rng["Description"][0] = min(rng["Description"][0], sa)
            rng["Description"][1] = max(rng["Description"][1], sb)      # listing closes the description
            seq_in_desc = True
        else:
            prev = [labels[k] for k in range(sa - 1, -1, -1) if labels[k] != "Other"]
            seq_after = prev[0] if prev else None

    # ---- claim count / cross-checks --------------------------------------
    claim_count = None
    if "Claim" in rng:
        a, b = rng["Claim"]
        seq, expected = 0, 1
        for i in range(a, b + 1):
            for num in feats[i]["claim_nums"]:
                if num == expected:
                    seq = num
                    expected += 1
        claim_count = seq or None
    declared_claims = next((f["declared_claims"] for f in feats[:3] if f["declared_claims"]), None)

    if "Claim" in rng and claim_count is None:
        warnings.append("Claim pages found but no numbered claims (1., 2., ...) were read.")
    if declared_claims and claim_count and declared_claims != claim_count:
        warnings.append(f"Front page says {declared_claims} claims but {claim_count} numbered "
                        f"claims were read - check claim page range.")
    for role, name in (("Claim", "Claims"), ("Abstract", "Abstract")):
        pgs = sorted({i + 1 for i, f in enumerate(feats) if any(h["role"] == role for h in f["headings"])})
        if len(pgs) > 1:
            warnings.append(f"Multiple '{name}' headings found on pages {pgs} - please verify.")
    if "Abstract" in rng:
        a, b = rng["Abstract"]
        if b - a + 1 > 2:
            warnings.append(f"Abstract spans {b - a + 1} pages - unusually long, verify.")
    if "Drawing" in rng:
        a, b = rng["Drawing"]
        totals = {feats[i]["sheet"][1] for i in range(a, b + 1) if feats[i]["sheet"] and feats[i]["sheet"][1]}
        count = b - a + 1
        if len(totals) == 1 and next(iter(totals)) != count:
            warnings.append(f"Sheet markers say {next(iter(totals))} drawing sheets but "
                            f"{count} pages were detected as drawings.")
    else:
        if sum(f["fig_mentions"] for f in feats) >= 3 and not scanned:
            warnings.append("Description mentions figures but no drawing pages were detected.")

    # ---- rows -------------------------------------------------------------
    rows = []
    for section in SECTION_ORDER:
        if section not in rng:
            rows.append({"TITLE": section, "FIRST pg.no": "", "Last Pg.no": "",
                         "Confidence": "0%", "Detection": "Not detected", "Review": "YES"})
            continue
        a, b = rng[section]
        start_head = heads_on(a, section)
        conf_start = 0.95 if start_head else 0.6
        why = []
        if start_head:
            why.append(f"Start p.{a + 1}: heading '{start_head[0]['label']}'")
        else:
            best = next((t for t in tags[a] if not t.startswith("Heading")), "content pattern")
            if section == "Drawing" and feats[a]["sheet"]:
                conf_start = 0.85
            if section == "Claim" and feats[a]["claim_like"] >= 3:
                conf_start = 0.8
            why.append(f"Start p.{a + 1}: {best}")

        nxt_sections = [(rng[o][0], o) for o in rng if o != section and rng[o][0] >= b]
        if b == n - 1:
            conf_end, end_why = 0.9, f"End p.{b + 1}: last page of PDF"
        elif nxt_sections:
            ns, nname = min(nxt_sections)
            if heads_on(ns, nname):
                conf_end = 0.92
                end_why = f"End p.{b + 1}: '{nname}' heading starts on p.{ns + 1}"
            else:
                conf_end = 0.65
                end_why = f"End p.{b + 1}: '{nname}' detected by content from p.{ns + 1}"
        else:
            conf_end, end_why = 0.65, f"End p.{b + 1}: followed by non-specification pages"
        why.append(end_why)
        if section == "Description" and seq_in_desc:
            why.append(f"includes Sequence Listing as its last part (p.{seq_block[0] + 1}-{seq_block[1] + 1})")

        if section == "Claim" and claim_count:
            why.append(f"{claim_count} numbered claims")
        shared = []
        for o, (oa, ob) in rng.items():
            if o == section:
                continue
            common = [pg + 1 for pg in range(max(a, oa), min(b, ob) + 1)]
            if common:
                shared.append(f"shares p.{common[0] if len(common) == 1 else str(common[0]) + '-' + str(common[-1])} with {o}")
        if shared:
            why.append("; ".join(shared))
        conf = (conf_start + conf_end) / 2
        if section in rescued:
            conf = min(conf, 0.85)
        if any(section.lower() in w.lower() or (section == "Claim" and "claim" in w.lower())
               for w in warnings):
            conf -= 0.15
        if scanned:
            conf = min(conf, 0.3)
        conf = max(0.0, min(conf, 0.99))
        rows.append({
            "TITLE": section, "FIRST pg.no": a + 1, "Last Pg.no": b + 1,
            "Confidence": f"{round(conf * 100)}%",
            "Detection": "; ".join(why),
            "Review": "YES" if conf < 0.8 else "",
        })
        if section == "Description" and seq_block:
            sa, sb = seq_block
            heads = feats[sa].get("seq_heading")
            conf_s = 0.95 if heads else 0.7
            how = f"heading '{heads}'" if heads else "sequence data (ST.26 / ST.25 pattern)"
            ends = "last page of PDF" if sb == n - 1 else "sequence data ends"
            where = ("last part of the Description" if seq_in_desc else
                     f"placed after {seq_after or 'the other sections'} - kept apart from the Description")
            rows.append({
                "TITLE": "Sequence Listing", "FIRST pg.no": sa + 1, "Last Pg.no": sb + 1,
                "Confidence": f"{round(conf_s * 100)}%",
                "Detection": f"Start p.{sa + 1}: {how}; End p.{sb + 1}: {ends}; {where}",
                "Review": "" if conf_s >= 0.8 else "YES",
            })

    # ---- sub-parts of the Description (Field / Background / Summary / Sequence Listing) ----
    sub_rows = []
    if "Description" in rng:
        da, db = rng["Description"]
        body_end = db
        if seq_block and seq_in_desc:
            body_end = min(db, seq_block[0] - 1)
        marks = []                       # (page index, class) of description headings, in page order
        for i in range(da, body_end + 1):
            for h in feats[i]["headings"]:
                if h["role"] == "Description" and not h["title"]:
                    marks.append((i, _sub_class(h["label"]), h["label"]))
        marks.sort(key=lambda m: m[0])
        found = {}
        for k, (pg, cls, lab) in enumerate(marks):
            if cls == "other" or cls in found:
                continue
            nxt = next((m[0] for m in marks[k + 1:] if m[0] > pg or m[1] != cls), None)
            end = body_end if nxt is None else max(pg, nxt - 1)
            # a following heading that starts mid-page still shares its page
            if nxt is not None and nxt > pg:
                nh = [h for h in feats[nxt]["headings"] if h["role"] == "Description" and not h["title"]]
                if nh and nh[0]["words_before"] >= 15:
                    end = nxt
            found[cls] = (pg, end, lab)
        for name in SUB_SECTIONS:
            if name == "Sequence Listing":
                if seq_block:
                    sub_rows.append({"TITLE": name, "FIRST pg.no": seq_block[0] + 1,
                                     "Last Pg.no": seq_block[1] + 1, "Parent": "Description",
                                     "Detection": "last part of the Description" if seq_in_desc
                                     else f"placed after {seq_after or 'the other sections'}"})
                else:
                    sub_rows.append({"TITLE": name, "FIRST pg.no": "", "Last Pg.no": "",
                                     "Parent": "Description", "Detection": ""})
            elif name in found:
                a_, b_, lab = found[name]
                sub_rows.append({"TITLE": name, "FIRST pg.no": a_ + 1, "Last Pg.no": b_ + 1,
                                 "Parent": "Description", "Detection": f"heading '{lab}'"})
            else:
                sub_rows.append({"TITLE": name, "FIRST pg.no": "", "Last Pg.no": "",
                                 "Parent": "Description", "Detection": ""})
    else:
        sub_rows = [{"TITLE": nm, "FIRST pg.no": "", "Last Pg.no": "", "Parent": "Description",
                     "Detection": ""} for nm in SUB_SECTIONS]

    # ---- per-page table ---------------------------------------------------
    page_rows = []
    for i, f in enumerate(feats):
        owners = [s for s, (a, b) in rng.items() if a <= i <= b]
        label = " + ".join(owners) if owners else "Other"
        if seq_block and seq_block[0] <= i <= seq_block[1]:
            label = "Description (Sequence Listing)" if seq_in_desc else "Sequence Listing"
            f_ = feats[i]
            tags[i].insert(0, "Sequence Listing heading" if f_.get("seq_heading") else
                           f"sequence data ({f_['seq_hits']} field labels, {f_['seq_residues']} residue lines)")
        page_rows.append({
            "PDF page": i + 1,
            # inside a sequence listing a bare number near the edge is table data (lengths, counters),
            # not a page number - accept only an explicit "Page N" stamp there
            "Printed page": ("" if (seq_block and seq_block[0] <= i <= seq_block[1]
                                    and not f.get("printed_explicit")) else (f["printed"] or "")),
            "Section": label,
            "Words": f["words"],
            "Evidence": "; ".join(tags[i][:4]) + (" [OCR]" if f["ocr_used"] else ""),
        })

    return {"rows": rows, "sub_rows": sub_rows, "page_rows": page_rows, "warnings": warnings, "n_pages": n}


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------

def _main(argv):
    if len(argv) < 2:
        print("usage: python detector.py file.pdf [--ocr] [--pages]")
        return 2
    res = analyze_pdf(argv[1], use_ocr="--ocr" in argv)
    print(f"{res['n_pages']} pages\n")
    print(f"{'TITLE':<12}{'FIRST':>6}{'LAST':>6}  {'CONF':>5}  DETECTION")
    for r in res["rows"]:
        print(f"{r['TITLE']:<12}{str(r['FIRST pg.no']):>6}{str(r['Last Pg.no']):>6}  "
              f"{r['Confidence']:>5}  {r['Detection']}")
    if res["warnings"]:
        print("\nWARNINGS")
        for w in res["warnings"]:
            print(" -", w)
    if "--pages" in argv:
        print("\nPAGE  PRINTED  SECTION              WORDS  EVIDENCE")
        for r in res["page_rows"]:
            print(f"{r['PDF page']:>4}  {str(r['Printed page']):>7}  {r['Section']:<20}{r['Words']:>6}  {r['Evidence']}")
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
