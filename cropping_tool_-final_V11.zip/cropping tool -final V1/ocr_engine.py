"""
Lightweight OCR for the patent tool:  Tesseract (command line)  +  OpenCV pre-processing.

* No Python OCR package and no model download: only the small `tesseract` program is needed
  (found automatically - see find_tesseract()).  Start-up cost is ~0 s, nothing is loaded in
  memory between pages.
* OpenCV cleans the picture before Tesseract sees it: grey-scale, even-out the background
  (shadows / yellow paper), straighten a tilted scan, and - only when the first result looks
  weak - a second pass with adaptive thresholding.
* Thread-safe: every call starts its own tesseract process, so pages can be OCR'd in parallel.

Public API
----------
    available()                -> (ok: bool, message: str)
    find_tesseract()           -> path  (raises OcrUnavailable)
    ocr_image(gray, dpi, psm)  -> [ {"text","x0","y0","x1","y1","conf"} ... ]  pixel coordinates
    merge_lines(base, extra)   -> base + the lines of `extra` that are not already in `base`
    worker_count()             -> number of pages to OCR at the same time
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading

import numpy as np

try:
    import cv2
except Exception:  # pragma: no cover - reported through available()
    cv2 = None


class OcrUnavailable(RuntimeError):
    """Tesseract (or OpenCV) is missing."""


INSTALL_HELP = (
    "Tesseract OCR was not found. Install it once (Windows: run install_tesseract.bat, or download the "
    "installer from https://github.com/UB-Mannheim/tesseract/wiki), or copy a Tesseract folder next to "
    "this program as 'tesseract' (see README, 'OCR')."
)

_LOCK = threading.Lock()
_STATE = {"exe": None, "error": None, "version": "", "tessdata": None}
_CREATE_NO_WINDOW = 0x08000000


# --------------------------------------------------------------------------
# locating tesseract
# --------------------------------------------------------------------------

def _app_dirs():
    dirs = []
    if getattr(sys, "frozen", False):                       # PyInstaller exe
        if getattr(sys, "_MEIPASS", None):
            dirs.append(sys._MEIPASS)
        dirs.append(os.path.dirname(sys.executable))
    dirs.append(os.path.dirname(os.path.abspath(__file__)))
    dirs.append(os.getcwd())
    seen, out = set(), []
    for d in dirs:
        if d and d not in seen:
            seen.add(d)
            out.append(d)
    return out


def _candidate_paths():
    exe = "tesseract.exe" if os.name == "nt" else "tesseract"
    cands = []
    env = os.environ.get("TESSERACT_CMD") or os.environ.get("TESSERACT_PATH")
    if env:
        cands.append(env if os.path.isfile(env) else os.path.join(env, exe))
    for d in _app_dirs():                                   # "portable" copy next to the program
        cands.append(os.path.join(d, "tesseract", exe))
        cands.append(os.path.join(d, exe))
    found = shutil.which("tesseract")
    if found:
        cands.append(found)
    if os.name == "nt":
        for var in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
            base = os.environ.get(var)
            if base:
                cands.append(os.path.join(base, "Tesseract-OCR", exe))
        la = os.environ.get("LOCALAPPDATA")
        if la:
            cands.append(os.path.join(la, "Programs", "Tesseract-OCR", exe))
        up = os.environ.get("USERPROFILE")
        if up:
            cands.append(os.path.join(up, "scoop", "apps", "tesseract", "current", exe))
        cands.append(r"C:\Tesseract-OCR\tesseract.exe")
    else:
        cands += ["/usr/bin/tesseract", "/usr/local/bin/tesseract", "/opt/homebrew/bin/tesseract"]
    seen, out = set(), []
    for c in cands:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def _popen_kwargs():
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = _CREATE_NO_WINDOW | 0x00004000  # no console window + BELOW_NORMAL priority (UI stays smooth)
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        kw["startupinfo"] = si
    return kw


def _tess_env(exe):
    env = dict(os.environ)
    env["OMP_THREAD_LIMIT"] = "1"                           # we parallelise over pages instead
    return env


def _tessdata_args(exe):
    """A portable copy ('tesseract\\tessdata' next to tesseract.exe) uses its own language data."""
    td = os.path.join(os.path.dirname(exe), "tessdata")
    if os.path.isfile(os.path.join(td, "eng.traineddata")):
        return ["--tessdata-dir", td]
    return []


def find_tesseract():
    """Return the path of a working tesseract program (cached). Raises OcrUnavailable."""
    with _LOCK:
        if _STATE["exe"]:
            return _STATE["exe"]
        if _STATE["error"]:
            raise OcrUnavailable(_STATE["error"])
        if cv2 is None:
            _STATE["error"] = ("OpenCV is not installed (py -m pip install opencv-python-headless numpy).")
            raise OcrUnavailable(_STATE["error"])
        problems = []
        for cand in _candidate_paths():
            if not os.path.isfile(cand):
                continue
            try:
                r = subprocess.run([cand, "--version"], capture_output=True, timeout=20,
                                   env=_tess_env(cand), stdin=subprocess.DEVNULL, **_popen_kwargs())
                text = (r.stdout + r.stderr).decode("utf-8", "replace")
                if r.returncode != 0 or "tesseract" not in text.lower():
                    problems.append(f"{cand}: not a working Tesseract")
                    continue
                langs = subprocess.run([cand, *_tessdata_args(cand), "--list-langs"], capture_output=True, timeout=20,
                                       env=_tess_env(cand), stdin=subprocess.DEVNULL, **_popen_kwargs())
                ltxt = (langs.stdout + langs.stderr).decode("utf-8", "replace").split()
                if "eng" not in ltxt:
                    problems.append(f"{cand}: English language data (eng.traineddata) is missing")
                    continue
                _STATE["exe"] = cand
                _STATE["version"] = text.strip().splitlines()[0].strip()
                return cand
            except Exception as exc:
                problems.append(f"{cand}: {exc}")
        _STATE["error"] = INSTALL_HELP + ((" (" + "; ".join(problems)[:200] + ")") if problems else "")
        raise OcrUnavailable(_STATE["error"])


def available():
    """(True, 'Tesseract 5.x (path)')  or  (False, reason)."""
    try:
        exe = find_tesseract()
        return True, f"{_STATE['version']}  [{exe}]"
    except OcrUnavailable as exc:
        return False, str(exc)


def worker_count():
    """How many pages are OCR'd at the same time (one single-threaded Tesseract each).
    Default: every core (one is left free on 6+ core machines), at most 8.
    Override with the PATENT_OCR_WORKERS environment variable."""
    try:
        n = int(os.environ.get("PATENT_OCR_WORKERS", "0"))
        if n > 0:
            return n
    except ValueError:
        pass
    cpu = os.cpu_count() or 2
    return max(1, min(8, cpu if cpu <= 5 else cpu - 1))


# --------------------------------------------------------------------------
# OpenCV pre-processing
# --------------------------------------------------------------------------

def _odd(n):
    n = int(n)
    return n if n % 2 else n + 1


def even_background(gray):
    """Divide by an estimate of the paper colour: removes shadows, scanner gradients, yellow paper.
    Skipped (returns the input) for a clean page."""
    h, w = gray.shape[:2]
    s = 4 if max(h, w) > 1200 else 2
    small = cv2.resize(gray, (max(1, w // s), max(1, h // s)), interpolation=cv2.INTER_AREA)
    k = _odd(max(9, min(small.shape[:2]) // 12))
    bg = cv2.morphologyEx(small, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    bg = cv2.GaussianBlur(bg, (_odd(k), _odd(k)), 0)
    uneven = int(bg.max()) - int(np.percentile(bg, 2))
    if uneven < 28 and int(np.median(bg)) > 225:
        return gray
    bg_full = cv2.resize(bg, (w, h), interpolation=cv2.INTER_LINEAR)
    return cv2.divide(gray, np.maximum(bg_full, 1), scale=255)


def estimate_skew(gray, max_angle=6.0):
    """Angle (degrees, OpenCV convention) that makes the text lines horizontal; 0.0 if unsure."""
    h, w = gray.shape[:2]
    scale = min(1.0, 900.0 / max(h, w))
    small = cv2.resize(gray, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA) \
        if scale < 1 else gray
    _, bw = cv2.threshold(small, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    if int(bw.sum() // 255) < 300:
        return 0.0
    # ignore the dark scanner border / frame: keep only the inner 90 %
    sh, sw = bw.shape
    my, mx = int(sh * 0.05), int(sw * 0.05)
    bw = bw[my:sh - my, mx:sw - mx]
    bw = cv2.dilate(bw, np.ones((1, 7), np.uint8))
    sh, sw = bw.shape
    centre = (sw / 2.0, sh / 2.0)

    def score(angle):
        m = cv2.getRotationMatrix2D(centre, angle, 1.0)
        r = cv2.warpAffine(bw, m, (sw, sh), flags=cv2.INTER_NEAREST, borderValue=0)
        p = r.sum(axis=1, dtype=np.float64)
        return float(np.sum(np.diff(p) ** 2))

    base = score(0.0)
    if base <= 0:
        return 0.0
    best_a, best_s = 0.0, base
    for a in np.arange(-max_angle, max_angle + 1e-6, 0.5):
        sc = score(float(a))
        if sc > best_s:
            best_a, best_s = float(a), sc
    for a in np.arange(best_a - 0.5, best_a + 0.5 + 1e-6, 0.1):
        sc = score(float(a))
        if sc > best_s:
            best_a, best_s = float(a), sc
    if abs(best_a) < 0.4 or best_s < 1.15 * base:
        return 0.0
    return best_a


def _rotate(gray, angle):
    h, w = gray.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
    out = cv2.warpAffine(gray, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                         borderValue=255)
    return out, m


def _unrotate_box(m, box):
    """Map a box from the rotated picture back to the original picture (axis-aligned result)."""
    inv = cv2.invertAffineTransform(m)
    x0, y0, x1, y1 = box
    pts = np.array([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], dtype=np.float64)
    pts = pts @ inv[:, :2].T + inv[:, 2]
    return float(pts[:, 0].min()), float(pts[:, 1].min()), float(pts[:, 0].max()), float(pts[:, 1].max())


def clean_binary(gray):
    """Light blur (kills JPEG speckle / scanner noise) + Otsu -> clean black-on-white picture.
    Faster for Tesseract than a noisy grey image and often reads thin or faint text better."""
    g = cv2.GaussianBlur(gray, (3, 3), 0)
    return cv2.threshold(g, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]


# --------------------------------------------------------------------------
# running tesseract
# --------------------------------------------------------------------------

def _scratch_dir():
    """A temp folder with a plain-ASCII path (Tesseract on Windows can fail on non-ASCII paths)."""
    cands = [tempfile.gettempdir(), os.environ.get("PUBLIC", ""), os.environ.get("ProgramData", ""),
             os.getcwd()]
    for c in cands:
        if c and os.path.isdir(c) and all(ord(ch) < 128 for ch in c) and os.access(c, os.W_OK):
            return c
    return tempfile.gettempdir()


def _tesseract_tsv(img, dpi, psm, extra=()):
    exe = find_tesseract()
    fd, tmp = tempfile.mkstemp(suffix=".png", dir=_scratch_dir())
    os.close(fd)
    try:
        cv2.imwrite(tmp, img, [cv2.IMWRITE_PNG_COMPRESSION, 1])
        cmd = [exe, tmp, "stdout", *_tessdata_args(exe), "--psm", str(psm), "--dpi", str(int(dpi)), "-l", "eng",
               "-c", "tessedit_do_invert=0", "-c", "preserve_interword_spaces=1", *extra, "tsv"]
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=45, env=_tess_env(exe),
                               stdin=subprocess.DEVNULL, **_popen_kwargs())
        except subprocess.TimeoutExpired:       # pathological (very noisy) picture: skip it, never hang
            return ""
        if r.returncode != 0 and not r.stdout:
            raise OcrUnavailable("Tesseract failed: " + r.stderr.decode("utf-8", "replace")[:200])
        return r.stdout.decode("utf-8", "replace")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def parse_tsv(tsv, min_word_conf=15):
    """Group tesseract's word rows into text lines -> [{"text","x0","y0","x1","y1","conf"}]."""
    groups = {}
    order = []
    for row in tsv.splitlines()[1:]:
        parts = row.split("\t", 11)
        if len(parts) < 12 or parts[0] != "5":
            continue
        text = parts[11].strip()
        if not text:
            continue
        try:
            conf = float(parts[10])
            left, top, wd, ht = (int(parts[6]), int(parts[7]), int(parts[8]), int(parts[9]))
        except ValueError:
            continue
        if conf < min_word_conf:
            continue
        key = (parts[2], parts[3], parts[4])                # block, paragraph, line
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append((left, top, left + wd, top + ht, conf, text))
    lines = []
    for key in order:
        ws = sorted(groups[key], key=lambda w: w[0])
        lines.append({
            "text": " ".join(w[5] for w in ws),
            "x0": float(min(w[0] for w in ws)), "y0": float(min(w[1] for w in ws)),
            "x1": float(max(w[2] for w in ws)), "y1": float(max(w[3] for w in ws)),
            "words": [(float(w[0]), float(w[2]), w[5]) for w in ws],
            "conf": sum(w[4] * max(len(w[5]), 1) for w in ws) / sum(max(len(w[5]), 1) for w in ws) / 100.0,
        })
    return lines


def _quality(lines):
    """Rough 'how much good text did we get' score used to pick the better of two passes."""
    return sum(l["conf"] * len(l["text"]) for l in lines if l["conf"] >= 0.5)


def ocr_image(gray, dpi=200, psm=3, deskew=True, retry=True, clean=True):
    """OCR one grey-scale picture. Returns lines in the picture's own pixel coordinates.

    psm 3  = automatic page layout (running text, reading order)
    psm 11 = sparse text (finds small labels scattered over a drawing, e.g. "FIG. 3")

    Running text: even-background grey picture first; a denoised black-and-white version is tried
    when the result looks weak.  Sparse labels: both versions always run and the better reading of
    each label is kept (thin / faint captions are read correctly by one or the other).
    """
    if cv2 is None:
        raise OcrUnavailable("OpenCV is not installed.")
    if gray.ndim == 3:
        gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
    work = even_background(gray) if clean else gray
    angle, matrix = 0.0, None
    if deskew and psm in (3, 4, 6):
        angle = estimate_skew(work)
        if angle:
            work, matrix = _rotate(work, angle)

    if psm in (11, 12):
        lines = parse_tsv(_tesseract_tsv(clean_binary(work), dpi, psm), min_word_conf=10)
        if retry:
            lines = merge_lines(lines, parse_tsv(_tesseract_tsv(work, dpi, psm), min_word_conf=10))
    else:
        lines = parse_tsv(_tesseract_tsv(work, dpi, psm))
        n_chars = sum(len(l["text"]) for l in lines)
        mean_conf = (sum(l["conf"] * len(l["text"]) for l in lines) / n_chars) if n_chars else 0.0
        if retry and (n_chars < 40 or mean_conf < 0.50):        # weak result -> denoised black & white
            alt = parse_tsv(_tesseract_tsv(clean_binary(work), dpi, psm))
            if _quality(alt) > _quality(lines):
                lines = alt
    if matrix is not None:
        for l in lines:
            l["x0"], l["y0"], l["x1"], l["y1"] = _unrotate_box(matrix, (l["x0"], l["y0"], l["x1"], l["y1"]))
    return lines


def _overlap(a, b):
    ix = min(a["x1"], b["x1"]) - max(a["x0"], b["x0"])
    iy = min(a["y1"], b["y1"]) - max(a["y0"], b["y0"])
    if ix <= 0 or iy <= 0:
        return 0.0
    smaller = min((a["x1"] - a["x0"]) * (a["y1"] - a["y0"]), (b["x1"] - b["x0"]) * (b["y1"] - b["y0"]))
    return (ix * iy) / max(smaller, 1e-6)


def _score(l):
    return l["conf"] * len(l["text"])


def merge_lines(base, extra, threshold=0.3):
    """Union of two OCR readings of the same picture. A line of `extra` that sits on top of lines
    already in `base` replaces them only if it is clearly the better reading ("FIG. 1" beats "FIG")."""
    out = list(base)
    for e in extra:
        hit = [b for b in out if _overlap(e, b) > threshold]
        if not hit:
            out.append(e)
        elif _score(e) > 1.25 * max(_score(b) for b in hit):
            out = [b for b in out if b not in hit]
            out.append(e)
    return out
